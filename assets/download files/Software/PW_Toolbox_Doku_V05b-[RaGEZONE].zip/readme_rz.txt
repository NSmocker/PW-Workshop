This package contains some sort of toolset for importing and exporting PW-style *.ski files (models, AKA skins).

There's nothing really to describe in this readme; please refer to the attached Tutorial in PDF format.

pvpseeker, Feb. 2010 

-----------------------------
THIS FILE ORIGINATED FROM
WWW.RAGEZONE.COM
-----------------------------
