#include "A3D.h"
#include "A3DHLSL.h"
#include "A3DEffect.h"
#include "A3DTexture.h"
//#include "AIniFile.h"
#include "AFileImage.h"
#include "a3dpi.h"
#include <Shlwapi.h>
#include "afi.h"

#define SHADERINI_SECT "ShaderDesc"
#define SHADERINI_KEY_HLSL "HLSL"
//#define SHADERINI_KEY_BASE "Base"
#define SHADERINI_KEY_MACRO "Macro"
//#define SHADERINI_KEY_BUMP "Bump"
#define STRING_MASK		0x8e
#
class EffectFile : public AFileImage
{
public:
	bool ReadDecryptString(AString& str);
};

class EffectFileSave : public AFile
{
public:
	bool WriteEncryptString(const AString& str);
};

bool EffectFile::ReadDecryptString(AString& str)
{
	DWORD dwRead;

	//	Read length of string
	int iLen;
	if( !Read((BYTE*) &iLen, sizeof (int), &dwRead) )
		return false;

	//	Read string data
	if (iLen)
	{
		char* szBuf = new char [iLen+1];
		if (!szBuf)
			return false;

		if( !Read((BYTE*) szBuf, iLen, &dwRead) )
		{
			delete [] szBuf;
			return false;
		}
		szBuf[iLen] = '\0';
		for(int i = 0; i < iLen; i++)
		{
			szBuf[i] ^= STRING_MASK;
		}
		str = szBuf;

		delete [] szBuf;
	}
	else
		str = "";

	return true;
}

bool EffectFileSave::WriteEncryptString(const AString& str)
{
	int nCount = str.GetLength();
	if(nCount == 0)
	{
		return WriteString(str);
	}

	char* pBuffer = new char[nCount + 1];
	strncpy(pBuffer, str, nCount + 1);
	for(int i = 0; i < nCount; i++)
	{
		pBuffer[i] ^= STRING_MASK;
	}
	bool bVal = WriteString(pBuffer);
	delete pBuffer;
	return bVal;
}

extern A3DCOMMONCONSTDESC s_aSkinRenderCommConst[];
extern size_t g_cbSizeOfSkinRenderCommConst;
A3DEffect::A3DEffect()
: m_pA3DDevice	(NULL)
, m_pHLSL		(NULL)
{
	m_dwClassID	= A3D_CID_HLSLSHADER;
}

A3DEffect::~A3DEffect()
{
}

bool A3DEffect::Init(A3DDevice* pDevice)
{
	m_pA3DDevice = pDevice;
	return true;
}

bool A3DEffect::ReleaseSamplerDesc()
{
	for(SamplerDescArray::iterator it = m_aSampDesc.begin();
		it != m_aSampDesc.end(); ++it)	{
			if(it->pTexture != this)
				m_pA3DDevice->GetA3DEngine()->GetA3DTextureMan()->ReleaseTexture(it->pTexture);
	}
	m_aSampDesc.clear();
	return true;
}
bool A3DEffect::Release()
{
	ReleaseSamplerDesc();
	A3DHLSLMan* pHLSLMan = m_pA3DDevice->GetA3DEngine()->GetA3DHLSLMan();
	pHLSLMan->ReleaseShader(m_pHLSL);
	A3DTexture::Release();
	return true;
}

bool A3DEffect::Reload(bool bForceReload)
{
	if(bForceReload)
	{
		ReleaseSamplerDesc();

		A3DHLSLMan* pHLSLMan = m_pA3DDevice->GetA3DEngine()->GetA3DHLSLMan();
		pHLSLMan->ReleaseShader(m_pHLSL);
		m_pHLSL = NULL;

		return Load(GetMtlFilename(), A3DTexture::GetMapFile());
	}
	else
	{
		if(m_pHLSL != NULL)
			m_pHLSL->ReloadTexture();
	}
}

bool A3DEffect::Load(const char* pszFile, const char* pszOriginFile)
{
	//AIniFile IniFile;
	//if( ! IniFile.Open(pszFile))
	//{
	//	g_A3DErrLog.Log("A3DEffect::Load, can't open HLSLShader file(%s).", pszFile);
	//	return false;
	//}
	DWORD dwRead;
	EffectFile file;
	if( ! file.Open(pszFile, AFILE_BINARY | AFILE_OPENEXIST))
	{
		return false;
	}
	char szFileDir[MAX_PATH];
	char buffer[MAX_PATH];
	EFFECTFILEHEADER efh;
	//strncpy(szFileDir, pszFile, MAX_PATH);
	//PathRemoveFileSpecA(szFileDir);
	af_GetFilePath(pszFile, szFileDir, MAX_PATH);

	const size_t nHeaderSize = sizeof(efh.cbSize);
	const size_t nHeaderSizeRamain = sizeof(EFFECTFILEHEADER) - sizeof(efh.cbSize);

	if( ! file.Read(&efh.cbSize, nHeaderSize, &dwRead) || dwRead != nHeaderSize)
	{
		return false;
	}

	if(efh.cbSize != sizeof(EFFECTFILEHEADER))
	{
		return false;
	}

	if( ! file.Read(&efh.nParamCount, nHeaderSizeRamain, &dwRead) || dwRead != nHeaderSizeRamain)
	{
		return false;
	}

	if(efh.nParamCount < 0 || efh.nParamCount > 64)
	{
		return false;
	}

	AString strHLSLFile;// = IniFile.GetValueAsString(SHADERINI_SECT, SHADERINI_KEY_HLSL, NULL);
	AString strMacro;// =  IniFile.GetValueAsString(SHADERINI_SECT, SHADERINI_KEY_MACRO, NULL);
	//AString strTexture =  IniFile.GetValueAsString(SHADERINI_SECT, SHADERINI_KEY_BASE, NULL);
	if(( ! file.ReadString(strHLSLFile)) || ( ! file.ReadString(strMacro)))
	{
		return false;
	}
	ParamDict sParamDict;
	for(int i = 0; i < efh.nParamCount; i++)
	{
		MTLPARAM Param;
		if(( ! file.ReadDecryptString(Param.strKey)) || ( ! file.ReadDecryptString(Param.strValue)))
		{
			return false;
		}
		sParamDict[Param.strKey] = Param.strValue;
	}

	if(strHLSLFile.GetLength() == 0)
	{
		g_A3DErrLog.Log("A3DEffect::Load, require to specify HLSL file.");
		return false;
	}
	A3DHLSLMan* pHLSLMan = m_pA3DDevice->GetA3DEngine()->GetA3DHLSLMan();
	strncpy(buffer, strHLSLFile, MAX_PATH);
	if( PathIsFileSpecA(buffer) )
	{
		PathCombineA(buffer, szFileDir, strHLSLFile);
	}
	m_pHLSL = pHLSLMan->LoadShader(NULL, NULL, buffer, "ps_main", strMacro.GetLength() == 0 ? NULL : strMacro, NULL);
	if(m_pHLSL == NULL)
	{
		g_A3DErrLog.Log("A3DEffect::Load, load hlsl failed(%s).", buffer);
		return false;
	}
	m_pHLSL->SetCommConstDesc(s_aSkinRenderCommConst, g_cbSizeOfSkinRenderCommConst);

	// ����������
	if(A3DTexture::LoadFromFile(m_pA3DDevice, pszOriginFile, pszOriginFile) == false)
	{
		g_A3DErrLog.Log("A3DEffect::Load, can't load texture(%s).", m_strMapFile);
		return false;
	}

	const A3DHLSL::CONSTMAPDESC* pConstName = m_pHLSL->GetConstMapArray();
	int nCount = m_pHLSL->GetConstCount();
	//for(A3DHLSL::ConstNameDict::const_iterator it = aDict.begin();
	//	it != aDict.end(); ++it)
	for(int i = 0; i < nCount; i++)
	{
		const A3DHLSL::CONSTMAPDESC& cmd = pConstName[i];
		AString strValue;// = IniFile.GetValueAsString(SHADERINI_SECT, cmd.cd.cd.Name);
		ParamDict::iterator it = sParamDict.find(cmd.cd.cd.Name);

		if(it != sParamDict.end())
		{
			strValue = it->second;
		}

		// ��������ļ�û���ҵ���ֵ
		if(strValue.GetLength() == 0)
		{
			// �����sampler������һ��Ĭ�ϵ�����
			if(cmd.cd.cd.RegisterSet == D3DXRS_SAMPLER)
			{
				SAMPLER_DESC SampDesc;

				SampDesc.strName = cmd.cd.cd.Name;
				SampDesc.pTexture = this;
				m_aSampDesc.push_back(SampDesc);
				m_pHLSL->SetTexture(SampDesc.strName, SampDesc.pTexture);
			}
			continue;
		}
		SetValueByString(cmd, strValue);
	}

	return true;
}

bool A3DEffect::Save(const char* pszFile)
{
	DWORD dwWrite;
	EffectFileSave file;
	AString strMtlFilename;

	// �õ�������
	if(pszFile == NULL)
	{
		strMtlFilename = GetMtlFilename();
		pszFile = strMtlFilename;
	}

	if(file.Open(pszFile, AFILE_CREATENEW | AFILE_BINARY | AFILE_NOHEAD) == false)
	{
		g_A3DErrLog.Log("A3DEffect::Save, Can not mtl file(%s).", pszFile);
		return false;
	}

	AString strBuffer;
	AString strFilename;
	AString strMacro;
	AString strValue;

	int nCount = m_pHLSL->GetConstCount();

	EFFECTFILEHEADER efh;
	efh.cbSize = sizeof(EFFECTFILEHEADER);
	efh.nParamCount = nCount;

	if( ! file.Write(&efh, sizeof(EFFECTFILEHEADER), &dwWrite) || dwWrite != sizeof(EFFECTFILEHEADER))
	{
		return false;
	}


	//// Section ��
	//strBuffer.Format("[%s]", SHADERINI_SECT);
	//file.WriteLine(strBuffer);

	//// д�� HLSL ��
	strFilename = GetHLSLFilename();
	//strBuffer.Format("%s = %s", SHADERINI_KEY_HLSL, strFilename);
	//file.WriteLine(strBuffer);

	file.WriteString(strFilename);
	file.WriteString(strMacro);

	// д�����
	const A3DHLSL::CONSTMAPDESC* pConstName = m_pHLSL->GetConstMapArray();
	for(int i = 0; i < nCount; i++)
	{
		const A3DHLSL::CONSTMAPDESC& cmd = pConstName[i];

		if( ! GetValueByString(cmd, strValue))
		{
			strValue.Empty();
		}
		file.WriteEncryptString(cmd.cd.cd.Name);
		file.WriteEncryptString(strValue);
	}

	return true;
}

bool A3DEffect::SetValueByString(const A3DHLSL::CONSTMAPDESC& ConstDesc, const AString& strVaule)
{
	A3DVECTOR4 vValue;
	switch(ConstDesc.cd.cd.Class)
	{
	case D3DXPC_SCALAR:
		{
			sscanf(strVaule, "%f", &vValue.x);
			m_pHLSL->SetConstantArrayF(ConstDesc.cd.cd.Name, &vValue, 1);
		}
		break;
	case D3DXPC_VECTOR:
		{			
			switch(ConstDesc.cd.cd.Columns)
			{
			case 1:
				sscanf(strVaule, "(%f)", &vValue.x);
				break;
			case 2:
				sscanf(strVaule, "(%f,%f)", &vValue.x, &vValue.y);
				break;
			case 3:
				sscanf(strVaule, "(%f,%f,%f)", &vValue.x, &vValue.y, &vValue.z);
				break;
			case 4:
				sscanf(strVaule, "(%f,%f,%f,%f)", &vValue.x, &vValue.y, &vValue.z, &vValue.w);
				break;
			}
			m_pHLSL->SetConstantArrayF(ConstDesc.cd.cd.Name, &vValue, 1);
		}
		break;
	case D3DXPC_MATRIX_ROWS:
		// FIXME: δʵ��
		ASSERT(0);
		break;
	case D3DXPC_MATRIX_COLUMNS:
		// FIXME: δʵ��
		ASSERT(0);
		break;
	case D3DXPC_OBJECT:
		{
			SetTextureByName(ConstDesc.cd.cd.Name, strVaule);
		}
		break;
	case D3DXPC_STRUCT:
		// FIXME: δʵ��
		ASSERT(0);
		break;
	}
	return true;
}

bool A3DEffect::GetValueByString(const A3DHLSL::CONSTMAPDESC& ConstDesc, AString& strVaule)
{
	A3DVECTOR4 vValue;
	bool bVal = false;
	switch(ConstDesc.cd.cd.Class)
	{
	case D3DXPC_SCALAR:
		{
			bVal = m_pHLSL->GetConstantArrayF(ConstDesc.cd.cd.Name, &vValue, 1);
			if(bVal)
			{
				strVaule.Format("%.3f", vValue.x);
			}
		}
		break;
	case D3DXPC_VECTOR:
		{
			bVal = m_pHLSL->GetConstantArrayF(ConstDesc.cd.cd.Name, &vValue, 1);
			if(bVal)
			{
				switch(ConstDesc.cd.cd.Columns)
				{
				case 1:
					strVaule.Format("(%.3f)", vValue.x);
					break;
				case 2:
					strVaule.Format("(%.3f,%.3f)", vValue.x, vValue.y);
					break;
				case 3:
					strVaule.Format("(%.3f,%.3f,%.3f)", vValue.x, vValue.y, vValue.z);
					break;
				case 4:
					strVaule.Format("(%.3f,%.3f,%.3f,%.3f)", vValue.x, vValue.y, vValue.z, vValue.w);
					break;
				}
			}
		}
		break;
	case D3DXPC_MATRIX_ROWS:
		// FIXME: δʵ��
		ASSERT(0);
		break;
	case D3DXPC_MATRIX_COLUMNS:
		// FIXME: δʵ��
		ASSERT(0);
		break;
	case D3DXPC_OBJECT:
		{
			A3DTexture* pTexture = GetTextureByName(ConstDesc.cd.cd.Name);
			if(pTexture != NULL)
			{
				AString strDir = GetMtlFilename();
				AString strPath;
				AString strFullPath;
				af_GetFilePath(strDir, strDir);
				af_GetFullPath(strFullPath, pTexture->GetMapFile());
				af_GetRelativePath(strFullPath, strDir, strPath);
				af_GetRelativePathNoBase(strPath, af_GetBaseDir(), strPath);
				strVaule = strPath;
				bVal = true;
			}
			else
			{
				strVaule.Empty();
			}
		}
		break;
	case D3DXPC_STRUCT:
		// FIXME: δʵ��
		ASSERT(0);
		break;
	}
	return bVal;
}


A3DEffect* A3DEffect::CreateHLSLShader(A3DDevice* pA3DDevice, const char* pszTextureFile, const char* pszHLSLFile)
{
	A3DEffect* pHLSLShader = NULL;

	char szMtlFile[MAX_PATH];
	strncpy(szMtlFile, pszTextureFile, MAX_PATH);
	//PathRenameExtensionA(szMtlFile, ".mtl");
	af_ChangeFileExt(szMtlFile, MAX_PATH, ".mtl");
	A3DTextureMan* pTextureMan = pA3DDevice->GetA3DEngine()->GetA3DTextureMan();

	pTextureMan->LoadTextureFromFile(szMtlFile, (A3DTexture**)&pHLSLShader, A3DTF_CREATEHLSLSHADER);

	if( ! pHLSLShader->Init(pA3DDevice) )
	{
		g_A3DErrLog.Log("A3DEffect::CreateHLSLShader, Can not init mtl.");
		goto FAILED_RET;
	}

	if( ! pHLSLShader->LoadFromFile(pA3DDevice, pszTextureFile, pszTextureFile) )
	{
		g_A3DErrLog.Log("A3DEffect::CreateHLSLShader, can't load texture(%s).", pszTextureFile);
		goto FAILED_RET;
	}

	if( ! pHLSLShader->SetHLSL(pszHLSLFile))
	{
		g_A3DErrLog.Log("A3DEffect::CreateHLSLShader, can't load hlsl(%s), maybe has some errors in it.", pszHLSLFile);
		goto FAILED_RET;
	}
	return pHLSLShader;

FAILED_RET:
	pTextureMan->ReleaseTexture(((A3DTexture*&)pHLSLShader));
	return NULL;
}

bool A3DEffect::SetHLSL(const char* pszHLSLFile)
{
	A3DHLSLMan* pHLSLMan = m_pA3DDevice->GetA3DEngine()->GetA3DHLSLMan();

	for(SamplerDescArray::iterator it = m_aSampDesc.begin();
		it != m_aSampDesc.end(); ++it)	{
			if(it->pTexture != this)
				m_pA3DDevice->GetA3DEngine()->GetA3DTextureMan()->ReleaseTexture(it->pTexture);
	}
	m_aSampDesc.clear();
	if(m_pHLSL != NULL) {
		pHLSLMan->ReleaseShader(m_pHLSL);
	}

	if(af_CheckFileExt(pszHLSLFile, ".obj")) {
		m_pHLSL = pHLSLMan->LoadShader(pszHLSLFile, NULL);
	}
	else {
		m_pHLSL = pHLSLMan->LoadShader(NULL, NULL, pszHLSLFile, "ps_main", NULL, NULL);
	}

	if(m_pHLSL == NULL)
	{
		g_A3DErrLog.Log("A3DEffect::SetHLSL, can't load hlsl(%s).", pszHLSLFile);
		return false;
	}

	m_pHLSL->SetCommConstDesc(s_aSkinRenderCommConst, g_cbSizeOfSkinRenderCommConst);

	const A3DHLSL::CONSTMAPDESC* pConstName = m_pHLSL->GetConstMapArray();
	int nCount = m_pHLSL->GetConstCount();
	for(int i = 0; i < nCount; i++)
	{
		const A3DHLSL::CONSTMAPDESC& cmd = pConstName[i];

		if(cmd.cd.cd.RegisterSet == D3DXRS_SAMPLER)
		{
			SAMPLER_DESC SampDesc;

			// ����Sampler�е�����Ϊԭ����
			SampDesc.strName = cmd.cd.cd.Name;
			SampDesc.pTexture = this;
			m_aSampDesc.push_back(SampDesc);
			m_pHLSL->SetTexture(SampDesc.strName, SampDesc.pTexture);

			// ��ѯ Annotation �Ƿ�������������,��������滻
			A3DHLSLCore* pCore = m_pHLSL->GetCore();
			A3DHLSLCore::LPCCONSTANTDESC pConstDesc = pCore->GetConstDescByName(SampDesc.strName);
			if(pConstDesc != NULL)
			{
				A3DHLSLCore::LPCSAMPLER_STATE pSamplerState = pCore->GetSamplerState(pConstDesc->cd.RegisterIndex);
				if(pSamplerState != NULL)
				{
					SetTextureByName(SampDesc.strName, pSamplerState->strDefault);
				}
			}
			//const A3DHLSL::ANNOTATION* pAnno = m_pHLSL->FindAnnotationByName(SampDesc.strName, "Texture");
			//if(pAnno != NULL && pAnno->Type == D3DXPT_STRING)
			//{
			//	pAnno = m_pHLSL->FindAnnotationByName((const char*)pAnno->pData, "UIObject");
			//	if(pAnno != NULL && pAnno->Type == D3DXPT_STRING)
			//	{
			//		SetTextureByName(SampDesc.strName, (const char*)pAnno->pData);
			//	}
			//}
		}
	}
	return true;
}

bool A3DEffect::Appear(const A3DCOMMCONSTTABLE* lpCommConstTable)
{
	if(m_pHLSL != NULL)
	{
		m_pHLSL->Appear(lpCommConstTable);
		return true;
	}
	return false;
}

bool A3DEffect::Appear(int nLayer)
{
	if(m_pHLSL != NULL)
	{
		m_pHLSL->Appear(NULL);
		return true;
	}
	return false;
}

bool A3DEffect::Disappear(int nLayer)
{
	m_pA3DDevice->ClearVertexShader();
	m_pA3DDevice->ClearPixelShader();
	return true;
}

A3DTexture* A3DEffect::GetTextureByName(const char* pszName) const
{
	for(SamplerDescArray::const_iterator it = m_aSampDesc.begin();
		it != m_aSampDesc.end(); ++it)	
	{
		if(stricmp(pszName, it->strName) == 0)
		{
			return it->pTexture;
		}
	}
	return NULL;
}

bool A3DEffect::SetTextureByName(const char* pszName, const char* pszFilename)
{
	A3DTexture* pNewTexture;
	A3DTextureMan* pA3DTextureMan = m_pA3DDevice->GetA3DEngine()->GetA3DTextureMan();
	AString strFilename;

	if( PathIsFileSpecA(pszFilename) )
	{
		char buffer[MAX_PATH];
		af_GetFilePath(GetMtlFilename(), buffer, MAX_PATH);
		af_GetFullPath(strFilename, buffer, pszFilename);
	}
	else
		strFilename = pszFilename;

	if(pA3DTextureMan->LoadTextureFromFile(strFilename, (A3DTexture**)&pNewTexture, A3DTF_DONOTLOADASSHADER) == false)
	{
		g_A3DErrLog.Log("A3DEffect::SetTextureByName, Can not load texture(%s).", strFilename);
		return false;
	}

	for(SamplerDescArray::iterator it = m_aSampDesc.begin();
		it != m_aSampDesc.end(); ++it)	
	{
		if(stricmp(pszName, it->strName) == 0)
		{
			if(it->pTexture != this)
				pA3DTextureMan->ReleaseTexture(it->pTexture);

			it->pTexture = pNewTexture;
			m_pHLSL->SetTexture(pszName, pNewTexture);
			return true;
		}
	}

	// û���ҵ���������, ����ж�Ӧ�����������ӵ��б���
	if(m_pHLSL->SetTexture(pszName, pNewTexture) == true)
	{
		SAMPLER_DESC SampDesc;
		SampDesc.strName = pszName;
		SampDesc.pTexture = pNewTexture;
		m_aSampDesc.push_back(SampDesc);
		return true;
	}

	pA3DTextureMan->ReleaseTexture(pNewTexture);
	return false;
}

AString A3DEffect::GetMtlFilename()
{
	char buffer[MAX_PATH];
	strncpy(buffer, m_strMapFile, MAX_PATH);
	//PathRenameExtensionA(buffer, ".mtl");
	af_ChangeFileExt(buffer, MAX_PATH, ".mtl");
	return AString(buffer);
}

AString A3DEffect::GetHLSLFilename()
{
	AString strFilename;
	if(m_pHLSL != NULL && m_pHLSL->GetCore() != NULL)
	{
		A3DHLSLMan::ParseName(m_pHLSL->GetCore()->GetName(), NULL, NULL, &strFilename, NULL, NULL);
	}
	return strFilename;
}
bool A3DEffect::GenerateParam(ParamArray& aParam)
{
	if(m_pHLSL == NULL)
	{
		return false;
	}

	aParam.clear();
	int nCount = m_pHLSL->GetConstCount();
	const A3DHLSL::CONSTMAPDESC* pConstDesc = m_pHLSL->GetConstMapArray();
	for(int i = 0; i < nCount; i++)
	{
		MTLPARAM Param;
		Param.strKey = pConstDesc[i].cd.cd.Name;
		GetValueByString(pConstDesc[i], Param.strValue);
		aParam.push_back(Param);
	}
	return true;
}

IDirect3DBaseTexture9* A3DEffect::GetD3DBaseTexture() const
{
	return m_pDXTexture;
}