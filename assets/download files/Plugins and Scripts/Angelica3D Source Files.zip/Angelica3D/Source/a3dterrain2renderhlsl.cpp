/*
* FILE: A3DTerrain2RenderHLSL.cpp
*
* DESCRIPTION: terrain 2 render function with HLSL method
*
* CREATED BY: Zhangyachuan (zhangyachuan000899@wanmei.com), 2012/2/13
*
* HISTORY: 
*
* Copyright (c) 2012 Archosaur Studio, All Rights Reserved.
*/

#include "A3DPlatform.h"
#include "A3DTerrain2.h"
#include "A3DTerrain2Render.h"
#include "A3DHLSL.h"
#include "A3DDevice.h"
#include "A3DEngine.h"
#include "A3DTerrain2Blk.h"
#include "A3DTerrain2Env.h"
#include "A3DViewport.h"
#include "A3DVertexShader.h"
#include "A3DTexture.h"
#include "A3DCameraBase.h"
#include "A3DPI.h"

///////////////////////////////////////////////////////////////////////////
//	
//	Define and Macro
//	
///////////////////////////////////////////////////////////////////////////

#define new A_DEBUG_NEW

///////////////////////////////////////////////////////////////////////////
//	
//	Reference to External variables and functions
//	
///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////
//	
//	Local Types and Variables and Global variables
//	
///////////////////////////////////////////////////////////////////////////

template <int LAYERNUM>
class TerrainMtlParams
{
public:
	
	TerrainMtlParams(A3DTerrain2Render* pTrnRender)
		: m_pTrnRender(pTrnRender)
		, m_pBlackTex(pTrnRender->GetBlackTex())
		, m_fDNFactor(pTrnRender->GetTerrain()->GetDNFactor())
	{
		memset(m_aEnableFlags, 0, sizeof(m_aEnableFlags));
		memset(m_aProjAxis, 0, sizeof(m_aProjAxis));
		memset(m_aScaleU, 0, sizeof(m_aScaleU));
		memset(m_aScaleV, 0, sizeof(m_aScaleV));
		memset(m_aTextures, 0, sizeof(m_aTextures));
		memset(m_aDNLightMaps, 0, sizeof(m_aDNLightMaps));
	}

	bool Init(A3DTerrain2Mask* pMask);
	bool Fill(A3DHLSL* pShader);

private:

	void UpdateShaderParam3f(A3DHLSL* pHLSL, const char* szName, const float* aParams)
	{
		A3DVECTOR3 v(aParams[0], aParams[1], aParams[2]);
		pHLSL->SetValue3f(szName, &v);
	}

private:
	
	A3DTerrain2Render* m_pTrnRender;
	A3DTexture* m_pBlackTex;
	float m_fDNFactor;
	float m_aEnableFlags[LAYERNUM];
	float m_aProjAxis[LAYERNUM];
	float m_aScaleU[LAYERNUM];
	float m_aScaleV[LAYERNUM];
	A3DTexture* m_aTextures[LAYERNUM];
	A3DTexture* m_aMaskTexs[LAYERNUM / 3];
	A3DTexture* m_aDNLightMaps[2];

};

template <int LAYERNUM>
bool TerrainMtlParams<LAYERNUM>::Init(A3DTerrain2Mask* pMask)
{
	int iLayerCnt = a_Min(pMask->GetLayerNum(), LAYERNUM);

	for (int i = 0; i < LAYERNUM; ++i)
	{
		m_aProjAxis[i] = 0.0f;
		m_aScaleU[i] = m_aScaleV[i] = 1.0f;

		if (i >= iLayerCnt)
		{
			m_aEnableFlags[i] = 0.0f;
			m_aTextures[i] = m_pBlackTex;
			continue;
		}

		const A3DTerrain2Mask::LAYER& layer = pMask->GetLayer(i);
		m_aProjAxis[i] = layer.byProjAxis;
		m_aScaleU[i] = layer.fUScale;
		m_aScaleV[i] = layer.fVScale;
		m_aEnableFlags[i] = 1.0f;
		m_aTextures[i] = pMask->GetTexture(i);
	}

	int iMaskNum = LAYERNUM / 3;
	for (int i = 0; i < iMaskNum; ++i)
	{
		m_aMaskTexs[i] = pMask->GetMaskTexture(i);
	}

	if (m_pTrnRender->GetTerrain()->GetLightEnableFlag())
	{
		m_aDNLightMaps[0] = pMask->GetLightMap(true);
		m_aDNLightMaps[1] = pMask->GetLightMap(false);
	}
	else
	{
		m_aDNLightMaps[0] = m_aDNLightMaps[1] = A3D::g_pA3DTerrain2Env->GetWhiteTexture();
	}

	a_Swap(m_aEnableFlags[0], m_aEnableFlags[2]);

	if (LAYERNUM > 3)
		a_Swap(m_aEnableFlags[3], m_aEnableFlags[5]);

	return true;
}

template <int LAYERNUM>
bool TerrainMtlParams<LAYERNUM>::Fill(A3DHLSL* pShader)
{
	AString strSampler;
	for (int i = 0; i < LAYERNUM; ++i)
	{
		strSampler.Format("g_BaseSampler%d", i);
		pShader->SetTexture(strSampler, m_aTextures[i]);
	}

	pShader->SetValue1f("g_DNFactor", m_fDNFactor);
	UpdateShaderParam3f(pShader, "g_vProjAxis0", m_aProjAxis);
	UpdateShaderParam3f(pShader, "g_LayerEnableFlags0", m_aEnableFlags);
	UpdateShaderParam3f(pShader, "g_vScaleU0", m_aScaleU);
	UpdateShaderParam3f(pShader, "g_vScaleV0", m_aScaleV);

	for (int i = 0; i < _countof(m_aMaskTexs); ++i)
	{
		strSampler.Format("g_MaskMapSampler%d", i);
		pShader->SetTexture(strSampler, m_aMaskTexs[i]);
	}

	pShader->SetTexture("g_LMDaySampler", m_aDNLightMaps[0]);
	pShader->SetTexture("g_LMNightSampler", m_aDNLightMaps[1]);

	if (LAYERNUM > 3)
	{
		UpdateShaderParam3f(pShader, "g_vProjAxis1", m_aProjAxis + 3);
		UpdateShaderParam3f(pShader, "g_LayerEnableFlags1", m_aEnableFlags + 3);
		UpdateShaderParam3f(pShader, "g_vScaleU1", m_aScaleU + 3);
		UpdateShaderParam3f(pShader, "g_vScaleV1", m_aScaleV + 3);
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////
//	
//	Local functions
//	
///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////
//	
//	Implement A3DTerrain2Render
//	
///////////////////////////////////////////////////////////////////////////

//	Render routine using ps 2.0 hlsl and lightmap
bool A3DTerrain2Render::Render_PS20_LM(A3DViewport* pViewport)
{
	using namespace A3D;

	A3DVertexDecl* pDecl = g_pA3DTerrain2Env->GetVertexDecl();
	if (!pDecl)
		return false;

	if (!m_aCurSlots.GetSize())
		return true;

	SyncLastRenderSlots();

	m_pA3DDevice->SetLightingEnable(true);
	m_pA3DDevice->SetSpecularEnable(true);
	m_pA3DDevice->SetSourceAlpha(A3DBLEND_ONE);
	m_pA3DDevice->SetDestAlpha(A3DBLEND_INVSRCALPHA);

	APtrArray<A3DTrn2RenderSlot*> a3LayerSlots;
	APtrArray<A3DTrn2RenderSlot*> a6LayerSlots;
	for (int i = 0; i < m_aCurSlots.GetSize(); ++i)
	{
		if (m_aCurSlots[i]->GetSortLayerNum() <= 3)
			a3LayerSlots.Add(m_aCurSlots[i]);
		else if (m_aCurSlots[i]->GetSortLayerNum() <= 6)
			a6LayerSlots.Add(m_aCurSlots[i]);
		else
		{
			// do not render ? ... or take them as 6 layer slot ?
			a6LayerSlots.Add(m_aCurSlots[i]);
		}
	}

	m_pA3DDevice->SetTextureAddress(0, A3DTADDR_WRAP, A3DTADDR_WRAP);
	m_pA3DDevice->SetTextureAddress(1, A3DTADDR_WRAP, A3DTADDR_WRAP);
	m_pA3DDevice->SetTextureAddress(2, A3DTADDR_WRAP, A3DTADDR_WRAP);
	m_pA3DDevice->SetTextureAddress(3, A3DTADDR_CLAMP, A3DTADDR_CLAMP);
	m_pA3DDevice->SetTextureAddress(4, A3DTADDR_CLAMP, A3DTADDR_CLAMP);
	m_pA3DDevice->SetTextureAddress(5, A3DTADDR_CLAMP, A3DTADDR_CLAMP);
	for (int i = 0; i < 9; ++i)
	{
		m_pA3DDevice->SetTextureCoordIndex(i, i);
		m_pA3DDevice->SetTextureFilterType(i, A3DTEXF_LINEAR);
		m_pA3DDevice->SetTextureTransformFlags(i, A3DTTFF_DISABLE);
	}

	for (int i = 0; i < a3LayerSlots.GetSize(); ++i)
	{
		RenderSlot_PS20_LM<3>(pViewport, a3LayerSlots[i], g_pA3DTerrain2Env->GetHLSL3LayersLM());
	}

	m_pA3DDevice->SetTextureAddress(3, A3DTADDR_WRAP, A3DTADDR_WRAP);
	m_pA3DDevice->SetTextureAddress(4, A3DTADDR_WRAP, A3DTADDR_WRAP);
	m_pA3DDevice->SetTextureAddress(5, A3DTADDR_WRAP, A3DTADDR_WRAP);
	m_pA3DDevice->SetTextureAddress(6, A3DTADDR_CLAMP, A3DTADDR_CLAMP);
	m_pA3DDevice->SetTextureAddress(7, A3DTADDR_CLAMP, A3DTADDR_CLAMP);
	m_pA3DDevice->SetTextureAddress(8, A3DTADDR_CLAMP, A3DTADDR_CLAMP);
	m_pA3DDevice->SetTextureAddress(9, A3DTADDR_CLAMP, A3DTADDR_CLAMP);

	for (int i = 0; i < a6LayerSlots.GetSize(); ++i)
	{
		RenderSlot_PS20_LM<6>(pViewport, a6LayerSlots[i], g_pA3DTerrain2Env->GetHLSL6LayersLM());
	}

	//	Restore render states
	m_pA3DDevice->ClearPixelShader();
	m_pA3DDevice->ClearVertexShader();
	m_pA3DDevice->SetZWriteEnable(true);
	m_pA3DDevice->SetLightingEnable(true);
	m_pA3DDevice->SetSpecularEnable(true);
	m_pA3DDevice->SetSourceAlpha(A3DBLEND_SRCALPHA);
	m_pA3DDevice->SetDestAlpha(A3DBLEND_INVSRCALPHA);
	m_pA3DDevice->ClearTexture(0);
	m_pA3DDevice->ClearTexture(1);
	m_pA3DDevice->ClearTexture(2);
	m_pA3DDevice->ClearTexture(3);
	m_pA3DDevice->ClearTexture(4);
	m_pA3DDevice->ClearTexture(5);
	m_pA3DDevice->ClearTexture(6);
	m_pA3DDevice->ClearTexture(7);
	m_pA3DDevice->ClearTexture(8);
	m_pA3DDevice->ClearTexture(9);

	return true;
}

template <int LAYERCNTONEPASS>
bool A3DTerrain2Render::RenderSlot_PS20_LM(A3DViewport* pViewport, A3DTrn2RenderSlot* pSlot, A3DHLSL* pHLSL)
{
	using namespace A3D;

	A3DTerrain2Mask* pMask = m_pTerrain->GetMaskArea(pSlot->m_iMaskIdx);
	if (!pMask)
		return true;

	D3DXPLANE cp;
	{
		DWORD dwState = m_pA3DDevice->GetDeviceRenderState(D3DRS_CLIPPLANEENABLE);
		if( dwState == D3DCLIPPLANE0 ) // only one clip plane supported now
		{
			D3DXPLANE hcp;
			m_pA3DDevice->GetClipPlane(0, (float *)&cp);
			A3DMATRIX4 matVP = pViewport->GetCamera()->GetVPTM();
			matVP.InverseTM();
			matVP.Transpose();
			D3DXPlaneTransform(&hcp, &cp, (D3DXMATRIX *) &matVP);
			m_pA3DDevice->SetClipPlane(0, hcp);
		}
	}

	g_pA3DTerrain2Env->GetVertexDecl()->Appear();

	const A3DMaterial& trnMaterial = m_pTerrain->GetTerrainMaterial();
	pHLSL->SetValue3f("g_vecMainLightDir", &m_pTerrain->GetMainLightParam().Direction);
	pHLSL->SetValue3f("g_vecEyePos", &pViewport->GetCamera()->GetPos());
	pHLSL->SetValue4f("g_colMtlDiffuse", (const A3DVECTOR4*)&trnMaterial.GetDiffuse());
	pHLSL->SetValue4f("g_colMtlSpecular", (const A3DVECTOR4*)&trnMaterial.GetSpecular());
	pHLSL->SetValue1f("g_fSpecPower", trnMaterial.GetPower());
	A3DMATRIX4 matVP = m_pA3DDevice->GetViewMatrix() * m_pA3DDevice->GetProjectionMatrix();
	pHLSL->SetConstantMatrix("g_matViewProjection", matVP);

	int iStartLayer = 0;
	int iLayerCnt = a_Min(pMask->GetLayerNum(), LAYERCNTONEPASS);
	if (iLayerCnt)
	{
		//	Render primitives
		TerrainMtlParams<LAYERCNTONEPASS> mtlParams(this);
		mtlParams.Init(pMask);
		mtlParams.Fill(pHLSL);

		pHLSL->Appear();
		//	Render
		pSlot->DrawAllBlocks(false);
	}

	{
		DWORD dwState = m_pA3DDevice->GetDeviceRenderState(D3DRS_CLIPPLANEENABLE);
		if( dwState == D3DCLIPPLANE0 ) // only one clip plane supported now
		{
			m_pA3DDevice->SetClipPlane(0, cp);
		}
	}

	return true;
}
