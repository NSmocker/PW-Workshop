#include "A3D.h"
#include "A3DHLSL.h"
#include "A3DPI.h"
#include "AFI.h"
#include "AFilePackage.h"
#include "AFileImage.h"
#include "A3DFuncs.h"
#include <Shlwapi.h>

#define HLSLCORE_VERSION_001	0x10000001
#define SAFE_RELEASE(p)	if((p) != NULL){ (p)->Release(); p = NULL; }
#define CACHEDIR "Shaders\\2.2\\HLSL"
const char* szCachePath = CACHEDIR"\\HLSL.Cache";
static char s_szEffectSupplyVS[] = "						\
struct ___VS_INPUT{	float4 vPosition : POSITION;};		\
struct ___VS_OUTPUT{ float4 Position : POSITION;};		\
___VS_OUTPUT vs_main(___VS_INPUT Input){				\
	___VS_OUTPUT Output;								\
	Output.Position = Input.vPosition;					\
	return Output;	}\r\n";
static char s_szEffectSupplyTech[] = "\r\n				\
technique ___TechBasic {								\
	pass P0	{											\
		VertexShader = compile vs_3_0 vs_main();		\
		PixelShader  = compile ps_3_0 ps_main();		\
	}}";

typedef abase::hash_map<AString, DWORD> Text2EnumDict;

static Text2EnumDict* s_pText2EnumDict = NULL;

// BuildConstDict �ı�־λ
#define BCD_ADDCONSTNAME      0x00000001
#define BCD_ADDSEMANTIC       0x00000002
#define BCD_CLEARBEFOREBUILD  0x00000100
#define BCD_ALL               (BCD_CLEARBEFOREBUILD | BCD_ADDCONSTNAME | BCD_ADDSEMANTIC)


struct HLSLCOREHEADER
{
	DWORD cbSize;
	DWORD dwVersion;
	DWORD dwID;
	DWORD cbVSFunc;
	DWORD cbPSFunc;
	DWORD nSemaCount;
	DWORD nMaxSamplerUsed; // m_nMaxSamplerIdx
};

struct HLSLMANHEADER
{
	DWORD cbSize;
	DWORD dwShaderCount;
	DWORD dwRefFileCount;
};

A3DHLSLInclude::A3DHLSLInclude(A3DHLSLCore* pHLSL)
: m_pHLSL(pHLSL)
{
}

A3DHLSLInclude::~A3DHLSLInclude()
{
}

bool A3DHLSLInclude::Init()
{
	m_strSystemDir = AString(af_GetBaseDir()) + "\\shaders\\2.2\\";
	m_strLocalDir = m_strSystemDir;
	return true;
}
bool A3DHLSLInclude::Release()
{
	return true;
}

void A3DHLSLInclude::SetDir(D3DXINCLUDE_TYPE IncludeType, const AString& strDir)
{
	if(IncludeType == D3DXINC_LOCAL)
		m_strLocalDir = strDir;
	else if(IncludeType == D3DXINC_SYSTEM)
		m_strSystemDir = strDir;
}

abase::vector<AString>* A3DHLSLInclude::GetIncludeFiles()
{
	return &m_aIncludeFiles;
}

HRESULT A3DHLSLInclude::Open(THIS_ D3DXINCLUDE_TYPE IncludeType, LPCSTR pFileName, LPCVOID pParentData, LPCVOID *ppData, UINT *pBytes)
{
	char szAbsPath[MAX_PATH];
	char szWholePath[MAX_PATH];
	
	if(IncludeType == D3DXINC_LOCAL)
		PathCombineA(szWholePath, m_strLocalDir, pFileName);
	else if(IncludeType == D3DXINC_SYSTEM)
		PathCombineA(szWholePath, m_strSystemDir, pFileName);

	char* pSlash;
	while((pSlash = strchr(szWholePath, '/')) != NULL)
	{
		*pSlash = '\\';
	}

	PathCanonicalizeA(szAbsPath, szWholePath);

	AFileImage file;
	if(file.Open(szAbsPath, AFILE_BINARY | AFILE_OPENEXIST) == true)
	{
		DWORD dwLen = file.GetFileLength();
		BYTE* pData = new BYTE[dwLen];
		DWORD dwRead;
		file.Read(pData, dwLen, &dwRead);

		*ppData = pData;
		*pBytes = dwRead;

		m_aIncludeFiles.push_back(szAbsPath);
		return S_OK;
	}
	return MK_E_CANTOPENFILE;
}

HRESULT A3DHLSLInclude::Close(THIS_ LPCVOID pData)
{
	delete pData;
	return S_OK;
}
//////////////////////////////////////////////////////////////////////////
A3DHLSLCore::A3DHLSLCore(A3DDevice* pA3DDevice, A3DHLSLMan* pHLSLMgr)
: m_pDevice				(pA3DDevice)
, m_pHLSLMgr			(pHLSLMgr)
, m_pVertexShader		(NULL)
, m_pPixelShader		(NULL)
, m_pVertexConstants	(NULL)
, m_pPixelConstants		(NULL)
, m_nRefCount			(NULL)
, m_lpVShaderFunc		(NULL)
, m_lpPShaderFunc		(NULL)
, m_dwID				(NULL)
, m_pName2AnnoDict		(NULL)
, m_nMaxSamplerIdx		(0)
{
	m_dwClassID = A3D_CID_HLSLCORE;
	for(int i = 0; i < MAX_SAMPLERCOUNT; i++)
	{
		m_aSampState[i].Cleanup();
	}
}

A3DHLSLCore::~A3DHLSLCore()
{
}

bool A3DHLSLCore::Init()
{
	return true;
}

int A3DHLSLCore::AddRef()
{
	return ++m_nRefCount;
}

int A3DHLSLCore::Release()
{
	ASSERT(m_nRefCount >= 0);
	if(m_nRefCount == 0)
		return 0;
	m_nRefCount--;
	if(m_nRefCount == 0)
	{
		Cleanup();
		return 0;
	}
	return m_nRefCount;
}

void A3DHLSLCore::Cleanup()
{
	m_NameSemaToConstDict.clear();
	m_aConst.clear();
	if(m_pName2AnnoDict != NULL)
	{
		Name2AnnoDict::iterator it = m_pName2AnnoDict->begin();
		for(; it != m_pName2AnnoDict->end(); ++it)
		{
			AnnotationArray& aAnno = *it->second;
			for(AnnotationArray::iterator itAnno = aAnno.begin();
				itAnno != aAnno.end(); ++itAnno)
			{
				if(itAnno->pData != NULL)
				{
					delete itAnno->pData;
				}
			}
			delete it->second;
		}
		delete m_pName2AnnoDict;
		m_pName2AnnoDict = NULL;
	}
	SAFE_RELEASE(m_lpVShaderFunc);
	SAFE_RELEASE(m_lpPShaderFunc);
	SAFE_RELEASE(m_pVertexShader);
	SAFE_RELEASE(m_pPixelShader);
	SAFE_RELEASE(m_pVertexConstants);
	SAFE_RELEASE(m_pPixelConstants);
}

bool A3DHLSLCore::CreateShader(LPD3DXBUFFER lpVSFunc, LPD3DXBUFFER lpPSFunc)
{
	LPDIRECT3DDEVICE9 pd3dDevice = m_pDevice->GetD3DDevice();
	bool bval = true;
	if(lpVSFunc != NULL && FAILED(pd3dDevice->CreateVertexShader((DWORD*)lpVSFunc->GetBufferPointer(), &m_pVertexShader)))
	{
		g_A3DErrLog.Log("Failed to create vertex shader.");
		bval = false;
		ASSERT(0);
	}

	if(lpPSFunc != NULL && FAILED(pd3dDevice->CreatePixelShader((DWORD*)lpPSFunc->GetBufferPointer(), &m_pPixelShader)))
	{
		g_A3DErrLog.Log("Failed to create pixel shader.");
		bval = false;
		ASSERT(0);
	}
	return bval;
}

bool A3DHLSLCore::LoadFromMemory(const BYTE* pszVSCode, size_t uVSCodeLen, const D3DXMACRO* pVSMacro, A3DHLSLInclude* pVSInclude, const char* szVSFuncName, 
							 const BYTE* pszPSCode, size_t uPSCodeLen, const D3DXMACRO* pPSMacro, A3DHLSLInclude* pPSInclude, const char* szPSFuncName)
{
	LPD3DXBUFFER lpErrorBuffer = NULL;
	LPD3DXEFFECT lpD3DXEffect = NULL;
	LPD3DXBUFFER lpEffectErrorBuffer = NULL;
	LPDIRECT3DDEVICE9 pd3dDevice = m_pDevice->GetD3DDevice();
	bool bval = true;

	Cleanup();
	
	ASSERT(m_aConst.size() == 0);
	ASSERT(m_NameSemaToConstDict.size() == 0);
	ASSERT(m_pName2AnnoDict == NULL || m_pName2AnnoDict->size() == 0);

	if(pszVSCode != NULL && uVSCodeLen != 0)
	{
		m_strVSFuncName = szVSFuncName ? szVSFuncName : "vs_main";
		if(FAILED(D3DXCompileShader((LPCSTR)pszVSCode, uVSCodeLen, pVSMacro, pVSInclude, m_strVSFuncName, 
			D3DXGetVertexShaderProfile(pd3dDevice), NULL, &m_lpVShaderFunc,
			&lpErrorBuffer, &m_pVertexConstants)) )
		{
			g_A3DErrLog.Log("Failed to compile vertex shader:\n%s\n", lpErrorBuffer->GetBufferPointer());
			m_pHLSLMgr->AppendErrorMsg(GetName(), true);
			m_pHLSLMgr->AppendErrorMsg((const char*)lpErrorBuffer->GetBufferPointer());
			bval = false;
		}
		SAFE_RELEASE(lpErrorBuffer);
	}
	if(pszPSCode != NULL && uPSCodeLen != 0)
	{
		m_strPSFuncName = szPSFuncName ? szPSFuncName : "ps_main";
		if(FAILED(D3DXCompileShader((LPCSTR)pszPSCode, uPSCodeLen, pPSMacro, pPSInclude, m_strPSFuncName, 
			D3DXGetPixelShaderProfile(pd3dDevice), NULL, &m_lpPShaderFunc,
			&lpErrorBuffer, &m_pPixelConstants)) )
		{
			g_A3DErrLog.Log("Failed to compile pixel shader:\n%s\n", lpErrorBuffer->GetBufferPointer());
			if(pszVSCode == NULL)
			{
				m_pHLSLMgr->AppendErrorMsg(GetName(), true);
			}
			m_pHLSLMgr->AppendErrorMsg((const char*)lpErrorBuffer->GetBufferPointer());
			bval = false;
		}
		SAFE_RELEASE(lpErrorBuffer);
	}

	if(m_lpPShaderFunc != NULL)
	{
		BYTE* pszEffectCode = NULL;
		UINT uSrcLen = 0;
		if(m_lpVShaderFunc == NULL)
		{
			uSrcLen = uPSCodeLen + sizeof(s_szEffectSupplyVS) + sizeof(s_szEffectSupplyTech) + 32;
			pszEffectCode = new BYTE[uSrcLen];
			memcpy(pszEffectCode, s_szEffectSupplyVS, sizeof(s_szEffectSupplyVS));
			memcpy(pszEffectCode + sizeof(s_szEffectSupplyVS) - 1, pszPSCode, uPSCodeLen);
			memcpy(pszEffectCode + sizeof(s_szEffectSupplyVS) - 1 + uPSCodeLen, s_szEffectSupplyTech, sizeof(s_szEffectSupplyTech));
		}
		else
		{
			uSrcLen = uVSCodeLen + uPSCodeLen + sizeof(s_szEffectSupplyTech) + 32;
			pszEffectCode = new BYTE[uSrcLen];
			memcpy(pszEffectCode, pszVSCode, uVSCodeLen);
			memcpy(pszEffectCode + uVSCodeLen, pszPSCode, uPSCodeLen);
			memcpy(pszEffectCode + uVSCodeLen + uPSCodeLen, s_szEffectSupplyTech, sizeof(s_szEffectSupplyTech));
		}
		
		if(FAILED(D3DXCreateEffect(pd3dDevice, pszEffectCode, uSrcLen, pPSMacro, 
			pPSInclude, NULL, NULL, &lpD3DXEffect, &lpEffectErrorBuffer)))
		{
			g_A3DErrLog.Log("Failed to compile effect, you will not get annotation for the shader.");
			m_pHLSLMgr->AppendErrorMsg((const char*)lpEffectErrorBuffer->GetBufferPointer());
		}

		if(pszEffectCode != NULL)
		{
			delete pszEffectCode;
			pszEffectCode = NULL;
		}
	}


	if(bval == true)
		bval = CreateShader(m_lpVShaderFunc, m_lpPShaderFunc);

	if(bval == true)
	{
		abase::vector<AString>* pArray = NULL;
		if(pVSInclude != NULL)
		{
			pArray = pVSInclude->GetIncludeFiles();
			for(abase::vector<AString>::iterator it = pArray->begin();
				it != pArray->end(); ++it)
			{
				m_pHLSLMgr->RegisterRefFile(*it);
			}
		}
		if(pPSInclude != NULL)
		{
			pArray = pPSInclude->GetIncludeFiles();
			for(abase::vector<AString>::iterator it = pArray->begin();
				it != pArray->end(); ++it)
			{
				m_pHLSLMgr->RegisterRefFile(*it);
			}
		}
	}

	GenConstTable(m_pVertexConstants, true);
	GenConstTable(m_pPixelConstants, false);

	if(lpD3DXEffect != NULL)
	{		
		GenAnnoAndSema(lpD3DXEffect);
	}
	BuildConstDict(BCD_ALL);
	GenSamplerState();
	SAFE_RELEASE(lpD3DXEffect);
	SAFE_RELEASE(lpEffectErrorBuffer);
	return bval;
}

bool A3DHLSLCore::LoadFromFile(AFile* pVSFile, AFile* pPSFile, const D3DXMACRO* pMacro, A3DHLSLInclude* pVSInclude, const char* szVSFuncName, A3DHLSLInclude* pPSInclude, const char* szPSFuncName)
{
	BYTE* pVSCodes = NULL;
	DWORD dwVSSize = 0;
	BYTE* pPSCodes = NULL;
	DWORD dwPSSize = 0;
	DWORD dwRead = 0;
	A3DHLSLInclude* pMyVSInclude = NULL;
	A3DHLSLInclude* pMyPSInclude = NULL;

	if(pVSFile != NULL)
	{
		dwVSSize = pVSFile->GetFileLength();
		pVSCodes = new BYTE[dwVSSize];

		pVSFile->Read(pVSCodes, dwVSSize, &dwRead);
	}
	if(pPSFile != NULL)
	{
		dwPSSize = pPSFile->GetFileLength();
		pPSCodes = new BYTE[dwPSSize];

		pPSFile->Read(pPSCodes, dwPSSize, &dwRead);
	}
	char buffer[MAX_PATH];
	if(pVSInclude == NULL && pVSFile != NULL)
	{
		strncpy(buffer, pVSFile->GetFileName(), MAX_PATH);
		PathRemoveFileSpecA(buffer);
		pMyVSInclude = new A3DHLSLInclude(this);
		pMyVSInclude->Init();
		pMyVSInclude->SetDir(D3DXINC_LOCAL, buffer);
		pVSInclude = pMyVSInclude;
	}

	if(pPSInclude == NULL && pPSFile != NULL)
	{
		strncpy(buffer, pPSFile->GetFileName(), MAX_PATH);
		PathRemoveFileSpecA(buffer);
		pMyPSInclude = new A3DHLSLInclude(this);
		pMyPSInclude->Init();
		pMyPSInclude->SetDir(D3DXINC_LOCAL, buffer);
		pPSInclude = pMyPSInclude;
	}

	bool bval = LoadFromMemory(pVSCodes, dwVSSize, pMacro, pVSInclude, szVSFuncName, pPSCodes, dwPSSize, pMacro, pPSInclude, szPSFuncName);

	A3DRELEASE(pMyVSInclude);
	A3DRELEASE(pMyPSInclude);

	delete pVSCodes;
	delete pPSCodes;

	return bval;
}

bool A3DHLSLCore::LoadFromFile(const char* pszVertexShaderFile, const char* pszPixelShaderFile, const D3DXMACRO* pMacro, A3DHLSLInclude* pVSInclude, const char* szVSFuncName, A3DHLSLInclude* pPSInclude, const char* szPSFuncName)
{
	AFileImage fileVS, filePS;
	bool bVS = pszVertexShaderFile 
		? fileVS.Open(pszVertexShaderFile, AFILE_BINARY | AFILE_OPENEXIST)
		: false;
	bool bPS = pszPixelShaderFile
		? filePS.Open(pszPixelShaderFile, AFILE_BINARY | AFILE_OPENEXIST)
		: false;
	if(bVS == false && bPS == false)
	{
		if(pszVertexShaderFile != NULL)
			g_A3DErrLog.Log("A3DHLSLCore::LoadFromFile, can not find file: %s", pszVertexShaderFile);
		if(pszPixelShaderFile != NULL)
			g_A3DErrLog.Log("A3DHLSLCore::LoadFromFile, can not find file: %s", pszPixelShaderFile);
		return false;
	}

	return LoadFromFile(bVS ? &fileVS : NULL, bPS ? &filePS : NULL, pMacro, pVSInclude, szVSFuncName, pPSInclude, szPSFuncName);
}

bool A3DHLSLCore::Save(AFile* pFile)
{
	DWORD          dwLength;
	HLSLCOREHEADER Header;
	//SYSTEMTIME     SystemTime;
	Header.cbSize          = sizeof(HLSLCOREHEADER);
	Header.dwVersion       = HLSLCORE_VERSION_001;
	Header.dwID            = m_dwID;
	Header.cbVSFunc        = m_lpVShaderFunc ? m_lpVShaderFunc->GetBufferSize() : 0;
	Header.cbPSFunc        = m_lpPShaderFunc ? m_lpPShaderFunc->GetBufferSize() : 0;
	Header.nSemaCount      = GetSemaCount();
	Header.nMaxSamplerUsed = m_nMaxSamplerIdx + 1;

	//GetSystemTime(&SystemTime);
	
	pFile->Write(&Header, sizeof(Header), &dwLength);
	pFile->WriteString(m_strName);

	if(m_lpVShaderFunc != NULL)
		pFile->Write(m_lpVShaderFunc->GetBufferPointer(), m_lpVShaderFunc->GetBufferSize(), &dwLength);

	if(m_lpPShaderFunc != NULL)
		pFile->Write(m_lpPShaderFunc->GetBufferPointer(), m_lpPShaderFunc->GetBufferSize(), &dwLength);

	// �������
	for(ConstArray::iterator it = m_aConst.begin();
		it != m_aConst.end(); ++it)
	{
		if(it->Semantic.GetLength() > 0)
		{
			pFile->WriteString(it->cd.Name);
			pFile->WriteString(it->Semantic);
		}
	}

	// ������״̬
	for(UINT i = 0; i <= m_nMaxSamplerIdx; i++)
	{
		pFile->Write(&m_aSampState[i], sizeof(DWORD) * 14, &dwLength);
		pFile->WriteString(m_aSampState[i].strDefault);
	}

	return true;
}

bool A3DHLSLCore::Load(AFile* pFile)
{
	Cleanup();

	AString strName;
	AString strSemantic;
	HLSLCOREHEADER Header;
	DWORD          dwLength;
	pFile->Read(&Header.cbSize, sizeof(Header.cbSize), &dwLength);
	pFile->Read(((BYTE*)&Header.cbSize) + sizeof(Header.cbSize), Header.cbSize - sizeof(Header.cbSize), &dwLength);

	if(Header.dwVersion != HLSLCORE_VERSION_001)
	{
		ASSERT(0);
		goto FAILED_RET;
	}
	// TODO: �Ϸ�����֤

	pFile->ReadString(m_strName);
	m_dwID = a_MakeIDFromString(m_strName);

	if(Header.cbVSFunc != 0)
	{
		D3DXCreateBuffer(Header.cbVSFunc, &m_lpVShaderFunc);
		pFile->Read(m_lpVShaderFunc->GetBufferPointer(), Header.cbVSFunc, &dwLength);
		D3DXGetShaderConstantTable((DWORD*)m_lpVShaderFunc->GetBufferPointer(), &m_pVertexConstants);

	}
	if(Header.cbPSFunc != 0)
	{
		D3DXCreateBuffer(Header.cbPSFunc, &m_lpPShaderFunc);
		pFile->Read(m_lpPShaderFunc->GetBufferPointer(), Header.cbPSFunc, &dwLength);
		D3DXGetShaderConstantTable((DWORD*)m_lpPShaderFunc->GetBufferPointer(), &m_pPixelConstants);
	}

	bool bval = CreateShader(m_lpVShaderFunc, m_lpPShaderFunc);

	if( ! bval)
	{
		g_A3DErrLog.Log("Failed to create HLSL.");
		goto FAILED_RET;
	}

	GenConstTable(m_pVertexConstants, true);
	GenConstTable(m_pPixelConstants, false);

	BuildConstDict(BCD_ADDCONSTNAME);

	for(DWORD i = 0; i < Header.nSemaCount; i++)
	{
		pFile->ReadString(strName);
		pFile->ReadString(strSemantic);

		ConstDict::iterator it = m_NameSemaToConstDict.find(strName);
		if(it == m_NameSemaToConstDict.end())
		{
			g_A3DErrLog.Log("A3DHLSLCore::Load, semantic table does not match the const record");
			goto FAILED_RET;
		}
		ASSERT(it->second->Semantic.GetLength() == 0);
		it->second->Semantic = strSemantic;
	}

	// ������״̬
	m_nMaxSamplerIdx = Header.nMaxSamplerUsed;
	for(UINT i = 0; i <= m_nMaxSamplerIdx; i++)
	{
		pFile->Read(&m_aSampState[i], sizeof(DWORD) * 14, &dwLength);
		pFile->ReadString(m_aSampState[i].strDefault);
	}
	// ���
	for(UINT i = m_nMaxSamplerIdx + 1; i < MAX_SAMPLERCOUNT; i++)
	{
		m_aSampState[i].Cleanup();
	}

	BuildConstDict(BCD_ADDSEMANTIC);
	return true;

FAILED_RET:
	Cleanup();
	return false;
}

void A3DHLSLCore::BuildConstDict(DWORD dwFlags)
{
	if(dwFlags & BCD_CLEARBEFOREBUILD) {
		m_NameSemaToConstDict.clear();
	}

	for(ConstArray::iterator itArray = m_aConst.begin();
		itArray != m_aConst.end(); ++itArray)
	{
		if(dwFlags & BCD_ADDCONSTNAME)
		{
			ConstDict::iterator itDict = m_NameSemaToConstDict.find(itArray->cd.Name);
			if(itDict != m_NameSemaToConstDict.end())
			{
				itDict->second->bUnique = false;
				itArray->bUnique = false;
				m_NameSemaToConstDict[AString("@") + itArray->cd.Name] = &(*itArray);
			}
			else
			{
				//m_ConstNameDict[cd.cd.Name] = cd;
				m_NameSemaToConstDict[itArray->cd.Name] = &(*itArray);
			}
		}
		else if(dwFlags & BCD_ADDSEMANTIC)
		{
			if(itArray->Semantic.GetLength() > 0)
			{
				m_NameSemaToConstDict[AString(":") + itArray->Semantic] = &(*itArray);
			}
		}
	}
}
void A3DHLSLCore::GetDefaultTexturePath(const char* szTextureName, AString& strPath)
{
	Name2AnnoDict::iterator itAnno = m_pName2AnnoDict->find(szTextureName);
	if(itAnno != m_pName2AnnoDict->end())
	{
		AnnotationArray& aAnno = *itAnno->second;
		for(AnnotationArray::iterator itAnnoElement = aAnno.begin(); 
			itAnnoElement != aAnno.end(); ++itAnnoElement)
		{
			if(itAnnoElement->Name == "UIObject" && 
				itAnnoElement->Type == D3DXPT_STRING && 
				itAnnoElement->pData != NULL)
			{
				strPath = (const char*)itAnnoElement->pData;
				break;
			}
		}
	}
}
void A3DHLSLCore::GenSamplerState()
{
	if(m_pName2AnnoDict == NULL) {
		return;
	}
	m_nMaxSamplerIdx = 0;

	for(ConstArray::iterator it = m_aConst.begin();
		it != m_aConst.end(); ++it)
	{
		if(it->cd.Class == D3DXPC_OBJECT)
		{
			ASSERT(it->cd.Type == D3DXPT_SAMPLER || it->cd.Type == D3DXPT_SAMPLER1D || 
				it->cd.Type == D3DXPT_SAMPLER2D || it->cd.Type == D3DXPT_SAMPLER3D);
			SAMPLER_STATE* pSamplerState = &m_aSampState[it->cd.RegisterIndex];

			Name2AnnoDict::iterator itAnno = m_pName2AnnoDict->find(it->cd.Name);
			if(itAnno != m_pName2AnnoDict->end())
			{
				ASSERT(m_aSampState[it->cd.RegisterIndex].SampStateMask == 0);
				m_nMaxSamplerIdx = a_Max(m_nMaxSamplerIdx, it->cd.RegisterIndex);
				AnnotationArray& aAnno = *itAnno->second;
				for(AnnotationArray::iterator itAnnoElement = aAnno.begin(); 
					itAnnoElement != aAnno.end(); ++itAnnoElement)
				{
					if(itAnnoElement->Type != D3DXPT_STRING)
					{
						continue;
					}
					AString strName = itAnnoElement->Name;
					AString strValue = (const char*)itAnnoElement->pData;
					strName.MakeUpper();
					D3DSAMPLERSTATETYPE eType = D3DSAMP_FORCE_DWORD;
					DWORD Value = D3DTADDRESS_FORCE_DWORD;
					Text2EnumDict::iterator itEnum = s_pText2EnumDict->find(strName);
					if(itEnum == s_pText2EnumDict->end())
					{
						if(strName == "TEXTURE")
						{
							GetDefaultTexturePath(strValue, pSamplerState->strDefault);
						}
						continue;
					}

					eType = (D3DSAMPLERSTATETYPE)itEnum->second;
					strValue.MakeUpper();
					switch(eType)
					{
					case D3DSAMP_ADDRESSU:
					case D3DSAMP_ADDRESSV:
					case D3DSAMP_ADDRESSW:
						{
							itEnum = s_pText2EnumDict->find(strValue);
							if(itEnum == s_pText2EnumDict->end())
							{
								eType = D3DSAMP_FORCE_DWORD;
								break;
							}
							Value = itEnum->second;
							if(Value > D3DTADDRESS_MIRRORONCE)
							{
								eType = D3DSAMP_FORCE_DWORD;
							}
						}
						break;

					//case dwBORDERCOLOR:
					//	break;
					case D3DSAMP_MAGFILTER:
					case D3DSAMP_MINFILTER:
					case D3DSAMP_MIPFILTER:
						{
							itEnum = s_pText2EnumDict->find(strValue);
							if(itEnum == s_pText2EnumDict->end())
							{
								eType = D3DSAMP_FORCE_DWORD;
								break;
							}
							Value = itEnum->second;
							if(Value > D3DTEXF_CONVOLUTIONMONO)
							{
								eType = D3DSAMP_FORCE_DWORD;
							}
						}
						break;
					//case dwMIPMAPLODBIAS:
					//case dwMAXMIPLEVEL:
					//case dwMAXANISOTROPY:
					//case dwSRGBTEXTURE:
					//case dwELEMENTINDEX:
					//case dwDMAPOFFSET:
					default:
						eType = D3DSAMP_FORCE_DWORD;
						break;
					}
					if(eType != D3DSAMP_FORCE_DWORD) {
						pSamplerState->SetState(eType, Value);
					}					
				}
			} // if(itAnno != m_pName2AnnoDict->end())
		}
	}
}

int A3DHLSLCore::GetSemaCount()		// �õ���Semantic��const����
{
	int nSema = 0;
	for(ConstArray::iterator it = m_aConst.begin();
		it != m_aConst.end(); ++it)
	{
		if(it->Semantic.GetLength() > 0)
		{
			nSema++;
		}
	}
	return nSema;
}

void A3DHLSLCore::Transfer(A3DHLSLCore& Src)
{
	m_pDevice          = Src.m_pDevice;
	m_nRefCount        = Src.m_nRefCount;
	m_dwID             = Src.m_dwID;
	m_pHLSLMgr         = Src.m_pHLSLMgr;
	m_pVertexShader    = Src.m_pVertexShader;
	m_pPixelShader     = Src.m_pPixelShader;
	//m_pVertexConstants = Src.m_pVertexConstants;
	//m_pPixelConstants  = Src.m_pPixelConstants;
	m_lpVShaderFunc    = Src.m_lpVShaderFunc;
	m_lpPShaderFunc    = Src.m_lpPShaderFunc;
	m_pName2AnnoDict   = Src.m_pName2AnnoDict;
	m_aConst           = Src.m_aConst;
	m_nMaxSamplerIdx   = Src.m_nMaxSamplerIdx;
	m_strVSFuncName    = Src.m_strVSFuncName;
	m_strPSFuncName    = Src.m_strPSFuncName;

	for(int i = 0; i < MAX_SAMPLERCOUNT; i++)
	{
		m_aSampState[i] = Src.m_aSampState[i];
		Src.m_aSampState[i].Cleanup();
	}
	m_NameSemaToConstDict.clear();
}

bool A3DHLSLCore::Rebuild()
{
	AString strVSFile;
	AString strPSFile;
	AString strMacro;
	AString strVSFuncName;
	AString strPSFuncName;
	
	A3DHLSLMan::ParseName(m_strName, &strVSFile, &strVSFuncName, &strPSFile, &strPSFuncName, &strMacro);

	A3DHLSLMan::MacroArray		aMacros;
	A3DHLSLMan::D3DXMacroArray	aD3DXMacros;

	A3DHLSLMan::ParseMacroArgument(strMacro, aMacros);
	A3DHLSLMan::BuildD3DMacro(aMacros, aD3DXMacros);

	A3DHLSLCore Backup(m_pDevice, m_pHLSLMgr);
	Backup.Transfer(*this);

	m_pVertexShader    = NULL;
	m_pPixelShader     = NULL;
	//m_pVertexConstants = NULL;
	//m_pPixelConstants  = NULL;
	m_lpVShaderFunc    = NULL;
	m_lpPShaderFunc    = NULL;
	m_pName2AnnoDict   = NULL;
	//m_strVSFuncName.Empty();
	//m_strPSFuncName.Empty();

	bool bval = LoadFromFile(
		strVSFile.GetLength() == 0 ? NULL : strVSFile,
		strPSFile.GetLength() == 0 ? NULL : strPSFile,
		&aD3DXMacros.front(), NULL, m_strVSFuncName, NULL, m_strPSFuncName);

	if(bval == false)
	{
		Cleanup();
		this->Transfer(Backup);
		BuildConstDict(BCD_ALL);
	}
	else
	{
		Backup.Cleanup();
	}
	return bval;
}

bool A3DHLSLCore::GenConstTable(ID3DXConstantTable* pD3DXConstTabel, /*CONSTREGCONTEXT* pContext, */bool bVertexShader)
{
	if(pD3DXConstTabel == NULL)
		return false;

	D3DXCONSTANTTABLE_DESC ctd;
	pD3DXConstTabel->GetDesc(&ctd);
	unsigned int nTopIndex = m_aConst.size();

	typedef abase::vector<D3DXCONSTANT_DESC> D3DConstDescArray;
	D3DConstDescArray aConstDesc;

	for(UINT i = 0; i < ctd.Constants; i++)
	{
		D3DXCONSTANT_DESC d3dcd;
		UINT nCount = 0;
		D3DXHANDLE hHandle = pD3DXConstTabel->GetConstant(NULL, i);
		pD3DXConstTabel->GetConstantDesc(hHandle, &d3dcd, &nCount);

		D3DConstDescArray::iterator it = aConstDesc.begin();
		for(;it != aConstDesc.end(); ++it)
		{
			int a = (it->RegisterSet == D3DXRS_SAMPLER ? 0 : 100) + it->RegisterIndex;
			int b = (d3dcd.RegisterSet == D3DXRS_SAMPLER ? 0 : 100) + d3dcd.RegisterIndex;
			if(a > b)
			{
				aConstDesc.insert(it, d3dcd);
				break;
			}
		}
		if(it == aConstDesc.end())
		{
			aConstDesc.push_back(d3dcd);
		}
	}
	ASSERT((UINT)aConstDesc.size() == ctd.Constants);

	for(UINT i = 0; i < ctd.Constants; i++)
	{
		CONSTANTDESC cd;
		UINT nCount = 0;
		//D3DXHANDLE hHandle = pD3DXConstTabel->GetConstant(NULL, i);
		//pD3DXConstTabel->GetConstantDesc(hHandle, &cd.cd, &nCount);
		//cd.uMemberOffset = -1;
		cd.cd = aConstDesc[i];
		cd.bVertexShader = bVertexShader;
		cd.dwNameID      = a_MakeIDFromString(cd.cd.Name);
		cd.nIdx          = nTopIndex++;
		cd.bUnique       = true;

		m_aConst.push_back(cd);
	}
	return true;
}

bool A3DHLSLCore::GenAnnoAndSema(LPD3DXEFFECT lpD3DXEffect)
{
	ASSERT(lpD3DXEffect != NULL);
	ASSERT(m_pName2AnnoDict == NULL);

	m_pName2AnnoDict = new Name2AnnoDict;

	D3DXEFFECT_DESC d3ded;
	lpD3DXEffect->GetDesc(&d3ded);
	for(UINT i = 0; i < d3ded.Parameters; i++)
	{
		D3DXHANDLE hHandle = lpD3DXEffect->GetParameter(NULL, i);
		D3DXPARAMETER_DESC d3dxpd;
		lpD3DXEffect->GetParameterDesc(hHandle, &d3dxpd);

		// ����������Ϣ
		if(d3dxpd.Semantic != NULL)
		{
			for(ConstArray::iterator it = m_aConst.begin();
				it != m_aConst.end(); ++it)
			{
				if(strcmp(it->cd.Name, d3dxpd.Name) == 0)
				{
					it->Semantic = d3dxpd.Semantic;
					break;
				}
			}
		}

		// ����Annotation��Ϣ.
		if(d3dxpd.Annotations > 0)
		{
			AnnotationArray* pAnnotation = new AnnotationArray;
			ANNOTATION annot;
			for(UINT n = 0; n < d3dxpd.Annotations; n++)
			{
				D3DXPARAMETER_DESC d3dxad;
				D3DXHANDLE hAnnotation = lpD3DXEffect->GetAnnotation(hHandle, n);

				lpD3DXEffect->GetParameterDesc(hAnnotation, &d3dxad);
				annot.Type       = d3dxad.Type;
				annot.Class      = d3dxad.Class;
				annot.Name       = d3dxad.Name;
				annot.cbDateSize = d3dxad.Bytes;
				annot.pData      = NULL;
				switch(d3dxad.Type)
				{
				case D3DXPT_STRING:
					{
						LPCSTR lpString;
						lpD3DXEffect->GetString(hAnnotation, &lpString);
						annot.cbDateSize = strlen(lpString) + 1;
						annot.pData = new char[annot.cbDateSize];
						strncpy((LPSTR)annot.pData, lpString, annot.cbDateSize);
					}
					break;
				case D3DXPT_INT:
					{
						if(d3dxad.Class == D3DXPC_SCALAR)
						{
							ASSERT(annot.cbDateSize == sizeof(int));
							lpD3DXEffect->GetInt(hAnnotation, &annot.nValue);
						}
						else if(d3dxad.Class == D3DXPC_VECTOR)
						{
							const UINT Count = annot.cbDateSize / sizeof(int);
							annot.pData = new int[Count];
							lpD3DXEffect->GetIntArray(hAnnotation, (INT*)annot.pData, Count);
						}
						else
						{
							// FIXME: ûʵ��
							ASSERT(0);
						}
					}
					break;
				case D3DXPT_FLOAT:
					{
						if(d3dxad.Class == D3DXPC_SCALAR)
						{
							ASSERT(annot.cbDateSize == sizeof(float));
							lpD3DXEffect->GetFloat(hAnnotation, &annot.fValue);
						}
						else
						{
							// FIXME: ûʵ��
							ASSERT(0);
						}
					}
					break;
				default:
					ASSERT(0);
					break;
				}
				pAnnotation->push_back(annot);
			}
			(*m_pName2AnnoDict)[d3dxpd.Name] = pAnnotation;
		} // if(d3dxpd.Annotations > 0)
	}
	return true;
}

bool A3DHLSLCore::Appear()
{
	if(m_pVertexShader == NULL && m_pPixelShader == NULL)
		return false;

	LPDIRECT3DDEVICE9 pd3dDevice = m_pDevice->GetD3DDevice();
	for(UINT i = 0; i <= m_nMaxSamplerIdx; i++)
	{
		LPCSAMPLER_STATE pSampState = &m_aSampState[i];
		if(pSampState->SampStateMask == 0)
			continue;
		for(int n = 1; n <= 13; n++)
		{
			if(pSampState->SampStateMask & (1 << n))
			{
				HRESULT hval = pd3dDevice->SetSamplerState(i, 
					(D3DSAMPLERSTATETYPE)n, pSampState->SampState[n - 1]);
				ASSERT(SUCCEEDED(hval));
			}
		}
	}

	return (
		(m_pVertexShader 
		? SUCCEEDED(pd3dDevice->SetVertexShader(m_pVertexShader)) 
		: true ) &&
		(m_pPixelShader
		? SUCCEEDED(pd3dDevice->SetPixelShader(m_pPixelShader))
		: true));
}

bool A3DHLSLCore::Disappear()
{
	if(m_pVertexShader != NULL)
		m_pDevice->ClearVertexShader();
	if(m_pPixelShader != NULL)
		m_pDevice->ClearPixelShader();
	return true;
}

void A3DHLSLCore::SetName(const char* szName)
{
	m_dwID = a_MakeIDFromString(szName);
	A3DObject::SetName(szName);
}

//////////////////////////////////////////////////////////////////////////
A3DHLSL::CONSTREGCONTEXT::CONSTREGCONTEXT() 
: nMin(0xffff)
, nMax(0)
, pConstBuffer(NULL)
{}
A3DHLSL::CONSTREGCONTEXT::~CONSTREGCONTEXT()
{
	if(pConstBuffer != NULL)
	{
		delete pConstBuffer;
		pConstBuffer = NULL;
	}
}

void A3DHLSL::CONSTREGCONTEXT::Build()
{
	ASSERT(pConstBuffer == NULL);
	if(nMin < nMax)
	{
		pConstBuffer = new A3DVECTOR4[nMax];
		memset(pConstBuffer, 0, sizeof(A3DVECTOR4) * nMax);
	}
}


A3DHLSL::A3DHLSL(A3DHLSLCore* pCore)
	: m_pCore				(pCore)
	, m_cbConstTableSize	(NULL)
	, m_lpCommConstDesc		(NULL)
	//, m_eVertType			(A3DVT_UNKNOWN)
	, m_aConstName			(NULL)
{
	m_dwClassID = A3D_CID_HLSL;
	memset(m_aSamplerSlot, 0, sizeof(m_aSamplerSlot));
	m_pCore->AddRef();
}

A3DHLSL::~A3DHLSL()
{
}

bool A3DHLSL::Init()
{
	//m_ConstNameDict.clear();
	if(m_aConstName != NULL)
	{
		delete[] m_aConstName;
		m_aConstName = NULL;
	}
	GenConstBuffer(&m_VertexRegContext, true);
	GenConstBuffer(&m_PixelRegContext, false);
	SetCommConstDesc(NULL, 0);
	return true;
}

bool A3DHLSL::Release()
{
	if(m_aConstName != NULL)
	{
		delete[] m_aConstName;
		m_aConstName = NULL;
	}
	m_pCore->Release();
	return true;
}

bool A3DHLSL::Relink()
{
	m_VertexRegContext.~CONSTREGCONTEXT();
	m_PixelRegContext.~CONSTREGCONTEXT();
	GenConstBuffer(&m_VertexRegContext, true);
	GenConstBuffer(&m_PixelRegContext, false);
	SetCommConstDesc(NULL, m_cbConstTableSize);
	return true;
}

bool A3DHLSL::SetCommConstDesc(A3DCOMMONCONSTDESC* lpCommConstDesc, int cbTable)
{
	if(lpCommConstDesc == NULL)
		lpCommConstDesc = m_lpCommConstDesc;

	//if(lpCommConstDesc == NULL)
	//	return false;

	if(m_aConstName != NULL)
	{
		delete[] m_aConstName;
		m_aConstName = NULL;
	}

	// ������������õ�
	//for(ConstMapArray::iterator it = m_aConstName.begin();
	//	it != m_aConstName.end(); ++it)
	int nCount = GetConstCount();
	m_aConstName = new CONSTMAPDESC[nCount];

	//for(int i = 0; i < nCount; i++)

	ConstArray aConst = m_pCore->GetConstArray();
	for(ConstArray::iterator it = aConst.begin();
		it != aConst.end(); ++it)
	{
		CONSTMAPDESC& cmd = m_aConstName[it->nIdx];
		A3DHLSLCore::CONSTANTDESC& cd = cmd.cd;
		cmd.uMemberOffset = -1;
		cmd.cd = *it;

		if(lpCommConstDesc != NULL)
		{
			for(int i = 0;; i++)
			{
				if(lpCommConstDesc[i].szConstName == NULL)
					break;

				if(strcmp(cd.cd.Name, lpCommConstDesc[i].szConstName) == 0 &&
					(cd.cd.Bytes == lpCommConstDesc[i].cbSize || 
					(cd.cd.RegisterSet == D3DXRS_SAMPLER && lpCommConstDesc[i].cbSize == A3DCOMMONCONSTDESC::CCD_SAMPLER) ) )
				{
					if(cbTable == 0)
					{
						lpCommConstDesc[i].nRef--;
						ASSERT(lpCommConstDesc[i].nRef >= 0);
					}
					else
					{
						cmd.uMemberOffset = lpCommConstDesc[i].uMemberOffset;
						lpCommConstDesc[i].nRef++;
					}
					// ����break,��Ϊ�������ͬʱ������VertexShader��PixelShader��Constant, ��������Shader�������constant
				}
			}
		}
	}
	m_lpCommConstDesc = lpCommConstDesc;
	m_cbConstTableSize = cbTable;
	return true;
}

bool A3DHLSL::Appear(const A3DCOMMCONSTTABLE* lpCommConstTable /* = NULL */)
{
	A3DDevice* pDevice = m_pCore->GetA3DDevice();
	LPDIRECT3DDEVICE9 pd3dDevice = pDevice->GetD3DDevice();
	pDevice->SetHLSLShader(this);

	if( lpCommConstTable != APPEAR_SETSHADERONLY )
	{
		int nCount = GetConstCount();
		//for(ConstMapArray::iterator it = m_aConstName.begin();
		//	it != m_aConstName.end(); ++it)
		for(int i = 0; i < nCount; i++)
		{
			CONSTMAPDESC& cmd = m_aConstName[i];
			A3DHLSLCore::CONSTANTDESC& cd = cmd.cd;

			if(cmd.uMemberOffset >= 0 && lpCommConstTable != NULL)
			{
				LPVOID* ppParam = (LPVOID*)(((BYTE*)lpCommConstTable) + cmd.uMemberOffset);
				if(cd.cd.RegisterSet == D3DXRS_SAMPLER)
				{
					pd3dDevice->SetTexture(cd.cd.RegisterIndex, (IDirect3DBaseTexture9*)(*ppParam));
				}
				else if(cd.cd.RegisterSet == D3DXRS_FLOAT4)
				{
					if( cd.bVertexShader )
						pd3dDevice->SetVertexShaderConstantF(cd.cd.RegisterIndex, (const float*)(ppParam), cd.cd.RegisterCount);
					else
						pd3dDevice->SetPixelShaderConstantF(cd.cd.RegisterIndex, (const float*)(ppParam), cd.cd.RegisterCount);
				}
				else if(cd.cd.RegisterSet == D3DXRS_INT4)
				{
					if( cd.bVertexShader )
						pd3dDevice->SetVertexShaderConstantI(cd.cd.RegisterIndex, (const int*)(ppParam), cd.cd.RegisterCount);
					else
						pd3dDevice->SetPixelShaderConstantI(cd.cd.RegisterIndex, (const int*)(ppParam), cd.cd.RegisterCount);
				}
				else if(cd.cd.RegisterSet == D3DXRS_BOOL)
				{
					g_A3DErrLog.Log("A3DHLSL::Appear, unsupport RegisterSet == D3DXRS_BOOL.");
				}
				else
				{
					g_A3DErrLog.Log("A3DHLSL::Appear, invalidate RegisterSet.");
				}
			}
			else
			{
				if(cd.cd.RegisterSet == D3DXRS_SAMPLER)
				{
					pd3dDevice->SetTexture(cd.cd.RegisterIndex, m_aSamplerSlot[cd.cd.RegisterIndex].pTextureBase);
				}
				else if(cd.cd.RegisterSet == D3DXRS_FLOAT4)
				{
					if( cd.bVertexShader )
						pd3dDevice->SetVertexShaderConstantF(
						cd.cd.RegisterIndex, (const float*)(&m_VertexRegContext.pConstBuffer[cd.cd.RegisterIndex]), cd.cd.RegisterCount);
					else
						pd3dDevice->SetPixelShaderConstantF(
						cd.cd.RegisterIndex, (const float*)(&m_PixelRegContext.pConstBuffer[cd.cd.RegisterIndex]), cd.cd.RegisterCount);
				}
				else if(cd.cd.RegisterSet == D3DXRS_INT4)
				{
					if( cd.bVertexShader )
						pd3dDevice->SetVertexShaderConstantI(
						cd.cd.RegisterIndex, (const int*)(&m_VertexRegContext.pConstBuffer[cd.cd.RegisterIndex]), cd.cd.RegisterCount);
					else
						pd3dDevice->SetPixelShaderConstantI(
						cd.cd.RegisterIndex, (const int*)(&m_PixelRegContext.pConstBuffer[cd.cd.RegisterIndex]), cd.cd.RegisterCount);
				}
				else if(cd.cd.RegisterSet == D3DXRS_BOOL)
				{
					g_A3DErrLog.Log("A3DHLSL::Appear, unsupport RegisterSet == D3DXRS_BOOL.");
				}
				else
				{
					g_A3DErrLog.Log("A3DHLSL::Appear, invalidate RegisterSet.");
				}
			}
		}
	}

	return m_pCore->Appear();
}

bool A3DHLSL::Disappear()
{
	return m_pCore->Disappear();
}
bool A3DHLSL::SubmitCommTable(const A3DCOMMCONSTTABLE* lpCommConstTable)
{
	A3DDevice* pDevice = m_pCore->GetA3DDevice();
	LPDIRECT3DDEVICE9 pd3dDevice = pDevice->GetD3DDevice();

	if( lpCommConstTable != APPEAR_SETSHADERONLY )
	{
		int nCount = GetConstCount();
		for(int i = 0; i < nCount; i++)
		{
			CONSTMAPDESC& cmd = m_aConstName[i];
			A3DHLSLCore::CONSTANTDESC& cd = cmd.cd;

			if(cmd.uMemberOffset >= 0 && lpCommConstTable != NULL)
			{
				LPVOID* ppParam = (LPVOID*)(((BYTE*)lpCommConstTable) + cmd.uMemberOffset);
				if(cd.cd.RegisterSet == D3DXRS_SAMPLER)
				{
					pd3dDevice->SetTexture(cd.cd.RegisterIndex, (IDirect3DBaseTexture9*)(*ppParam));
				}
				else if(cd.cd.RegisterSet == D3DXRS_FLOAT4)
				{
					if( cd.bVertexShader )
						pd3dDevice->SetVertexShaderConstantF(cd.cd.RegisterIndex, (const float*)(ppParam), cd.cd.RegisterCount);
					else
						pd3dDevice->SetPixelShaderConstantF(cd.cd.RegisterIndex, (const float*)(ppParam), cd.cd.RegisterCount);
				}
				else if(cd.cd.RegisterSet == D3DXRS_INT4)
				{
					if( cd.bVertexShader )
						pd3dDevice->SetVertexShaderConstantI(cd.cd.RegisterIndex, (const int*)(ppParam), cd.cd.RegisterCount);
					else
						pd3dDevice->SetPixelShaderConstantI(cd.cd.RegisterIndex, (const int*)(ppParam), cd.cd.RegisterCount);
				}
				else if(cd.cd.RegisterSet == D3DXRS_BOOL)
				{
					g_A3DErrLog.Log("A3DHLSL::SubmitCommTable, unsupport RegisterSet == D3DXRS_BOOL.");
				}
				else
				{
					g_A3DErrLog.Log("A3DHLSL::SubmitCommTable, invalidate RegisterSet.");
				}
			}
		}
	}
	return true;
}
bool A3DHLSL::SetValue1f(const char* szName, const float fConstant)
{
	A3DVECTOR4 v((float)0);
	v.x = fConstant;
	return SetConstantArrayF(szName, &v, 1);
}

bool A3DHLSL::SetValue2f(const char* szName, const float fConstant1, const float fConstant2)
{
	A3DVECTOR4 v((float)0);
	v.x = fConstant1;
	v.y = fConstant2;
	return SetConstantArrayF(szName, &v, 1);
}

bool A3DHLSL::SetValue3f(const char* szName, const A3DVECTOR3* pConstant)
{
	A3DVECTOR4 v(*pConstant);
	return SetConstantArrayF(szName, &v, 1);
}

bool A3DHLSL::SetValue4f(const char* szName, const A3DVECTOR4* pConstant)
{
	return SetConstantArrayF(szName, pConstant, 1);
}

bool A3DHLSL::SetConstantArrayF(const char* szName, const A3DVECTOR4* pConstant, int nFloat4Count)
{
	LPDIRECT3DDEVICE9 pd3dDevice = m_pCore->GetA3DDevice()->GetD3DDevice();
	bool bRet = false;

	ConstDict& sConstNameDict = m_pCore->GetConstDict();
	ConstDict::iterator it = sConstNameDict.find(AString(szName));
	if(it == sConstNameDict.end())
		return false;

UPDATE_SHADER_CACHE:
	CONSTMAPDESC& cmd = m_aConstName[it->second->nIdx];
	A3DHLSLCore::CONSTANTDESC& cd = *(it->second);

	if(cmd.uMemberOffset < 0 && nFloat4Count == cd.cd.RegisterCount)
	{
		if(cd.cd.RegisterSet == D3DXRS_FLOAT4 || cd.cd.RegisterSet == D3DXRS_INT4)
		{
			bRet = true;
			if( cd.bVertexShader )
			{
				memcpy(&m_VertexRegContext.pConstBuffer[cd.cd.RegisterIndex], pConstant, cd.cd.RegisterCount * sizeof(A3DVECTOR4));
			}
			else
			{
				memcpy(&m_PixelRegContext.pConstBuffer[cd.cd.RegisterIndex], pConstant, cd.cd.RegisterCount * sizeof(A3DVECTOR4));
			}
		}
		else if(cd.cd.RegisterSet == D3DXRS_BOOL)
		{
			g_A3DErrLog.Log("A3DHLSL::SetConstantArrayF, unsupport RegisterSet == D3DXRS_BOOL.");
		}
		else
		{
			g_A3DErrLog.Log("A3DHLSL::SetConstantArrayF, invalidate RegisterSet.");
			return false;
		}
	}

	if(cd.bUnique == false && it->first[0] != '@')
	{
		it = sConstNameDict.find(AString("@") + szName);
		if(it == sConstNameDict.end() || it->second->bUnique != false)
		{
			ASSERT(0);	// ��Ӧ�ó��������Ĵ���.
			return false;
		}
		goto UPDATE_SHADER_CACHE;
	}

	return bRet;
}
bool A3DHLSL::GetConstantArrayF(const char* szName, A3DVECTOR4* pConstant, int nFloat4Count)
{
	LPDIRECT3DDEVICE9 pd3dDevice = m_pCore->GetA3DDevice()->GetD3DDevice();
	DWORD dwNameID = a_MakeIDFromString(szName);
	bool bRet = false;

	A3DHLSLCore::ConstDict& sConstNameDict = m_pCore->GetConstDict();
	A3DHLSLCore::ConstDict::iterator it = sConstNameDict.find(szName);

	if(it == sConstNameDict.end())
		return false;

	CONSTMAPDESC& cmd = m_aConstName[it->second->nIdx];
	A3DHLSLCore::CONSTANTDESC& cd = *(it->second);

	if(cmd.uMemberOffset < 0 && cd.dwNameID == dwNameID && nFloat4Count == cd.cd.RegisterCount)
	{
		if(cd.cd.RegisterSet == D3DXRS_FLOAT4 || cd.cd.RegisterSet == D3DXRS_INT4)
		{
			if( cd.bVertexShader )
			{
				memcpy(pConstant, &m_VertexRegContext.pConstBuffer[cd.cd.RegisterIndex], cd.cd.RegisterCount * sizeof(A3DVECTOR4));
				bRet = true;
			}
			else
			{
				memcpy(pConstant, &m_PixelRegContext.pConstBuffer[cd.cd.RegisterIndex], cd.cd.RegisterCount * sizeof(A3DVECTOR4));
				bRet = true;
			}
		}
		else if(cd.cd.RegisterSet == D3DXRS_BOOL)
		{
			g_A3DErrLog.Log("A3DHLSL::GetConstantArrayF, unsupport RegisterSet == D3DXRS_BOOL.");
		}
		else
		{
			g_A3DErrLog.Log("A3DHLSL::GetConstantArrayF, invalidate RegisterSet.");
			return false;
		}
	}

	return bRet;
}

bool A3DHLSL::ReloadTexture()
{
	for(int i = 0; i < MAX_SAMPLERCOUNT; i++)
	{
		if(m_aSamplerSlot[i].pA3DObject != NULL)
			m_aSamplerSlot[i].UpdateD3DTexPtr(m_aSamplerSlot[i].pA3DObject);
	}
	return true;
}

const A3DHLSL::ANNOTATION* A3DHLSL::FindAnnotationByName(const char* szName, const char* szAnnoName)
{
	typedef A3DHLSLCore::Name2AnnoDict Name2AnnoDict;
	typedef A3DHLSLCore::AnnotationArray AnnotationArray;
	
	Name2AnnoDict* pAnnoDict = m_pCore->GetAnnoDict();
	if(pAnnoDict == NULL)
	{
		return NULL;
	}

	Name2AnnoDict::iterator itAnnoArray = pAnnoDict->find(szName);
	if(itAnnoArray == pAnnoDict->end())
	{
		return NULL;
	}
	
	AnnotationArray& aAnno = *(itAnnoArray->second);
	AnnotationArray::iterator itAnno = aAnno.begin();
	for(; itAnno != aAnno.end(); ++itAnno)
	{
		if(itAnno->Name == szAnnoName)
		{
			return &(*itAnno);
		}
	}
	return NULL;
}

const A3DHLSL::CONSTMAPDESC* A3DHLSL::GetConstMapByName(const char* szName)
{
	ConstDict& sConstNameDict = m_pCore->GetConstDict();
	ConstDict::iterator it = sConstNameDict.find(AString(szName));
	if(it == sConstNameDict.end())
	{
		return NULL;
	}
	return &(m_aConstName[it->second->nIdx]);
}
bool A3DHLSL::SetConstantMatrix(const char* szName, const A3DMATRIX4& mat)
{
	A3DMATRIX4 matT = mat;
	matT.Transpose();
	return SetConstantArrayF(szName, (A3DVECTOR4*)&matT, 4);
}

bool A3DHLSL::SetTexture(const char* szName, A3DObject* pA3DObject)
{
	DWORD dwNameID = a_MakeIDFromString(szName);
	bool bRet = false;
	const DWORD dwClassID = pA3DObject == NULL 
		? A3D_CID_UNKNOWN 
		: pA3DObject->GetClassID();

	if( dwClassID != A3D_CID_TEXTURE2D &&
		dwClassID != A3D_CID_TEXTURE3D &&
		dwClassID != A3D_CID_TEXTURECUBE &&
		dwClassID != A3D_CID_RENDERTARGET && 
		dwClassID != A3D_CID_HLSLSHADER && 
		pA3DObject != NULL )
	{
		return false;
	}

	A3DHLSLCore::ConstDict& sConstNameDict = m_pCore->GetConstDict();
	A3DHLSLCore::ConstDict::iterator it = sConstNameDict.find(szName);

	if(it == sConstNameDict.end())
		return false;

	CONSTMAPDESC& cmd = m_aConstName[it->second->nIdx];
	A3DHLSLCore::CONSTANTDESC& cd = *(it->second);

	if( cmd.uMemberOffset < 0 && cd.dwNameID == dwNameID )
	{
		if(cd.cd.RegisterSet == D3DXRS_SAMPLER)
		{
			ASSERT(cd.cd.RegisterIndex < MAX_SAMPLERCOUNT);
			SAMPLERSLOT& SamplerSlot = m_aSamplerSlot[cd.cd.RegisterIndex];

			SamplerSlot.UpdateD3DTexPtr(pA3DObject);

			bRet = true;
		}
	}

	return bRet;
}

bool A3DHLSL::GenConstBuffer(CONSTREGCONTEXT* pContext, bool bVertexShader)
{
	A3DHLSLCore::ConstArray& aConst = m_pCore->GetConstArray();
	for(ConstArray::iterator it = aConst.begin();
		it != aConst.end(); ++it)
	{
		A3DHLSLCore::CONSTANTDESC& cd = *it;

		if(cd.bVertexShader == bVertexShader)
		{
			if(cd.cd.RegisterSet != D3DXRS_SAMPLER && cd.cd.RegisterSet != D3DXRS_BOOL)	// FIXME: ��֧��BOOL����
			{
				if((UINT)pContext->nMin > cd.cd.RegisterIndex)
					pContext->nMin = cd.cd.RegisterIndex;
				if((UINT)pContext->nMax < cd.cd.RegisterIndex + cd.cd.RegisterCount)
					pContext->nMax = cd.cd.RegisterIndex + cd.cd.RegisterCount;
			}
		}
	}


	//D3DXCONSTANTTABLE_DESC ctd;
	//pD3DXConstTabel->GetDesc(&ctd);
	//for(UINT i = 0; i < ctd.Constants; i++)
	//{
	//	CONSTANTDESC cd;
	//	UINT nCount = 0;
	//	D3DXHANDLE hHandle = pD3DXConstTabel->GetConstant(NULL, i);
	//	pD3DXConstTabel->GetConstantDesc(hHandle, &cd.cd, &nCount);
	//	cd.uMemberOffset = -1;
	//	cd.bVertexShader = bVertexShader;
	//	cd.dwNameID = a_MakeIDFromString(cd.cd.Name);
	//	cd.bUnique = true;

	//	ConstNameDict::iterator it = m_ConstNameDict.find(cd.cd.Name);
	//	if(it != m_ConstNameDict.end())
	//	{
	//		it->second.bUnique = false;
	//		cd.bUnique = false;
	//		m_ConstNameDict[AString("@") + cd.cd.Name] = cd;
	//	}
	//	else
	//	{
	//		m_ConstNameDict[cd.cd.Name] = cd;
	//	}

	//	if(cd.cd.RegisterSet != D3DXRS_SAMPLER && cd.cd.RegisterSet != D3DXRS_BOOL)	// FIXME: ��֧��BOOL����
	//	{
	//		if((UINT)pContext->nMin > cd.cd.RegisterIndex)
	//			pContext->nMin = cd.cd.RegisterIndex;
	//		if((UINT)pContext->nMax < cd.cd.RegisterIndex + cd.cd.RegisterCount)
	//			pContext->nMax = cd.cd.RegisterIndex + cd.cd.RegisterCount;
	//	}
	//}
	pContext->Build();

	// ����hlsl�ļ����Ĭ��ֵ��ʼ����������
	if(pContext->pConstBuffer != NULL)
	{
		for(ConstArray::iterator it = aConst.begin();
			it != aConst.end(); ++it)
		{
			A3DHLSLCore::CONSTANTDESC& cd = *it;
			if(cd.bVertexShader == bVertexShader &&
				cd.cd.DefaultValue != NULL &&
				(cd.cd.RegisterSet != D3DXRS_SAMPLER && cd.cd.RegisterSet != D3DXRS_BOOL))	// FIXME: ��֧��BOOL����
			{
				memcpy(
					cd.bVertexShader 
					? &pContext->pConstBuffer[cd.cd.RegisterIndex]
					: &m_PixelRegContext.pConstBuffer[cd.cd.RegisterIndex],
					cd.cd.DefaultValue, cd.cd.RegisterCount * sizeof(A3DVECTOR4));
			}
		}
	}
	return true;
}

//////////////////////////////////////////////////////////////////////////
A3DHLSLMan::A3DHLSLMan(A3DDevice* pA3DDevice)
	: m_pDevice			(pA3DDevice)
	, m_bChanged		(false)
	, m_bEnableCache	(false)
	, m_lpLogReceiver	(NULL)
	, m_dwFlags			(NULL)
{
}

A3DHLSLMan::~A3DHLSLMan()
{
}

bool A3DHLSLMan::Init(bool bEnableCache)
{
	DWORD         dwLength;
	AFileImage    file;
	HLSLMANHEADER Header;
	m_bEnableCache = bEnableCache;

	if(m_bEnableCache == true)
	{
		memset(&Header, 0, sizeof(Header));

		if(file.Open(szCachePath, AFILE_BINARY | AFILE_OPENEXIST) == true)
		{
			file.Read(&Header.cbSize, sizeof(Header.cbSize), &dwLength);
			if(dwLength == 0)
			{
				g_A3DErrLog.Log("A3DHLSLMan::Init(), Cache file is 0 zero size.");
				return true;
			}
			file.Read(((BYTE*)&Header.cbSize) + sizeof(Header.cbSize), Header.cbSize - sizeof(Header.cbSize), &dwLength);

			for(DWORD i = 0; i < Header.dwShaderCount; i++)
			{
				A3DHLSLCore* pHLSLCore = new A3DHLSLCore(m_pDevice, this);
				pHLSLCore->Load(&file);
				pHLSLCore->AddRef();
				m_aShaderCorePtrArray.push_back(pHLSLCore);
			}

			AString strFile;
			for(DWORD i = 0; i < Header.dwRefFileCount; i++)
			{
				file.ReadString(strFile);
				RegisterRefFile(strFile);
			}
			CheckUpdate();
		}
		else
		{
			g_A3DErrLog.Log("A3DHLSLMan::Init() : Cache file does not exist.");
		}
	}

	s_pText2EnumDict = new Text2EnumDict;
	if(s_pText2EnumDict != NULL)
	{
		(*s_pText2EnumDict)["ADDRESSU"]      = D3DSAMP_ADDRESSU;
		(*s_pText2EnumDict)["ADDRESSV"]      = D3DSAMP_ADDRESSV;
		(*s_pText2EnumDict)["ADDRESSW"]      = D3DSAMP_ADDRESSW;
		(*s_pText2EnumDict)["BORDERCOLOR"]   = D3DSAMP_BORDERCOLOR;
		(*s_pText2EnumDict)["MAGFILTER"]     = D3DSAMP_MAGFILTER;
		(*s_pText2EnumDict)["MINFILTER"]     = D3DSAMP_MINFILTER;
		(*s_pText2EnumDict)["MIPFILTER"]     = D3DSAMP_MIPFILTER;
		(*s_pText2EnumDict)["MIPMAPLODBIAS"] = D3DSAMP_MIPMAPLODBIAS;
		(*s_pText2EnumDict)["MAXMIPLEVEL"]   = D3DSAMP_MAXMIPLEVEL;
		(*s_pText2EnumDict)["MAXANISOTROPY"] = D3DSAMP_MAXANISOTROPY;
		(*s_pText2EnumDict)["SRGBTEXTURE"]   = D3DSAMP_SRGBTEXTURE;
		(*s_pText2EnumDict)["ELEMENTINDEX"]  = D3DSAMP_ELEMENTINDEX;
		(*s_pText2EnumDict)["DMAPOFFSET"]    = D3DSAMP_DMAPOFFSET;

		(*s_pText2EnumDict)["WRAP"]          = D3DTADDRESS_WRAP;
		(*s_pText2EnumDict)["MIRROR"]        = D3DTADDRESS_MIRROR;
		(*s_pText2EnumDict)["CLAMP"]         = D3DTADDRESS_CLAMP;
		(*s_pText2EnumDict)["BORDER"]        = D3DTADDRESS_BORDER;
		(*s_pText2EnumDict)["MIRRORONCE"]    = D3DTADDRESS_MIRRORONCE;

		(*s_pText2EnumDict)["NONE"]            = D3DTEXF_NONE;
		(*s_pText2EnumDict)["POINT"]           = D3DTEXF_POINT;
		(*s_pText2EnumDict)["LINEAR"]          = D3DTEXF_LINEAR;
		(*s_pText2EnumDict)["ANISOTROPIC"]     = D3DTEXF_ANISOTROPIC;
		(*s_pText2EnumDict)["PYRAMIDALQUAD"]   = D3DTEXF_PYRAMIDALQUAD;
		(*s_pText2EnumDict)["GAUSSIANQUAD"]    = D3DTEXF_GAUSSIANQUAD;
		(*s_pText2EnumDict)["CONVOLUTIONMONO"] = D3DTEXF_CONVOLUTIONMONO;
	}

	return true;
}

bool A3DHLSLMan::BuildD3DMacro(const MacroArray& aMacros, D3DXMacroArray& aD3DXMacros)
{
	D3DXMACRO macro;
	aD3DXMacros.clear();

	for(MacroArray::const_iterator it = aMacros.begin();
		it != aMacros.end(); ++it)
	{
		macro.Name = it->Name;
		macro.Definition = it->Definition;
		aD3DXMacros.push_back(macro);
	}
	macro.Name = NULL;
	macro.Definition = NULL;
	aD3DXMacros.push_back(macro);
	return true;
}

bool A3DHLSLMan::Release()
{
	DWORD         dwLength;
	HLSLMANHEADER Header;
	Header.cbSize = sizeof(Header);
	Header.dwShaderCount = 0;
	Header.dwRefFileCount = m_FileTimeDict.size();

	AFile file;
	int fileOffset = 0;
	if(m_bChanged == true && m_bEnableCache == true)
	{
		BOOL bRet = TRUE;

		if(bRet == FALSE)
			m_bChanged = false;
		else
		{
			if(file.Open(szCachePath, AFILE_BINARY | AFILE_CREATENEW) == false)		// TODO: �ĳɲ���ÿ�ζ�д��
			{
				m_bChanged = false;
				g_A3DErrLog.Log("A3DHLSLMan::Release() : Can not write cache file!");
			}
			else
			{
				fileOffset = file.GetPos();
				file.Write(&Header, sizeof(Header), &dwLength);
			}
		}
	}

	for(ShaderCorePtrArray::iterator it = m_aShaderCorePtrArray.begin();
		it != m_aShaderCorePtrArray.end(); ++it)
	{
		if(m_bChanged == true && m_bEnableCache == true)
		{
			if(((*it)->m_lpVShaderFunc != NULL && (*it)->m_pVertexShader != NULL) ||
				((*it)->m_lpPShaderFunc != NULL && (*it)->m_pPixelShader != NULL) )
			{
				(*it)->Save(&file);
				Header.dwShaderCount++;
			}
		}

		int nRef = (*it)->Release();
		if(nRef == 0)
			delete *it;
		else
			g_A3DErrLog.Log("Some HLSL object has not been releasaed.");
	}
	m_aShaderCorePtrArray.clear();

	if(m_bChanged == true && m_bEnableCache == true)
	{
		for(FileTimeDict::iterator it = m_FileTimeDict.begin(); 
			it != m_FileTimeDict.end(); ++it)
		{
			file.WriteString(it->first);
		}

		// �����ļ�ͷ�е�dwShaderCountֵ
		file.Seek(fileOffset, AFILE_SEEK_SET);
		file.Write(&Header, sizeof(Header), &dwLength);
	}
	if(s_pText2EnumDict != NULL)
	{
		delete s_pText2EnumDict;
		s_pText2EnumDict = NULL;
	}
	return true;
}

bool A3DHLSLMan::ParseMacroArgument(const char* szMacros, MacroArray& aMacros)
{
	AString strMacroArg = szMacros;
	A3DSHDMACRO Macro;
	unsigned int nPos = 0;
	unsigned int nNext, nDef;
	do
	{
		nNext = (unsigned int)strMacroArg.Find(';', nPos);
		nDef = (unsigned int)strMacroArg.Find('=', nPos);

		if(nNext == (unsigned int)-1)
			nNext = strMacroArg.GetLength();
		if(nDef == (unsigned int)-1)
			nDef = strMacroArg.GetLength();

		if(nNext < nDef)
		{
			Macro.Name = strMacroArg.Mid(nPos, nNext - nPos);
			Macro.Name.TrimLeft(' ');
			Macro.Name.TrimRight(' ');
			Macro.Definition.Empty();
			aMacros.push_back(Macro);
			nPos = nNext + 1;
		}
		else
		{
			Macro.Name = strMacroArg.Mid(nPos, nDef - nPos);
			Macro.Definition = strMacroArg.Mid(nDef + 1, nNext - nDef - 1);
			Macro.Name.TrimLeft(' ');
			Macro.Name.TrimRight(' ');
			Macro.Definition.TrimLeft(' ');
			Macro.Definition.TrimRight(' ');
			aMacros.push_back(Macro);
			nPos = nNext + 1;
		}
	}while(nNext != strMacroArg.GetLength() || nDef != strMacroArg.GetLength());
	return true;
}

bool A3DHLSLMan::GenerateName(const char* pszVertexShaderFile, const char* szVSFuncName, const char* pszPixelShaderFile, const char* szPSFuncName, MacroArray& aMacros, AString& strName)
{
	AString strVertexFile;
	AString strPixelFile;

	if(pszVertexShaderFile != NULL)
		af_GetRelativePath(pszVertexShaderFile, strVertexFile);
	if(pszPixelShaderFile != NULL)
		af_GetRelativePath(pszPixelShaderFile, strPixelFile);
	strVertexFile.MakeLower();
	strPixelFile.MakeLower();
	strName.Empty();
	strName = strVertexFile + "|" + szVSFuncName+ "|" + strPixelFile + "|" + szPSFuncName + "|";
	for(MacroArray::iterator it = aMacros.begin(); it != aMacros.end(); ++it)
	{
		if(it->Name.GetLength() == 0)
			continue;
		if(it->Definition.GetLength() > 0)
			strName += it->Name + "=" + it->Definition + ";";
		else
			strName += it->Name + ";";
	}
	return true;
}

bool A3DHLSLMan::ParseName(const AString& strName, AString* pVertexShaderFile, AString* pVSFuncName, AString* pPixelShaderFile, AString* pPSFuncName, AString* pMacros)
{
	int nPos1 = strName.Find('|');
	int nPos2 = strName.Find('|', nPos1 + 1);
	int nPos3 = strName.Find('|', nPos2 + 1);
	int nPos4 = strName.Find('|', nPos3 + 1);
	int nPos5 = strName.Find('|', nPos4 + 1);

	if(pVertexShaderFile != NULL)
		*pVertexShaderFile = strName.Mid(0, nPos1);

	if(pVSFuncName != NULL)
		*pVSFuncName = strName.Mid(nPos1 + 1, nPos2 - nPos1 - 1);

	if(pPixelShaderFile != NULL)
		*pPixelShaderFile  = strName.Mid(nPos2 + 1, nPos3 - nPos2 - 1);

	if(pPSFuncName != NULL)
		*pPSFuncName = strName.Mid(nPos3 + 1, nPos4 - nPos3 - 1);

	if(pMacros != NULL)
		*pMacros = strName.Mid(nPos4 + 1, nPos5 - nPos4 - 1);

	return true;
}

bool A3DHLSLMan::ParseNameFromFile(const char* szShaderName, AString* pVertexShaderFile, AString* pVSFuncName, AString* pPixelShaderFile, AString* pPSFuncName, AString* pMacros)
{
	AFileImage     File;
	HLSLCOREHEADER Header;
	DWORD          dwLength;
	AString		   strName;
	if( ! File.Open(szShaderName, AFILE_BINARY | AFILE_OPENEXIST))
	{
		return false;
	}

	File.Read(&Header.cbSize, sizeof(Header.cbSize), &dwLength);
	File.Read(((BYTE*)&Header.cbSize) + sizeof(Header.cbSize), Header.cbSize - sizeof(Header.cbSize), &dwLength);
	
	if(File.ReadString(strName))
	{
		return ParseName(strName, pVertexShaderFile, pVSFuncName, pPixelShaderFile, pPSFuncName, pMacros);
	}
	return false;
}

A3DHLSLMan::ShaderCorePtrArray::iterator A3DHLSLMan::FindByName(const AString& strName)
{
	for(ShaderCorePtrArray::iterator it = m_aShaderCorePtrArray.begin(); 
		it != m_aShaderCorePtrArray.end(); ++it)
	{
		if(strName == (*it)->GetName())
			return it;
	}
	return m_aShaderCorePtrArray.end();
}

bool A3DHLSLMan::RegisterRefFile(const AString& strFile)
{
	FILETIME FileTime;
	FileTime.dwLowDateTime = 0;
	FileTime.dwHighDateTime = 0;
	m_FileTimeDict[strFile] = FileTime;
	return true;
}

bool A3DHLSLMan::GenCompiledFilename(const char* szVertexShaderFile, const char* szPixelShaderFile, DWORD dwNameID, AString& strFilename)
{
	AString strPath;
	if(szPixelShaderFile == 0 && szVertexShaderFile == 0) {
		return false;
	}
	const char* szFilename = (szVertexShaderFile == 0)
		? szPixelShaderFile
		: ((szPixelShaderFile == 0) 
			? szVertexShaderFile 
			: szPixelShaderFile);
	strPath = szFilename;
	if(strPath.GetLength() == 0){
		return false;
	}
	strPath.MakeLower();
	int nPos = strPath.Find("\\shaders\\2.2\\hlsl\\", 0);
	if(nPos < 0) {
		return false;
	}
	strPath[nPos + 13] = 's';
	strPath[nPos + 14] = 'd';
	strPath[nPos + 15] = 'r';
	strPath[nPos + 16] = 'x';

	af_GetFilePath(strPath, strPath);
	strFilename.Format("%s\\%08X_%s.obj", strPath, dwNameID, szFilename == szVertexShaderFile ? "VS" : "PS");

	return true;
}

A3DHLSL* A3DHLSLMan::LoadShader(const char* szCompiledShader, DWORD dwFlags)
{
	AFileImage     File;
	HLSLCOREHEADER Header;
	DWORD          dwLength;
	AString		   strName;
	A3DHLSL*       pHLSL = NULL;
	A3DHLSLCore*   pShader = NULL;
	if( ! File.Open(szCompiledShader, AFILE_BINARY | AFILE_OPENEXIST))
	{
		return false;
	}
	DWORD dwPos = File.GetPos();

	File.Read(&Header.cbSize, sizeof(Header.cbSize), &dwLength);
	File.Read(((BYTE*)&Header.cbSize) + sizeof(Header.cbSize), Header.cbSize - sizeof(Header.cbSize), &dwLength);

	ShaderCorePtrArray::iterator itShader = FindByName(strName);
	if(itShader != m_aShaderCorePtrArray.end())
	{
		ASSERT((*itShader)->m_pVertexShader != NULL || (*itShader)->m_pPixelShader != NULL);
		pShader = *itShader;
		goto CREATE_NEW_HLSL;
	}

	pShader = new A3DHLSLCore(m_pDevice, this);
	if(pShader->Init() == true)
	{
		pShader->AddRef();
		File.Seek(dwPos, AFILE_SEEK_SET);
		if(pShader->Load(&File) == true)
		{
			m_aShaderCorePtrArray.push_back(pShader);
			m_bChanged = true;
			goto CREATE_NEW_HLSL;
		}
	}

	pShader->Release();
	delete pShader;

	g_A3DErrLog.Log("A3DHLSLMan::LoadShader, failed to load shader %s.", szCompiledShader);
	return NULL;

CREATE_NEW_HLSL:
	pHLSL = new A3DHLSL(pShader);
	pHLSL->Init();
	m_aShaderInstPtr.push_back(pHLSL);
	return pHLSL;
}

A3DHLSL* A3DHLSLMan::LoadShader(const char* pszVertexShaderFile, const char* szVSFuncName, const char* pszPixelShaderFile, const char* szPSFuncName, const char* szMacro, DWORD dwFlags)
{
	AString			strName;
	MacroArray		aMacros;
	D3DXMacroArray	aD3DXMacros;
	A3DHLSLCore*	pShader = NULL;
	A3DHLSL*		pHLSL;

	AString strVertexShaderFile;
	AString strPixelShaderFile;

	if(pszVertexShaderFile != NULL)
	{
		af_GetFullPath(strVertexShaderFile, pszVertexShaderFile);
		pszVertexShaderFile = strVertexShaderFile;
		RegisterRefFile(pszVertexShaderFile);
	}

	if(pszPixelShaderFile != NULL)
	{
		af_GetFullPath(strPixelShaderFile, pszPixelShaderFile);
		pszPixelShaderFile = strPixelShaderFile;
		RegisterRefFile(pszPixelShaderFile);
	}

	ParseMacroArgument(szMacro, aMacros);
	BuildD3DMacro(aMacros, aD3DXMacros);

	GenerateName(pszVertexShaderFile, szVSFuncName, pszPixelShaderFile, szPSFuncName, aMacros, strName);
	ShaderCorePtrArray::iterator itShader = FindByName(strName);
	if(itShader != m_aShaderCorePtrArray.end())
	{
		ASSERT((*itShader)->m_pVertexShader != NULL || (*itShader)->m_pPixelShader != NULL);
		pShader = *itShader;
		goto CREATE_NEW_HLSL;
	}

	pShader = new A3DHLSLCore(m_pDevice, this);
	if(pShader->Init() == true)
	{
		pShader->AddRef();
		pShader->SetName(strName);
		if( (m_dwFlags & A3DHLSLMAN_FLAG_LOADSPECFILE) == 0 )	// ���ر������shader
		{
			AString strFilename;
			DWORD dwNameID = a_MakeIDFromString(strName);
			AFileImage File;
			if(GenCompiledFilename(pszVertexShaderFile, pszPixelShaderFile, dwNameID, strFilename) &&
				File.Open(strFilename, AFILE_BINARY | AFILE_OPENEXIST))
			{
				if( pShader->Load(&File) )
				{
					m_aShaderCorePtrArray.push_back(pShader);
					m_bChanged = true;
					goto CREATE_NEW_HLSL;
				}
			}
		}
		if(pShader->LoadFromFile(pszVertexShaderFile, pszPixelShaderFile, &aD3DXMacros.front(), NULL, szVSFuncName, NULL, szPSFuncName) == true)
		{
#ifdef _DEBUG
			if(pszVertexShaderFile != NULL)
				ASSERT(pShader->m_pVertexShader != NULL);
			if(pszPixelShaderFile != NULL)
				ASSERT(pShader->m_pPixelShader != NULL);
#endif // _DEBUG
			m_aShaderCorePtrArray.push_back(pShader);
			m_bChanged = true;
			goto CREATE_NEW_HLSL;
		}
	}
	
	pShader->Release();
	delete pShader;

	g_A3DErrLog.Log("Failed to create HLSL shader.VS:%s\nPS:%s", pszVertexShaderFile, pszPixelShaderFile);
	return NULL;

CREATE_NEW_HLSL:
	pHLSL = new A3DHLSL(pShader);
	pHLSL->Init();
	m_aShaderInstPtr.push_back(pHLSL);
	return pHLSL;
}

A3DHLSL* A3DHLSLMan::LoadShader( const char* pszVertexShaderFile, const char* pszPixelShaderFile, const char* szMacro )
{
	return LoadShader(pszVertexShaderFile, "vs_main", pszPixelShaderFile, "ps_main", szMacro, 0);
}

void A3DHLSLMan::ReleaseShader(A3DHLSL* pHLSL)
{
	if(pHLSL == NULL)
		return;

	for(ShaderInstPtrArray::iterator it = m_aShaderInstPtr.begin();
		it != m_aShaderInstPtr.end(); ++it)
	{
		if(*it == pHLSL)
		{
			A3DHLSLCore* pCore = (*it)->GetCore();
			(*it)->Release();
			delete *it;
			m_aShaderInstPtr.erase(it);

			// ���Core����Ϊ0, ���ͷŵ�Core
			if(pCore->m_nRefCount == 1)
			{
				ShaderCorePtrArray::iterator itCore = FindByName(pCore->GetName());
				if(itCore != m_aShaderCorePtrArray.end())
				{
					m_aShaderCorePtrArray.erase(itCore);
					pCore->Release();
					delete pCore;
				}
				else
				{
					ASSERT(0);
				}
			}
			return;
		}
	}
	ASSERT(0);
}

bool A3DHLSLMan::CheckUpdate()
{
	if(m_bEnableCache == false)
		return true;

	HANDLE hFile;
	FILETIME ftCache;
	FILETIME ftSource;

	hFile = CreateFileA(szCachePath, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
		return false;

	GetFileTime(hFile, NULL, NULL, &ftCache);
	CloseHandle(hFile);

	for(FileTimeDict::iterator it = m_FileTimeDict.begin();
		it != m_FileTimeDict.end(); ++it)
	{
		hFile = CreateFileA(it->first, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if(hFile == INVALID_HANDLE_VALUE)
			continue;
		GetFileTime(hFile, NULL, NULL, &ftSource);
		CloseHandle(hFile);

		if(CompareFileTime(&ftCache, &ftSource) < 0)
		{
			RebuildAll();
			return true;
		}
	}
	return false;
}

void A3DHLSLMan::AppendErrorMsg(const AString& strError, bool bWantReturn)
{
	if(m_lpLogReceiver != NULL)
	{
		m_lpLogReceiver(strError);
		if(bWantReturn)
		{
			m_lpLogReceiver("\r\n");
		}
	}
//#ifdef _DEBUG
//	//m_strErrorMsg += strError;
//	HWND hNotepadWnd = FindWindow(_AL("notepad"), NULL);
//	if(hNotepadWnd != NULL)
//	{
//		HWND hEditWnd = FindWindowEx(hNotepadWnd, NULL, _AL("EDIT"), NULL);
//		if(hEditWnd != NULL)
//		{
//			SendMessageA(hEditWnd, EM_SETSEL, -1, 0);
//			SendMessageA(hEditWnd, EM_REPLACESEL, FALSE, (LPARAM)(const char*)strError);
//		}
//	}
//#endif // _DEBUG
}

bool A3DHLSLMan::RebuildAll()
{
	return RebuildByKeyword(NULL);
}

bool A3DHLSLMan::RebuildByKeyword(const char* pszKeyword)
{
	bool bval = true;
	ShaderCorePtrArray aChanged;
	AString strKeyword = pszKeyword;
	strKeyword.MakeLower();
	AppendErrorMsg("\r\n\r\n\r\n--------------------------------------------------------\r\n");
	for(ShaderCorePtrArray::iterator it = m_aShaderCorePtrArray.begin();
		it != m_aShaderCorePtrArray.end(); ++it)
	{
		if(pszKeyword == NULL || strstr((*it)->GetName(), strKeyword) != NULL)
		{
			AString strName;
			strName.Format("����Shader:%s\r\n", (*it)->GetName());
			AppendErrorMsg(strName);

			bool bret = (*it)->Rebuild();
			bval = bval == true ? bret : bval;
			aChanged.push_back(*it);
		}
	}
	if(pszKeyword == NULL)
	{
		for(ShaderInstPtrArray::iterator it = m_aShaderInstPtr.begin();
			it != m_aShaderInstPtr.end(); ++it)
		{
			(*it)->Relink();
		}
	}
	else
	{
		for(ShaderInstPtrArray::iterator it = m_aShaderInstPtr.begin();
			it != m_aShaderInstPtr.end(); ++it)
		{
			for(ShaderCorePtrArray::iterator itCore = aChanged.begin();
				itCore != aChanged.end(); ++itCore)
			{
				if((*it)->m_pCore == *itCore)
				{
					(*it)->Relink();
				}
			}
		}
	}
	m_bChanged = bval;
	return bval;
}

void A3DHLSLMan::SetLogReceiver(LPLOGRECEIVER lpLogReceiver)
{
	m_lpLogReceiver = lpLogReceiver;
}


void A3DHLSL::SAMPLERSLOT::UpdateD3DTexPtr(A3DObject* _pA3DObject)
{
	pA3DObject = _pA3DObject;

	const DWORD dwClassID = pA3DObject == NULL 
		? A3D_CID_UNKNOWN 
		: pA3DObject->GetClassID();

	if(pA3DObject == NULL)
	{
		pTextureBase = NULL;
		return;
	}

	if(dwClassID == A3D_CID_RENDERTARGET)
	{
		pTextureBase = ((A3DRenderTarget*)pA3DObject)->GetTargetTexture();
	}
	else
	{
		pTextureBase = ((A3DTexture*)pA3DObject)->GetD3DBaseTexture();
	}
}

void A3DHLSLCore::SAMPLER_STATE::SetState(D3DSAMPLERSTATETYPE Type, DWORD dwState)
{
	SampStateMask |= (1 << Type);
	SampState[(int)Type - 1] = dwState;
}

void A3DHLSLCore::SAMPLER_STATE::ResetState(D3DSAMPLERSTATETYPE Type)
{
	SampStateMask &= (~(1 << Type));
}

void A3DHLSLCore::SAMPLER_STATE::Cleanup()
{
	SampStateMask = 0;
	memset(SampState, 0, sizeof(DWORD) * 13);
	strDefault.Empty();	
}