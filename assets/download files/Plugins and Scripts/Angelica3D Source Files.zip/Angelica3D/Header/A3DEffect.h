#ifndef _A3DEFFECT_H_
#define _A3DEFFECT_H_

class A3DEffect : public A3DTexture
{
public:
	struct SAMPLER_DESC
	{
		AString		strName;
		A3DTexture* pTexture;
	};
	typedef abase::vector<SAMPLER_DESC> SamplerDescArray;
	struct MTLPARAM
	{
		AString strKey;
		AString strValue;
	};
	typedef abase::vector<MTLPARAM> ParamArray;
	typedef abase::hash_map<AString, AString> ParamDict;
	struct EFFECTFILEHEADER
	{
		DWORD cbSize;
		int nParamCount;
	};
public:
	A3DEffect();
	~A3DEffect();

	virtual bool Init(A3DDevice* pDevice);
	virtual bool Release();
	virtual	bool Reload(bool bForceReload);
	//bool ReloadAllData();

	bool Load(const char* pszFile, const char* pszOriginFile);
	bool Save(const char* pszFile = NULL);
	static A3DEffect* CreateHLSLShader(A3DDevice* pA3DDevice, const char* pszTextureFile, const char* pszHLSLFile);


	bool Appear(const A3DCOMMCONSTTABLE* lpCommConstTable);
	virtual bool Appear(int nLayer=0);
	virtual bool Disappear(int nLayer=0);

	inline A3DHLSL* GetHLSL();
	bool SetHLSL(const char* pszHLSLFile);

	A3DTexture* GetTextureByName(const char* pszName) const;
	bool SetTextureByName(const char* pszName, const char* pszFilename);

	bool	SetValueByString(const A3DHLSL::CONSTMAPDESC& ConstDesc, const AString& strVaule);
	bool	GetValueByString(const A3DHLSL::CONSTMAPDESC& ConstDesc, AString& strVaule);
	AString GetMtlFilename();
	AString GetHLSLFilename();
	bool	GenerateParam(ParamArray& aParam);

	virtual IDirect3DBaseTexture9* GetD3DBaseTexture() const;
private:
	A3DDevice*			m_pA3DDevice;
	A3DHLSL*			m_pHLSL;
	SamplerDescArray	m_aSampDesc;

	bool ReleaseSamplerDesc();
};

//////////////////////////////////////////////////////////////////////////

A3DHLSL* A3DEffect::GetHLSL()
{
	return m_pHLSL;
}

#endif // _A3DMATERIAL_INSTANCE_H_