/*
 * FILE: A3DHLSL.h
 *
 * DESCRIPTION: DX9 High Level Shading Language
 *
 * CREATED BY: liuchenglong 2011-08-23
 *
 * HISTORY:
 *
 * Copyright (c) 2001 Archosaur Studio, All Rights Reserved.
 */

#ifndef _A3DHLSL_H_
#define _A3DHLSL_H_
#include <hashmap.h>

class A3DHLSLMan;
class A3DHLSL;
class A3DHLSLCore;
class AFilePackage;
class A3DVertexDecl;

#define HLSLCORE_VERSION_1		0x80000001
#define HLSLMANAGER_VERSION_1	0xf0000001
#define MAX_SAMPLERCOUNT		16

#define APPEAR_SETSHADERONLY ((const A3DCOMMCONSTTABLE*)-1)

// A3DHLSLMAN ��־
#define A3DHLSLMAN_FLAG_LOADSPECFILE	0x00000001		// �༭�������øñ�־��ȡָ�����ļ�,���������ȶ�ȡ�����ļ�

struct A3DCOMMONCONSTDESC
{
	enum{
		CCD_SAMPLER   = -4,
		CCD_FLOAT     = sizeof(float),
		CCD_FLOAT2    = sizeof(float) * 2,
		CCD_FLOAT3    = sizeof(float) * 3,
		CCD_FLOAT4    = sizeof(float) * 4,
		CCD_FLOAT4X4  = sizeof(A3DMATRIX4),
	};
	char*	szConstName;
	int		uMemberOffset;
	int		cbSize;
	int		nRef;
};


class A3DHLSLInclude : public ID3DXInclude
{
private:
	A3DHLSLCore*			m_pHLSL;
	AString					m_strSystemDir;
	AString					m_strLocalDir;
	abase::vector<AString>	m_aIncludeFiles;
public:
	A3DHLSLInclude(A3DHLSLCore* pHLSL);
	~A3DHLSLInclude();

	bool Init();
	bool Release();

	void SetDir(D3DXINCLUDE_TYPE IncludeType, const AString& strDir);

public:
	abase::vector<AString>* GetIncludeFiles();
	STDMETHOD(Open)(THIS_ D3DXINCLUDE_TYPE IncludeType, LPCSTR pFileName, LPCVOID pParentData, LPCVOID *ppData, UINT *pBytes);
	STDMETHOD(Close)(THIS_ LPCVOID pData);
};


class A3DHLSLCore : public A3DObject
{
	friend class A3DHLSLMan;
	friend class A3DHLSL;
public:
	struct CONSTANTDESC
	{
		D3DXCONSTANT_DESC cd;
		DWORD             dwNameID;
		AString			  Semantic;
		unsigned int      bVertexShader : 1;
		unsigned int      bUnique       : 1;
		unsigned int      nIdx          : 16;
		CONSTANTDESC() : dwNameID(0),bVertexShader(0),bUnique(0),nIdx(0)
		{
			memset(&cd, 0, sizeof(D3DXCONSTANT_DESC));
		}
	};
	struct ANNOTATION
	{
		AString				Name;
		union
		{
			BOOL			bValue;
			INT				nValue;
			FLOAT			fValue;
		};
		void*				pData;
		D3DXPARAMETER_CLASS Class;
		D3DXPARAMETER_TYPE	Type;
		UINT				cbDateSize;
	};
	struct SAMPLER_STATE
	{
		DWORD	SampStateMask;	// ʹ�ñ�־
		DWORD	SampState[13];	// ��¼13��״̬
		AString strDefault;

		// ���ò�����״̬
		void SetState(D3DSAMPLERSTATETYPE Type, DWORD dwState);

		// ���ò�����״̬!!!ע��!!!���ֻ�Ǳ�ʾAppearʱ���ٹ���״̬,�����ǻָ���Ĭ��״̬
		void ResetState(D3DSAMPLERSTATETYPE Type);

		void Cleanup();
	};
	//typedef abase::vector<SAMPLER_STATE>				SamplerStateArray;
	typedef abase::vector<CONSTANTDESC>					ConstArray;
	typedef abase::hash_map<AString, CONSTANTDESC*>		ConstDict;
	typedef abase::vector<ANNOTATION>					AnnotationArray;
	typedef abase::hash_map<AString, AnnotationArray*>	Name2AnnoDict;
	typedef const SAMPLER_STATE*						LPCSAMPLER_STATE;
	typedef const CONSTANTDESC*							LPCCONSTANTDESC;
protected:
	// ���ӳ�Ա�Ļ�Ҫ�޸� Transfer ����
	A3DDevice*               m_pDevice;
	int						 m_nRefCount;
	DWORD					 m_dwID;
	A3DHLSLMan*				 m_pHLSLMgr;
	LPDIRECT3DVERTEXSHADER9  m_pVertexShader;
	LPDIRECT3DPIXELSHADER9   m_pPixelShader;
	ID3DXConstantTable*	     m_pVertexConstants;
	ID3DXConstantTable*	     m_pPixelConstants;
	LPD3DXBUFFER			 m_lpVShaderFunc;
	LPD3DXBUFFER			 m_lpPShaderFunc;
	ConstArray				 m_aConst;
	ConstDict				 m_NameSemaToConstDict;
	Name2AnnoDict*			 m_pName2AnnoDict;
	SAMPLER_STATE			 m_aSampState[MAX_SAMPLERCOUNT];
	UINT					 m_nMaxSamplerIdx;
	AString					 m_strVSFuncName;
	AString					 m_strPSFuncName;
protected:
	bool	GenConstTable	(ID3DXConstantTable* pD3DXConstTabel, bool bVertexShader);
	bool	GenAnnoAndSema	(LPD3DXEFFECT lpD3DXEffect);
	void	Transfer		(A3DHLSLCore& Src);
	void	BuildConstDict	(DWORD dwFlags);
	void	GetDefaultTexturePath(const char* szTextureName, AString& strPath);
	void	GenSamplerState	();
	int		GetSemaCount	();
public:
	A3DHLSLCore(A3DDevice* pA3DDevice, A3DHLSLMan* pHLSLMgr);
	~A3DHLSLCore();

	bool	Init			();
	int		AddRef			();
	int		Release			();
	void	Cleanup			();
	bool	CreateShader	(LPD3DXBUFFER lpVSFunc, LPD3DXBUFFER lpPSFunc);
	bool	LoadFromMemory	(const BYTE* pszVSCode, size_t uVSCodeLen, const D3DXMACRO* pVSMacro, A3DHLSLInclude* pVSInclude, const char* szVSFuncName, 
							 const BYTE* pszPSCode, size_t uPSCodeLen, const D3DXMACRO* pPSMacro, A3DHLSLInclude* pPSInclude, const char* szPSFuncName);
	bool	LoadFromFile	(AFile* pVSFile, AFile* pPSFile, const D3DXMACRO* pMacro, A3DHLSLInclude* pVSInclude, const char* szVSFuncName, A3DHLSLInclude* pPSInclude, const char* szPSFuncName);
	bool	LoadFromFile	(const char* pszVertexShaderFile, const char* pszPixelShaderFile, const D3DXMACRO* pMacro, A3DHLSLInclude* pVSInclude, const char* szVSFuncName, A3DHLSLInclude* pPSInclude, const char* szPSFuncName);

	bool	Save			(AFile* pFile);
	bool	Load			(AFile* pFile);
	bool	Rebuild			();

	virtual void		SetName			(const char* szName);

public:
	bool	Appear				();
	bool	Disappear			();
	inline  A3DDevice*			GetA3DDevice	();
	inline	ConstDict&			GetConstDict();
	inline	ConstArray&			GetConstArray();
	inline	Name2AnnoDict*		GetAnnoDict();
	inline	LPCSAMPLER_STATE	GetSamplerState(int nSamplerIdx);
	inline	LPCCONSTANTDESC		GetConstDescByName(const char* szName);
	inline	DWORD				GetID();
	//inline	ID3DXConstantTable*	GetConstTable(int nIndex);
};
 

class A3DHLSL : public A3DObject
{
	friend class A3DHLSLMan;
public:
	struct CONSTREGCONTEXT
	{
		int nMin, nMax;
		A3DVECTOR4* pConstBuffer;
		CONSTREGCONTEXT();
		virtual ~CONSTREGCONTEXT();
		void Build();
	};
	struct CONSTMAPDESC
	{
		int					uMemberOffset;
		A3DHLSLCore::CONSTANTDESC cd;
		CONSTMAPDESC()
			: uMemberOffset(0){}
	};
	typedef abase::vector<CONSTMAPDESC> ConstMapArray;
	typedef A3DHLSLCore::ConstDict ConstDict;
	typedef A3DHLSLCore::ConstArray ConstArray;
	typedef A3DHLSLCore::ANNOTATION ANNOTATION;

	struct SAMPLERSLOT
	{
		A3DObject*				pA3DObject;
		LPDIRECT3DBASETEXTURE9	pTextureBase;
		DWORD					SampStateMask;
		DWORD					SampState[13];

		void UpdateD3DTexPtr(A3DObject* _pA3DObject);
	};
private:
	A3DHLSLCore*			m_pCore;
	CONSTMAPDESC*			m_aConstName;
	int						m_cbConstTableSize;	// ֻ��Ϊ�˼��
	CONSTREGCONTEXT			m_VertexRegContext;
	CONSTREGCONTEXT			m_PixelRegContext;
	A3DCOMMONCONSTDESC*		m_lpCommConstDesc;
	SAMPLERSLOT				m_aSamplerSlot[MAX_SAMPLERCOUNT];

	A3DHLSL(A3DHLSLCore* pCore);

	bool	Init			();
	bool	GenConstBuffer	(CONSTREGCONTEXT* pContext, bool bVertexShader);
	bool	Release			();
	bool	Relink			();
public:
	virtual ~A3DHLSL();
	bool	SetCommConstDesc	(A3DCOMMONCONSTDESC* lpCommConstDesc, int cbTable);	// ��һ�����������Ǿ�̬�ṹ, �����Ǿֲ�����
	bool	Appear				(const A3DCOMMCONSTTABLE* lpCommConstTable = NULL); // ���������-1�Ļ�,ֻ����Shader,�������κγ����Ĵ���
	bool	Disappear			();
	bool	SubmitCommTable		(const A3DCOMMCONSTTABLE* lpCommConstTable);		// ֻ�ύ������
	bool	SetValue1f			(const char* szName, const float fConstant);
	bool	SetValue2f			(const char* szName, const float fConstant1, const float fConstant2);
	bool	SetValue3f			(const char* szName, const A3DVECTOR3* pConstant);
	bool	SetValue4f			(const char* szName, const A3DVECTOR4* pConstant);
	bool	SetConstantArrayF	(const char* szName, const A3DVECTOR4* pConstant, int nFloat4Count);
	bool	SetConstantMatrix	(const char* szName, const A3DMATRIX4& mat);
	bool	SetTexture			(const char* szName, A3DObject* pA3DObject);	// szName ��Sampler������,����Texture������
	bool	GetConstantArrayF	(const char* szName, A3DVECTOR4* pConstant, int nFloat4Count);
	bool	ReloadTexture		();

	const ANNOTATION* FindAnnotationByName(const char* szName, const char* szAnnoName);
	const CONSTMAPDESC* GetConstMapByName(const char* szName);
	inline const CONSTMAPDESC* GetConstMapArray();
	inline int GetConstCount();
	inline A3DHLSLCore* GetCore();
};

class A3DHLSLMan
{
	friend class A3DHLSL;
	friend class A3DHLSLCore;
	friend class A3DEffect;
public:
	struct A3DSHDMACRO
	{
		AString Name;
		AString Definition;
	};
	typedef abase::vector<A3DSHDMACRO>			MacroArray;
	typedef abase::vector<D3DXMACRO>			D3DXMacroArray;
	typedef abase::vector<A3DHLSLCore*>			ShaderCorePtrArray;
	typedef abase::vector<A3DHLSL*>				ShaderInstPtrArray;
	typedef abase::hash_map<AString, FILETIME>	FileTimeDict;
	typedef void (*LPLOGRECEIVER)(const char*);

private:
	A3DDevice*			m_pDevice;
	ShaderCorePtrArray	m_aShaderCorePtrArray;
	bool				m_bChanged;
	FileTimeDict		m_FileTimeDict;
	ShaderInstPtrArray	m_aShaderInstPtr;
	bool				m_bEnableCache;
	LPLOGRECEIVER		m_lpLogReceiver;
	DWORD				m_dwFlags;

	//AString				m_strErrorMsg;

	static bool		BuildD3DMacro		(const MacroArray& aMacros, D3DXMacroArray& aD3DXMacros);
	static bool		ParseMacroArgument	(const char* szMacros, MacroArray& aMacros);
	ShaderCorePtrArray::iterator
					FindByName			(const AString& strName);
	bool			RegisterRefFile		(const AString& strFile);
	bool			CheckUpdate			();
	void			AppendErrorMsg		(const AString& strError, bool bWantReturn = false);
	static bool		GenCompiledFilename	(const char* szVertexShaderFile, const char* szPixelShaderFile, DWORD dwNameID, AString& strFilename);
public:
	static bool		GenerateName		(const char* pszVertexShaderFile, const char* szVSFuncName, const char* pszPixelShaderFile, const char* szPSFuncName, MacroArray& aMacros, AString& strName);
	static bool		ParseName			(const AString& strName, AString* pVertexShaderFile, AString* pVSFuncName, AString* pPixelShaderFile, AString* pPSFuncName, AString* pMacros);
	static bool		ParseNameFromFile	(const char* szShaderName, AString* pVertexShaderFile, AString* pVSFuncName, AString* pPixelShaderFile, AString* pPSFuncName, AString* pMacros);
public:
	A3DHLSLMan(A3DDevice* pA3DDevice);
	~A3DHLSLMan();
	bool		Init				(bool bEnableCache);
	bool		Release				();
	A3DHLSL*	LoadShader			(const char* szCompiledShader, DWORD dwFlags);
	A3DHLSL*	LoadShader			(const char* pszVertexShaderFile, const char* szVSFuncName, const char* pszPixelShaderFile, const char* szPSFuncName, const char* szMacro, DWORD dwFlags);
	A3DHLSL*	LoadShader			(const char* pszVertexShaderFile, const char* pszPixelShaderFile, const char* szMacro);
	void		ReleaseShader		(A3DHLSL* pHLSL);
	bool		RebuildAll			();
	bool		RebuildByKeyword	(const char* pszKeyword);
	void		SetLogReceiver		(LPLOGRECEIVER lpLogReceiver);
	inline DWORD GetFlags			();
	inline void  SetFlags			(DWORD dwFlags);
};
//////////////////////////////////////////////////////////////////////////
//
// inline
//
A3DDevice* A3DHLSLCore::GetA3DDevice()
{
	return m_pDevice;
}
//ID3DXConstantTable*	A3DHLSLCore::GetConstTable(int nIndex)
//{
//	switch(nIndex)
//	{
//	case 0:
//		return m_pVertexConstants;
//	case 1:
//		return m_pPixelConstants;
//	}
//	return NULL;
//}

inline A3DHLSLCore::ConstDict& A3DHLSLCore::GetConstDict()
{
	return m_NameSemaToConstDict;
}
inline A3DHLSLCore::ConstArray& A3DHLSLCore::GetConstArray()
{
	return m_aConst;
}
inline A3DHLSLCore::Name2AnnoDict* A3DHLSLCore::GetAnnoDict()
{
	return m_pName2AnnoDict;
}

inline A3DHLSLCore::LPCSAMPLER_STATE A3DHLSLCore::GetSamplerState(int nSamplerIdx)
{
	ASSERT(nSamplerIdx >= 0 && nSamplerIdx < MAX_SAMPLERCOUNT);
	return &m_aSampState[nSamplerIdx];
}

inline A3DHLSLCore::LPCCONSTANTDESC A3DHLSLCore::GetConstDescByName(const char* szName)
{
	ConstDict::iterator it = m_NameSemaToConstDict.find(szName);
	if(it == m_NameSemaToConstDict.end()) {
		return NULL;
	}
	return it->second;
}

DWORD A3DHLSLCore::GetID()
{
	return m_dwID;
}
inline const A3DHLSL::CONSTMAPDESC* A3DHLSL::GetConstMapArray()
{
	return m_aConstName;
}

inline int A3DHLSL::GetConstCount()
{
	return (int)m_pCore->GetConstArray().size();
}

inline A3DHLSLCore* A3DHLSL::GetCore()
{
	return m_pCore;
}

inline DWORD A3DHLSLMan::GetFlags()
{
	return m_dwFlags;
}
inline void  A3DHLSLMan::SetFlags(DWORD dwFlags)
{
	m_dwFlags = dwFlags;
}

//////////////////////////////////////////////////////////////////////////
// LoadShader szMacro��ʽ: "MACRO1;MACRO2=x;MACRO03;..."

//////////////////////////////////////////////////////////////////////////
// SetCommConstDesc	(A3DCOMMONCONSTDESC* lpCommConstDesc, A3DCOMMONCONSTDESC* lpCommMark, int cbTable);
//		lpCommConstDesc: common const ��������ָ��
//		cbTable: common const ��������ָ��

#endif // _A3DHLSL_H_