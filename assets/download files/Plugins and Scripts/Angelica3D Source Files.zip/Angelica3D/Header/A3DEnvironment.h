#ifndef _A3D_ENVIRONMENT_H_
#define _A3D_ENVIRONMENT_H_

class A3DEnvironment
{
protected:

public:
	A3DEnvironment();
	virtual ~A3DEnvironment();
};

#endif // _A3D_ENVIRONMENT_H_