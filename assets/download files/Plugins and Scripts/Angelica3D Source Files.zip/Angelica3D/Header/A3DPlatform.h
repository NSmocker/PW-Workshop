/*
 * FILE: A3DPlatform.h
 *
 * DESCRIPTION: header for a platform related headers list
 *
 * CREATED BY: Hedi, 2001/12/3
 *
 * HISTORY:
 *
 * Copyright (c) 2001 Archosaur Studio, All Rights Reserved.	
 */

#ifndef _A3DPLATFORM_H_
#define _A3DPLATFORM_H_

#include <Windows.h>
#include <StdIO.h>

#include <assert.h>
#include <d3d9.h>
#include <d3dx9.h>
//	#include <AC.h> 
//	#include <AF.h>

#endif

