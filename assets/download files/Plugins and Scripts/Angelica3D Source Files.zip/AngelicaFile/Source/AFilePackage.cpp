﻿/*
* FILE: AFilePackage.cpp
*
* DESCRIPTION: A File Package Class for Angelica Engine
*
* CREATED BY: Hedi, 2002/4/15
*
* HISTORY:
*
* Copyright (c) 2001 Archosaur Studio, All Rights Reserved.
*/

#include "AFPI.h"
#include "AFI.h"
#include "AFilePackage.h"
#include "AScriptFile.h"
#include "AMemory.h"
#include "AAssist.h"
#include "ACSWrapper.h"
#include <io.h>

int		AFPCK_GUARDBYTE0 = 0xfdfdfeee;
int		AFPCK_GUARDBYTE1 = 0xf00dbeef;
int 	AFPCK_MASKDWORD = 0xa8937462;
int		AFPCK_CHECKMASK = 0x59374231;

///////////////////////////////////////////////////////////////////////////
//
//	Define and Macro
//
///////////////////////////////////////////////////////////////////////////

#define new A_DEBUG_NEW

#define COPYRIGHT_TAG "Angelica File Package, Perfect World Co. Ltd. 2002~2008. All Rights Reserved. "

#define MAX_FILE_PACKAGE	0x7fffff00U

///////////////////////////////////////////////////////////////////////////
//
//	Reference to External variables and functions
//
///////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////
//
//	Local Types and Variables and Global variables
//
///////////////////////////////////////////////////////////////////////////

AFilePackMan g_AFilePackMan;

// for 0x00020003 version

struct SAFEFILEHEADER_0x00020003
{
	DWORD	tag1;			//	tag1 of safe header, current it is 0x4DCA23EF
	UINT64	offset;			//	offset of real entries
	//DWORD	tag2;			//	tag2 of safe header, current it is 0x56a089b7
};

struct FILEHEADER_0x00020003
{
	DWORD	guardByte0;				//	0xabcdefab
	DWORD	dwVersion;				//	Composed by two word version, major part and minor part;
	UINT64	dwEntryOffset;			//	The entry list offset from the beginning;
	DWORD	dwFlags;				//	package flags. the highest bit means the encrypt state;
	char	szDescription[252];		//	Description
	DWORD	guardByte1;				//	0xffeeffee
	DWORD	UNKNOWN;
};

struct FILEENTRY_0x00020003
{
	char	szFileName[MAX_PATH];	//	The file name of this entry; this may contain a path;
	DWORD	Zalupa0;
	UINT64	dwOffset;				//	The offset from the beginning of the package file;
	DWORD	dwLength;				//	The length of this file;
	DWORD	dwCompressedLength;		//	The compressed data length;
	DWORD	Zalupa1;

	int		iAccessCnt;				//	Access counter used by OpenSharedFile
};

// for 0x00020003 version END

///////////////////////////////////////////////////////////////////////////
//
//	Local functions
//
///////////////////////////////////////////////////////////////////////////

static int _CacheFileNameCompare(const void *arg1, const void *arg2)
{
	AFilePackage::CACHEFILENAME* pFile1 = *(AFilePackage::CACHEFILENAME**)arg1;
	AFilePackage::CACHEFILENAME* pFile2 = *(AFilePackage::CACHEFILENAME**)arg2;

	if (pFile1->dwFileID > pFile2->dwFileID)
		return 1;
	else if (pFile1->dwFileID < pFile2->dwFileID)
		return -1;
	else
		return 0;
}

///////////////////////////////////////////////////////////////////////////
//
//	Implement of AFilePackage::directory
//
///////////////////////////////////////////////////////////////////////////

int
AFilePackage::directory::searchItemIndex(const char * name, int * pos)
{
	int left, right, mid;
	left = 0;
	right = _list.size() - 1;
	mid = 0;
	while (left <= right)
	{
		mid = (left + right) / 2;
		int rst = _stricmp(name, _list[mid]->_name);
		if (rst < 0)
		{
			right = mid - 1;
		}
		else if (rst > 0)
		{
			left = mid + 1;
		}
		else
		{
			return mid;
		}
	}
	if (pos) *pos = mid;
	return -1;
}

AFilePackage::entry*
AFilePackage::directory::SearchItem(const char * name)
{
	int idx = searchItemIndex(name, NULL);
	if (idx < 0)
		return NULL;
	else
		return _list[idx];
}


int
AFilePackage::directory::RemoveItem(const char * name)
{
	int rst;
	rst = searchItemIndex(name, NULL);
	if (rst < 0) return -1;
	delete _list[rst];
	_list.erase(_list.begin() + rst);
	return 0;
}

AFilePackage::entry* AFilePackage::directory::GetItem(int index)
{
	if (index < 0 || index >= (int)(_list.size())) return NULL;
	return _list[index];
}

int AFilePackage::directory::AppendEntry(entry * item)
{
	int pos;
	if (searchItemIndex(item->_name, &pos) >= 0)
	{
		//ГыЧЦЦШёґ
		return -1;
	}

	if (pos >= (int)(_list.size()))
	{
		_list.push_back(item);
	}
	else
	{
		int rst = _stricmp(item->_name, _list[pos]->_name);
		if (rst < 0)
		{
			_list.insert(_list.begin() + pos, item);
		}
		else
		{
			_list.insert(_list.begin() + (pos + 1), item);
		}
	}
	return 0;
}

int AFilePackage::directory::SearchEntry(const char * filename)
{
	char name[MAX_PATH];
	strcpy(name, filename);
	char * tok;
	tok = strtok(name, "\\");
	entry * ent = this;
	while (tok)
	{
		char * next = strtok(NULL, "\\");
		entry * tmp = ent->SearchItem(tok);
		if (tmp == NULL) return -1;
		if (next)
		{
			if (tmp->IsContainer())
			{
				ent = tmp;
			}
			else
			{
				return -1;
			}
		}
		else
		{
			return tmp->GetIndex();
		}
		tok = next;
	}
	return -1;
}


int AFilePackage::directory::clear()
{
	size_t i;
	for (i = 0; i < _list.size(); i++)
	{
		delete _list[i];
	}
	_list.clear();
	return 0;
}


AFilePackage::directory::~directory()
{
	clear();
}

///////////////////////////////////////////////////////////////////////////
//
//	Implement of AFilePackage
//
///////////////////////////////////////////////////////////////////////////

AFilePackage::AFilePackage() :
	m_aFileEntries(0, 100),
	m_aFileEntryCache(0, 100),
	m_CachedFileTab(128),
	m_SharedFileTab(128)
{
	m_bHasChanged = false;
	m_bReadOnly = false;
	m_bUseShortName = false;
	m_fpPackageFile = NULL;
	m_dwSharedSize = 0;
	m_dwCacheSize = 0;
	m_szPckFileName[0] = '\0';

	InitializeCriticalSection(&m_csFR);
	InitializeCriticalSection(&m_csSF);

	m_bHasSafeHeader = false;
}

AFilePackage::~AFilePackage()
{
	DeleteCriticalSection(&m_csFR);
	DeleteCriticalSection(&m_csSF);
}

bool AFilePackage::InnerOpen(const char* szPckPath, const char* szFolder, OPENMODE mode, bool bEncrypt, bool bShortName)
{
	char szFullPckPath[MAX_PATH];
	af_GetFullPath(szFullPckPath, szPckPath);

	m_bUseShortName = bShortName;

	//	Save folder name
	ASSERT(szFolder);
	strncpy(m_szFolder, szFolder, MAX_PATH);
	_strlwr(m_szFolder);
	NormalizeFileName(m_szFolder);

	//	Add '//' at folder tail
	int iFolderLen = strlen(m_szFolder);
	if (m_szFolder[iFolderLen - 1] != '\\')
	{
		m_szFolder[iFolderLen] = '\\';
		m_szFolder[iFolderLen + 1] = '\0';
	}

	switch (mode)
	{
	case OPENEXIST:
		m_bReadOnly = false;
		m_fpPackageFile = new CPackageFile();

		if (!m_fpPackageFile->Open(szFullPckPath, "r+b"))
		{
			if (!m_fpPackageFile->Open(szFullPckPath, "rb"))
			{
				delete m_fpPackageFile;
				m_fpPackageFile = NULL;

				AFERRLOG(("AFilePackage::Open(), Can not open file [%s]", szFullPckPath));
				return false;
			}
			m_bReadOnly = true;
		}

		strncpy(m_szPckFileName, szPckPath, MAX_PATH);

		LoadSafeHeader();

		int nOffset;
		m_fpPackageFile->seek(0, SEEK_END);
		nOffset = m_fpPackageFile->tell();
		m_fpPackageFile->seek(0, SEEK_SET);

		if (m_bHasSafeHeader)
			nOffset = (int)m_safeHeader.offset;

		// Now analyse the file entries of the package;
		DWORD dwVersion;

		// First version;
		m_fpPackageFile->seek(nOffset - sizeof(DWORD), SEEK_SET);
		m_fpPackageFile->read(&dwVersion, sizeof(DWORD), 1);

		if (dwVersion == 0x00020003)
		{
			int i, iNumFile;

			FILEHEADER_0x00020003 tempHeader;
			// Now read file number;
			m_fpPackageFile->seek(nOffset - (sizeof(int) + sizeof(DWORD)), SEEK_SET);
			m_fpPackageFile->read(&iNumFile, sizeof(int), 1);
			m_fpPackageFile->seek(nOffset - (sizeof(FILEHEADER_0x00020003) + sizeof(DWORD) + sizeof(int)), SEEK_SET);
			m_fpPackageFile->read(&tempHeader, sizeof(FILEHEADER_0x00020003), 1);
			//copy to main header
			{
				m_header.guardByte0 = tempHeader.guardByte0;
				m_header.dwVersion = tempHeader.dwVersion;
				m_header.dwEntryOffset = tempHeader.dwEntryOffset;
				m_header.dwFlags = tempHeader.dwFlags;
				strncpy(m_header.szDescription, tempHeader.szDescription, sizeof(tempHeader.szDescription));
				m_header.guardByte1 = tempHeader.guardByte1;
			}
			if (strstr(m_header.szDescription, "lica File Package") == NULL)
				return false;
			strncpy(m_header.szDescription, COPYRIGHT_TAG, sizeof(m_header.szDescription));

			// if we don't expect one encrypt package, we will let the error come out.
			// make sure the encrypt flag is correct
			bool bPackIsEncrypt = (m_header.dwFlags & 0x80000000) != 0;
			if (bEncrypt != bPackIsEncrypt)
			{
				AFERRLOG(("AFilePackage::Open(), wrong encrypt flag"));
				return false;
			}

			m_header.dwEntryOffset ^= AFPCK_MASKDWORD;

			if (m_header.guardByte0 != AFPCK_GUARDBYTE0 ||
				m_header.guardByte1 != AFPCK_GUARDBYTE1)
			{
				// corrput file
				AFERRLOG(("AFilePackGame::Open(), GuardBytes corrupted [%s]", szPckPath));
				return false;
			}

			//	Seek to entry list;
			m_fpPackageFile->seek(m_header.dwEntryOffset, SEEK_SET);

			//	Create entries
			m_aFileEntries.SetSize(iNumFile, 100);
			m_aFileEntryCache.SetSize(iNumFile, 100);

			for (i = 0; i < iNumFile; i++)
			{
				FILEENTRY* pEntry = new FILEENTRY;
				if (!pEntry)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory!"));
					return false;
				}

				FILEENTRY_0x00020003* tempEntry = new FILEENTRY_0x00020003;
				if (!tempEntry)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory!"));
					return false;
				}
				tempEntry->iAccessCnt = 0;

				FILEENTRYCACHE* pEntryCache = new FILEENTRYCACHE;
				if (!pEntryCache)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory!"));
					return false;
				}
				memset(pEntryCache, 0, sizeof(FILEENTRYCACHE));

				// first read the entry size after compressed
				int nCompressedSize;
				m_fpPackageFile->read(&nCompressedSize, sizeof(int), 1);
				nCompressedSize ^= AFPCK_MASKDWORD;

				int nCheckSize;
				m_fpPackageFile->read(&nCheckSize, sizeof(int), 1);
				nCheckSize = nCheckSize ^ AFPCK_CHECKMASK ^ AFPCK_MASKDWORD;

				if (nCompressedSize != nCheckSize)
				{
					AFERRLOG(("AFilePackage::Open(), Check Byte Error!"));
					return false;
				}

				pEntryCache->dwCompressedLength = nCompressedSize;
				pEntryCache->pEntryCompressed = (BYTE*)a_malloc(nCompressedSize);
				if (!pEntryCache->pEntryCompressed)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory !"));
					return false;
				}

				m_fpPackageFile->read(pEntryCache->pEntryCompressed, nCompressedSize, 1);
				DWORD dwEntrySize = sizeof(FILEENTRY_0x00020003);

				if (dwEntrySize == nCompressedSize)
				{
					memcpy(tempEntry, pEntryCache->pEntryCompressed, sizeof(FILEENTRY_0x00020003));

					// maybe the original package fileentry has not been compressed
					DWORD dwCompressedSize = sizeof(FILEENTRY_0x00020003);
					BYTE * pBuffer = (BYTE *)a_malloc(sizeof(FILEENTRY_0x00020003));
					int nRet = Compress((LPBYTE)tempEntry, sizeof(FILEENTRY_0x00020003), pBuffer, &dwCompressedSize);
					if (nRet != 0 || dwCompressedSize >= sizeof(FILEENTRY_0x00020003))
					{
						dwCompressedSize = sizeof(FILEENTRY_0x00020003);
						memcpy(pBuffer, tempEntry, sizeof(FILEENTRY_0x00020003));
					}
					pEntryCache->dwCompressedLength = dwCompressedSize;
					pEntryCache->pEntryCompressed = (BYTE *)a_realloc(pEntryCache->pEntryCompressed, dwCompressedSize);
					memcpy(pEntryCache->pEntryCompressed, pBuffer, dwCompressedSize);
					a_free(pBuffer);
				}
				else
				{
					if (0 != Uncompress(pEntryCache->pEntryCompressed, nCompressedSize, (LPBYTE)tempEntry, &dwEntrySize))
					{
						AFERRLOG(("AFilePackage::Open(), decode file entry fail!"));
						return false;
					}

					//ASSERT(dwEntrySize == sizeof(FILEENTRY));
				}

				//	Duplicate entry info
				strncpy(pEntry->szFileName, tempEntry->szFileName, sizeof(tempEntry->szFileName));
				pEntry->dwLength = tempEntry->dwLength;
				pEntry->dwCompressedLength = tempEntry->dwCompressedLength;
				pEntry->dwOffset = tempEntry->dwOffset;

				m_aFileEntries[i] = pEntry;
				m_aFileEntryCache[i] = pEntryCache;
			}

			ResortEntries();

			// now we move entry point to the end of the file so to keep old entries here
			if (m_bHasSafeHeader)
				m_header.dwEntryOffset = nOffset;
		}
		else if (dwVersion == 0x00020002 || dwVersion == 0x00020001)
		{
			int i, iNumFile;

			// Now read file number;
			m_fpPackageFile->seek(nOffset - (sizeof(int) + sizeof(DWORD)), SEEK_SET);
			m_fpPackageFile->read(&iNumFile, sizeof(int), 1);
			m_fpPackageFile->seek(nOffset - (sizeof(FILEHEADER) + sizeof(DWORD) + sizeof(int)), SEEK_SET);
			m_fpPackageFile->read(&m_header, sizeof(FILEHEADER), 1);
			if (strstr(m_header.szDescription, "lica File Package") == NULL)
				return false;
			strncpy(m_header.szDescription, COPYRIGHT_TAG, sizeof(m_header.szDescription));

			// if we don't expect one encrypt package, we will let the error come out.
			// make sure the encrypt flag is correct
			if (bEncrypt)
			{
				if (0 == (m_header.dwFlags & 0x80000000))
				{
					AFERRLOG(("AFilePackage::Open(), wrong encrypt flag"));
					return false;
				}
			}
			else
			{
				if (m_header.dwFlags & 0x80000000)
				{
					AFERRLOG(("AFilePackage::Open(), wrong encrypt flag"));
					return false;
				}
			}

			m_header.dwEntryOffset ^= AFPCK_MASKDWORD;

			if (m_header.guardByte0 != AFPCK_GUARDBYTE0 ||
				m_header.guardByte1 != AFPCK_GUARDBYTE1)
			{
				// corrput file
				AFERRLOG(("AFilePackage::Open(), GuardBytes corrupted [%s]", szPckPath));
				return false;
			}

			//	Seek to entry list;
			m_fpPackageFile->seek(m_header.dwEntryOffset, SEEK_SET);

			//	Create entries
			m_aFileEntries.SetSize(iNumFile, 100);
			m_aFileEntryCache.SetSize(iNumFile, 100);

			for (i = 0; i < iNumFile; i++)
			{
				FILEENTRY* pEntry = new FILEENTRY;
				if (!pEntry)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory!"));
					return false;
				}
				pEntry->iAccessCnt = 0;

				FILEENTRYCACHE* pEntryCache = new FILEENTRYCACHE;
				if (!pEntryCache)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory!"));
					return false;
				}
				memset(pEntryCache, 0, sizeof(FILEENTRYCACHE));

				// first read the entry size after compressed
				int nCompressedSize;
				m_fpPackageFile->read(&nCompressedSize, sizeof(int), 1);
				nCompressedSize ^= AFPCK_MASKDWORD;

				int nCheckSize;
				m_fpPackageFile->read(&nCheckSize, sizeof(int), 1);
				nCheckSize = nCheckSize ^ AFPCK_CHECKMASK ^ AFPCK_MASKDWORD;

				if (nCompressedSize != nCheckSize)
				{
					AFERRLOG(("AFilePackage::Open(), Check Byte Error!"));
					return false;
				}

				pEntryCache->dwCompressedLength = nCompressedSize;
				pEntryCache->pEntryCompressed = (BYTE*)a_malloc(nCompressedSize);
				if (!pEntryCache->pEntryCompressed)
				{
					AFERRLOG(("AFilePackage::Open(), Not enough memory !"));
					return false;
				}

				m_fpPackageFile->read(pEntryCache->pEntryCompressed, nCompressedSize, 1);
				DWORD dwEntrySize = sizeof(FILEENTRY);

				if (dwEntrySize == nCompressedSize)
				{
					memcpy(pEntry, pEntryCache->pEntryCompressed, sizeof(FILEENTRY));

					// maybe the original package fileentry has not been compressed
					DWORD dwCompressedSize = sizeof(FILEENTRY);
					BYTE * pBuffer = (BYTE *)a_malloc(sizeof(FILEENTRY));
					int nRet = Compress((LPBYTE)pEntry, sizeof(FILEENTRY), pBuffer, &dwCompressedSize);
					if (nRet != 0 || dwCompressedSize >= sizeof(FILEENTRY))
					{
						dwCompressedSize = sizeof(FILEENTRY);
						memcpy(pBuffer, pEntry, sizeof(FILEENTRY));
					}
					pEntryCache->dwCompressedLength = dwCompressedSize;
					pEntryCache->pEntryCompressed = (BYTE *)a_realloc(pEntryCache->pEntryCompressed, dwCompressedSize);
					memcpy(pEntryCache->pEntryCompressed, pBuffer, dwCompressedSize);
					a_free(pBuffer);
				}
				else
				{
					if (0 != Uncompress(pEntryCache->pEntryCompressed, nCompressedSize, (LPBYTE)pEntry, &dwEntrySize))
					{
						AFERRLOG(("AFilePackage::Open(), decode file entry fail!"));
						return false;
					}

					ASSERT(dwEntrySize == sizeof(FILEENTRY));
				}

				m_aFileEntries[i] = pEntry;
				m_aFileEntryCache[i] = pEntryCache;
			}

			ResortEntries();

			// now we move entry point to the end of the file so to keep old entries here
			if (m_bHasSafeHeader)
				m_header.dwEntryOffset = nOffset;
		}
		else
		{
			AFERRLOG(("AFilePackage::Open(), Incorrect version!"));
			return false;
		}

		break;

	case CREATENEW:
		m_bReadOnly = false;
		m_fpPackageFile = new CPackageFile();

		if (!m_fpPackageFile->Open(szFullPckPath, "wb"))
		{
			delete m_fpPackageFile;
			m_fpPackageFile = NULL;

			AFERRLOG(("AFilePackage::Open(), Can not create file [%s]", szFullPckPath));
			return false;
		}
		strncpy(m_szPckFileName, szPckPath, MAX_PATH);

		CreateSafeHeader();

		// Init header;
		ZeroMemory(&m_header, sizeof(FILEHEADER));
		m_header.guardByte0 = AFPCK_GUARDBYTE0;
		m_header.dwEntryOffset = sizeof(SAFEFILEHEADER);
		m_header.dwVersion = AFPCK_VERSION;
		m_header.dwFlags = bEncrypt ? 0x80000000 : 0;
		m_header.guardByte1 = AFPCK_GUARDBYTE1;
		strncpy(m_header.szDescription, COPYRIGHT_TAG, sizeof(m_header.szDescription));

		m_aFileEntries.RemoveAll();
		m_aFileEntryCache.RemoveAll();
		break;

	default:

		AFERRLOG(("AFilePackage::Open(), Unknown open mode [%d]!", mode));
		return false;
	}

	m_mode = mode;
	m_bHasChanged = false;
	m_dwSharedSize = 0;
	m_dwCacheSize = 0;

	return true;
}

bool AFilePackage::Open(const char* szPckPath, const char* szFolder, OPENMODE mode, bool bEncrypt/* false */)
{
	return InnerOpen(szPckPath, szFolder, mode, bEncrypt, true);
}

bool AFilePackage::Open(const char* szPckPath, OPENMODE mode, bool bEncrypt)
{
	char szFolder[MAX_PATH];

	strncpy(szFolder, szPckPath, MAX_PATH);
	if (szFolder[0] == '\0')
	{
		AFERRLOG(("AFilePackage::Open(), can not open a null or empty file name!"));
		return false;
	}
	char* pext = szFolder + strlen(szFolder) - 1;
	while (pext != szFolder)
	{
		if (*pext == '.')
			break;

		pext--;
	}

	if (pext == szFolder)
	{
		AFERRLOG(("AFilePackage::Open(), only file with extension can be opened!"));
		return false;
	}

	*pext++ = '\\';
	*pext = '\0';

	return InnerOpen(szPckPath, szFolder, mode, bEncrypt, false);
}

bool AFilePackage::Close()
{
	switch (m_mode)
	{
	case OPENEXIST:

		if (m_bHasChanged)
		{
			DWORD dwFileSize = m_header.dwEntryOffset;

			DWORD dwEntrySize = 0;
			if (!SaveEntries(&dwEntrySize))
				return false;
			dwFileSize += dwEntrySize;

			// Write file header here;
			m_header.dwEntryOffset ^= AFPCK_MASKDWORD;
			m_fpPackageFile->write(&m_header, sizeof(FILEHEADER), 1);
			m_header.dwEntryOffset ^= AFPCK_MASKDWORD;
			dwFileSize += sizeof(FILEHEADER);

			int iNumFile = m_aFileEntries.GetSize();
			m_fpPackageFile->write(&iNumFile, sizeof(int), 1);
			dwFileSize += sizeof(int);
			m_fpPackageFile->write(&m_header.dwVersion, sizeof(DWORD), 1);
			dwFileSize += sizeof(DWORD);

			m_fpPackageFile->SetPackageFileSize(dwFileSize);

			SaveSafeHeader();
			m_bHasChanged = false;
		}

		break;

	case CREATENEW:
	{
		int iNumFile = m_aFileEntries.GetSize();

		if (!SaveEntries())
			return false;

		// Write file header here;
		m_header.dwEntryOffset ^= AFPCK_MASKDWORD;
		m_fpPackageFile->write(&m_header, sizeof(FILEHEADER), 1);
		m_header.dwEntryOffset ^= AFPCK_MASKDWORD;

		m_fpPackageFile->write(&iNumFile, sizeof(int), 1);
		m_fpPackageFile->write(&m_header.dwVersion, sizeof(DWORD), 1);

		SaveSafeHeader();
		break;
	}
	}

	if (m_fpPackageFile)
	{
		m_fpPackageFile->Close();
		delete m_fpPackageFile;
		m_fpPackageFile = NULL;
	}

	int i, iUnClosed = 0;

	//	Release entries
	for (i = 0; i < m_aFileEntries.GetSize(); i++)
		delete m_aFileEntries[i];

	//	Release entries cache
	for (i = 0; i < m_aFileEntryCache.GetSize(); i++)
	{
		if (m_aFileEntryCache[i]->pEntryCompressed)
		{
			a_free(m_aFileEntryCache[i]->pEntryCompressed);
			m_aFileEntryCache[i]->pEntryCompressed = NULL;
		}
		delete m_aFileEntryCache[i];
	}

	m_aFileEntries.RemoveAll();
	m_aFileEntryCache.RemoveAll();

	//	Release all shared files
	SharedTable::iterator it1 = m_SharedFileTab.begin();
	for (; it1 != m_SharedFileTab.end(); ++it1)
	{
		SHAREDFILE* pFileItem = *it1.value();
		if (pFileItem->iRefCnt)
			iUnClosed++;

		a_free(pFileItem->pFileData);
		delete pFileItem;
	}

	m_SharedFileTab.clear();

	if (iUnClosed)
		AFERRLOG(("AFilePackage::Close(), %d file in package weren't closed !", iUnClosed));

	//	Release cache file list
	CachedTable::iterator it2 = m_CachedFileTab.begin();
	for (; it2 != m_CachedFileTab.end(); ++it2)
	{
		CACHEFILENAME* pItem = *it2.value();
		delete pItem;
	}

	m_CachedFileTab.clear();

	return true;
}

//	Get rid of folder from file
void AFilePackage::GetRidOfFolder(const char* szInName, char* szOutName)
{
	af_GetRelativePathNoBase(szInName, m_szFolder, szOutName);
}

bool AFilePackage::NormalizeFileName(char* szFileName)
{
	int i, nLength;

	nLength = strlen(szFileName);

	//	First we should unite the path seperator to '\'
	for (i = 0; i < nLength; i++)
	{
		if (szFileName[i] == '/')
			szFileName[i] = '\\';
	}

	//	Get rid of the preceding .\ string
	if (nLength > 2 && szFileName[0] == '.' && szFileName[1] == '\\')
	{
		for (i = 0; i < nLength - 2; i++)
			szFileName[i] = szFileName[i + 2];

		szFileName[i] = '\0';
	}

	//	Get rid of extra space at the tail of the string;
	nLength = strlen(szFileName);

	for (i = nLength - 1; i >= 0; i--)
	{
		if (szFileName[i] != ' ')
			break;
		else
			szFileName[i] = '\0';
	}

	return true;
}

//	Normalize file name
bool AFilePackage::NormalizeFileName(char* szFileName, bool bUseShortName)
{
	if (!NormalizeFileName(szFileName))
		return false;

	//	Get rid of folder from file name
	if (bUseShortName)
	{
		char szFullName[MAX_PATH];
		strcpy(szFullName, szFileName);
		GetRidOfFolder(szFullName, szFileName);
	}

	return true;
}

bool AFilePackage::GetFileEntry(const char* szFileName, FILEENTRY* pFileEntry, int* pnIndex)
{
	char szFindName[MAX_PATH];

	//	Normalize file name
	strncpy(szFindName, szFileName, MAX_PATH);
	NormalizeFileName(szFindName, m_bUseShortName);

	ZeroMemory(pFileEntry, sizeof(FILEENTRY));

	int iEntry = m_directory.SearchEntry(szFindName);
	if (iEntry < 0)
		return false;

	*pFileEntry = *m_aFileEntries[iEntry];

	if (pnIndex)
		*pnIndex = iEntry;

	return true;
}

void AFilePackage::Encrypt(LPBYTE pBuffer, DWORD dwLength)
{
	if (m_header.dwFlags != 0x80000000)
		return;

	DWORD dwMask = dwLength + 0x739802ab;

	for (unsigned int i = 0; i < dwLength; i += 4)
	{
		if (i + 3 < dwLength)
		{
			DWORD data = (pBuffer[i] << 24) | (pBuffer[i + 1] << 16) | (pBuffer[i + 2] << 8) | pBuffer[i + 3];
			data ^= dwMask;
			data = (data << 16) | ((data >> 16) & 0xffff);
			pBuffer[i] = (BYTE)((data >> 24) & 0xff);
			pBuffer[i + 1] = (BYTE)((data >> 16) & 0xff);
			pBuffer[i + 2] = (BYTE)((data >> 8) & 0xff);
			pBuffer[i + 3] = (BYTE)(data & 0xff);
		}
	}
}

void AFilePackage::Decrypt(LPBYTE pBuffer, DWORD dwLength)
{
	if (m_header.dwFlags != 0x80000000)
		return;

	DWORD dwMask = dwLength + 0x739802ab;

	for (unsigned int i = 0; i < dwLength; i += 4)
	{
		if (i + 3 < dwLength)
		{
			DWORD data = (pBuffer[i] << 24) | (pBuffer[i + 1] << 16) | (pBuffer[i + 2] << 8) | pBuffer[i + 3];
			data = (data << 16) | ((data >> 16) & 0xffff);
			data ^= dwMask;
			pBuffer[i] = (BYTE)((data >> 24) & 0xff);
			pBuffer[i + 1] = (BYTE)((data >> 16) & 0xff);
			pBuffer[i + 2] = (BYTE)((data >> 8) & 0xff);
			pBuffer[i + 3] = (BYTE)(data & 0xff);
		}
	}
}

bool AFilePackage::ReadFile(const char* szFileName, LPBYTE pFileBuffer, DWORD* pdwBufferLen)
{
	FILEENTRY fileEntry;

	if (!GetFileEntry(szFileName, &fileEntry))
	{
		AFERRLOG(("AFilePackage::ReadFile(), Can not find file entry [%s]!", szFileName));
		return false;
	}

	return ReadFile(fileEntry, pFileBuffer, pdwBufferLen);
}

bool AFilePackage::ReadFile(FILEENTRY& fileEntry, LPBYTE pFileBuffer, DWORD * pdwBufferLen)
{
	if (*pdwBufferLen < fileEntry.dwLength)
	{
		AFERRLOG(("AFilePackage::ReadFile(), Buffer is too small!"));
		return false;
	}

	// We can automaticly determine whether compression has been used;
	if (fileEntry.dwLength > fileEntry.dwCompressedLength)
	{
		DWORD dwFileLength = fileEntry.dwLength;
		BYTE* pBuffer = (BYTE*)a_malloc(fileEntry.dwCompressedLength);
		if (!pBuffer)
			return false;

		ACSWrapper csa(&m_csFR);
		m_fpPackageFile->seek(fileEntry.dwOffset, SEEK_SET);
		m_fpPackageFile->read(pBuffer, fileEntry.dwCompressedLength, 1);
		Decrypt(pBuffer, fileEntry.dwCompressedLength);

		csa.Detach(true);

		if (0 != Uncompress(pBuffer, fileEntry.dwCompressedLength, pFileBuffer, &dwFileLength))
		{
			FILE * fp = fopen("logs\\bad.dat", "wb");
			fwrite(pBuffer, fileEntry.dwCompressedLength, 1, fp);
			fclose(fp);

			a_free(pBuffer);
			return false;
		}

		//uncompress(pFileBuffer, &dwFileLength, m_pBuffer, fileEntry.dwCompressedLength);

		*pdwBufferLen = dwFileLength;

		a_free(pBuffer);
	}
	else
	{
		ACSWrapper csa(&m_csFR);
		m_fpPackageFile->seek(fileEntry.dwOffset, SEEK_SET);
		m_fpPackageFile->read(pFileBuffer, fileEntry.dwLength, 1);
		Decrypt(pFileBuffer, fileEntry.dwLength);
		csa.Detach(true);

		*pdwBufferLen = fileEntry.dwLength;
	}

	return true;
}

bool AFilePackage::ReadCompressedFile(const char* szFileName, LPBYTE pCompressedBuffer, DWORD* pdwBufferLen)
{
	FILEENTRY fileEntry;

	if (!GetFileEntry(szFileName, &fileEntry))
	{
		AFERRLOG(("AFilePackage::ReadCompressedFile(), Can not find file entry [%s]!", szFileName));
		return false;
	}

	return ReadCompressedFile(fileEntry, pCompressedBuffer, pdwBufferLen);
}

bool AFilePackage::ReadCompressedFile(FILEENTRY& fileEntry, LPBYTE pCompressedBuffer, DWORD * pdwBufferLen)
{
	if (*pdwBufferLen < fileEntry.dwCompressedLength)
	{
		AFERRLOG(("AFilePackage::ReadCompressedFile(), Buffer is too small!"));
		return false;
	}

	ACSWrapper csa(&m_csFR);

	m_fpPackageFile->seek(fileEntry.dwOffset, SEEK_SET);
	*pdwBufferLen = m_fpPackageFile->read(pCompressedBuffer, 1, fileEntry.dwCompressedLength);
	Decrypt(pCompressedBuffer, fileEntry.dwCompressedLength);

	return true;
}

bool AFilePackage::AppendFile(const char* szFileName, LPBYTE pFileBuffer, DWORD dwFileLength, bool bCompress)
{
	// We should use a function to check whether szFileName has been added into the package;
	if (m_bReadOnly)
	{
		AFERRLOG(("AFilePackage::AppendFile(), Read only package, can not append!"));
		return false;
	}

	FILEENTRY fileEntry;
	if (GetFileEntry(szFileName, &fileEntry))
	{
		AFERRLOG(("AFilePackage::AppendFile(), file entry [%s] already exist!", szFileName));
		return false;
	}

	DWORD dwCompressedLength = dwFileLength;
	if (bCompress)
	{
		//	Compress the file
		BYTE* pBuffer = (BYTE*)a_malloc(dwFileLength);
		if (!pBuffer)
			return false;

		if (0 != Compress(pFileBuffer, dwFileLength, pBuffer, &dwCompressedLength))
		{
			//compress error, so use uncompressed format
			dwCompressedLength = dwFileLength;
		}

		//compress2(m_pBuffer, &dwCompressedLength, pFileBuffer, dwFileLength, 1);

		if (dwCompressedLength < dwFileLength)
		{
			if (!AppendFileCompressed(szFileName, pBuffer, dwFileLength, dwCompressedLength))
			{
				a_free(pBuffer);
				return false;
			}
		}
		else
		{
			if (!AppendFileCompressed(szFileName, pFileBuffer, dwFileLength, dwFileLength))
			{
				a_free(pBuffer);
				return false;
			}
		}

		a_free(pBuffer);
	}
	else
	{
		if (!AppendFileCompressed(szFileName, pFileBuffer, dwFileLength, dwFileLength))
			return false;
	}

	return true;
}

bool AFilePackage::AppendFileCompressed(const char* szFileName, LPBYTE pCompressedFileBuffer, DWORD dwFileLength, DWORD dwCompressedLength)
{
	FILEENTRY* pEntry = new FILEENTRY;
	if (!pEntry)
	{
		AFERRLOG(("AFilePackage::AppendFile(), Not enough memory!"));
		return false;
	}

	char szSavedFileName[MAX_PATH];
	if (m_bUseShortName)
	{
		//	Get rid of folder from file name
		strcpy(szSavedFileName, szFileName);
		NormalizeFileName(szSavedFileName, m_bUseShortName);
		szFileName = szSavedFileName;
	}

	//	Store this file;
	strncpy(pEntry->szFileName, szFileName, MAX_PATH);
	pEntry->dwOffset = m_header.dwEntryOffset;
	pEntry->dwLength = dwFileLength;
	pEntry->dwCompressedLength = dwCompressedLength;
	pEntry->iAccessCnt = 0;
	m_aFileEntries.Add(pEntry);

	FILEENTRYCACHE* pEntryCache = new FILEENTRYCACHE;
	if (!pEntryCache)
	{
		AFERRLOG(("AFilePackage::AppendFile(), Not enough memory!"));
		return false;
	}
	DWORD dwCompressedSize = sizeof(FILEENTRY);
	BYTE * pBuffer = (BYTE *)a_malloc(sizeof(FILEENTRY));
	int nRet = Compress((LPBYTE)pEntry, sizeof(FILEENTRY), pBuffer, &dwCompressedSize);
	if (nRet != 0 || dwCompressedSize >= sizeof(FILEENTRY))
	{
		dwCompressedSize = sizeof(FILEENTRY);
		memcpy(pBuffer, pEntry, sizeof(FILEENTRY));
	}
	pEntryCache->dwCompressedLength = dwCompressedSize;
	pEntryCache->pEntryCompressed = (BYTE *)a_malloc(dwCompressedSize);
	memcpy(pEntryCache->pEntryCompressed, pBuffer, dwCompressedSize);
	m_aFileEntryCache.Add(pEntryCache);
	a_free(pBuffer);

	m_fpPackageFile->seek(m_header.dwEntryOffset, SEEK_SET);

	//	We write the compressed buffer into the disk;
	Encrypt(pCompressedFileBuffer, dwCompressedLength);
	m_fpPackageFile->write(pCompressedFileBuffer, dwCompressedLength, 1);
	Decrypt(pCompressedFileBuffer, dwCompressedLength);
	m_header.dwEntryOffset += dwCompressedLength;

	InsertFileToDir(szFileName, m_aFileEntries.GetSize() - 1);
	m_bHasChanged = true;

	return true;
}

bool AFilePackage::RemoveFile(const char* szFileName)
{
	if (m_bReadOnly)
	{
		AFERRLOG(("AFilePackage::RemoveFile(), Read only package, can not remove file!"));
		return false;
	}

	FILEENTRY Entry;
	int	nIndex;

	if (!GetFileEntry(szFileName, &Entry, &nIndex))
	{
		AFERRLOG(("AFilePackage::RemoveFile(), Can not find file %s", szFileName));
		return false;
	}

	//	We only remove the file's entry, but leave the file's body there
	FILEENTRY* pEntry = m_aFileEntries[nIndex];
	delete pEntry;
	m_aFileEntries.RemoveAt(nIndex);

	FILEENTRYCACHE* pEntryCache = m_aFileEntryCache[nIndex];
	if (pEntryCache)
	{
		if (pEntryCache->pEntryCompressed)
		{
			a_free(pEntryCache->pEntryCompressed);
		}
		delete pEntryCache;
	}
	m_aFileEntryCache.RemoveAt(nIndex);

	ResortEntries();

	m_bHasChanged = true;
	return true;
}

bool AFilePackage::ReplaceFile(const char* szFileName, LPBYTE pFileBuffer, DWORD dwFileLength, bool bCompress)
{
	//	We only add a new file copy at the end of the file part, and modify the 
	//	file entry point to that file body;
	DWORD dwCompressedLength = dwFileLength;

	if (bCompress)
	{
		//	Try to compress the file
		BYTE* pBuffer = (BYTE*)a_malloc(dwFileLength);
		if (!pBuffer)
			return false;

		if (0 != Compress(pFileBuffer, dwFileLength, pBuffer, &dwCompressedLength))
		{
			//compress error, so use uncompressed format
			dwCompressedLength = dwFileLength;
		}

		//compress2(m_pBuffer, &dwCompressedLength, pFileBuffer, dwFileLength, 1);

		if (dwCompressedLength < dwFileLength)
		{
			if (!ReplaceFileCompressed(szFileName, pBuffer, dwFileLength, dwCompressedLength))
			{
				a_free(pBuffer);
				return false;
			}
		}
		else
		{
			if (!ReplaceFileCompressed(szFileName, pFileBuffer, dwFileLength, dwFileLength))
			{
				a_free(pBuffer);
				return false;
			}
		}

		a_free(pBuffer);
	}
	else
	{
		if (!ReplaceFileCompressed(szFileName, pFileBuffer, dwFileLength, dwFileLength))
			return false;
	}


	return true;
}

bool AFilePackage::ReplaceFileCompressed(const char * szFileName, LPBYTE pCompressedBuffer, DWORD dwFileLength, DWORD dwCompressedLength)
{
	if (m_bReadOnly)
	{
		AFERRLOG(("AFilePackage::ReplaceFileCompressed(), Read only package, can not replace!"));
		return false;
	}

	FILEENTRY Entry;
	int	nIndex;

	if (!GetFileEntry(szFileName, &Entry, &nIndex))
	{
		AFERRLOG(("AFilePackage::ReplaceFile(), Can not find file %s", szFileName));
		return false;
	}

	FILEENTRY* pEntry = m_aFileEntries[nIndex];
	// modify this file entry to point to the new file body;			
	pEntry->dwOffset = m_header.dwEntryOffset;
	pEntry->dwLength = dwFileLength;
	pEntry->dwCompressedLength = dwCompressedLength;

	FILEENTRYCACHE* pEntryCache = m_aFileEntryCache[nIndex];
	DWORD dwCompressedSize = sizeof(FILEENTRY);
	BYTE * pBuffer = (BYTE *)a_malloc(sizeof(FILEENTRY));
	int nRet = Compress((LPBYTE)pEntry, sizeof(FILEENTRY), pBuffer, &dwCompressedSize);
	if (nRet != 0 || dwCompressedSize >= sizeof(FILEENTRY))
	{
		dwCompressedSize = sizeof(FILEENTRY);
		memcpy(pBuffer, pEntry, sizeof(FILEENTRY));
	}
	pEntryCache->dwCompressedLength = dwCompressedSize;
	pEntryCache->pEntryCompressed = (BYTE *)a_realloc(pEntryCache->pEntryCompressed, dwCompressedSize);
	memcpy(pEntryCache->pEntryCompressed, pBuffer, dwCompressedSize);
	a_free(pBuffer);

	m_fpPackageFile->seek(m_header.dwEntryOffset, SEEK_SET);

	//	We write the compressed buffer into the disk;
	Encrypt(pCompressedBuffer, dwCompressedLength);
	m_fpPackageFile->write(pCompressedBuffer, dwCompressedLength, 1);
	Decrypt(pCompressedBuffer, dwCompressedLength);
	m_header.dwEntryOffset += dwCompressedLength;

	m_bHasChanged = true;
	return true;
}

bool AFilePackage::RemoveFileFromDir(const char * filename)
{
	char szFindName[MAX_PATH];
	int nLength, i;
	char *name, *tok;

	strncpy(szFindName, filename, MAX_PATH);
	_strlwr(szFindName);
	name = szFindName;
	nLength = strlen(szFindName);
	for (i = 0; i < nLength; i++)
	{
		if (szFindName[i] == '/')
			szFindName[i] = '\\';
	}
	tok = strtok(name, "\\");
	directory * dir = &m_directory;
	while (tok)
	{
		entry * ent = dir->SearchItem(tok);
		if (ent == NULL) return false; //entry not found
		char * next = strtok(NULL, "\\");
		if (next == NULL)
		{
			if (!ent->IsContainer())
			{
				dir->RemoveItem(tok);
				return true;
			}
			return false;
		}
		else
		{
			if (ent->IsContainer())
				dir = (directory *)ent;
			else
				return false;
		}
		tok = next;
	}
	return false;
}

AFilePackage::directory * AFilePackage::GetDirEntry(const char * szPath)
{
	char szFindName[MAX_PATH];
	int nLength, i;
	char *name, *tok;

	strncpy(szFindName, szPath, MAX_PATH);
	_strlwr(szFindName);
	name = szFindName;
	nLength = strlen(szFindName);
	for (i = 0; i < nLength; i++)
	{
		if (szFindName[i] == '/')
			szFindName[i] = '\\';
	}
	tok = strtok(name, "\\");
	directory * dir = &m_directory;
	while (tok && *tok)
	{
		entry * ent = dir->SearchItem(tok);
		if (ent == NULL) return NULL; //entry not found
		if (!ent->IsContainer()) return NULL;
		tok = strtok(NULL, "\\");
		dir = (directory*)ent;
	}
	return dir;
}

bool AFilePackage::InsertFileToDir(const char * filename, int index)
{
	char szFindName[MAX_PATH];
	int nLength, i;
	char *name, *tok;

	strncpy(szFindName, filename, MAX_PATH);
	_strlwr(szFindName);
	name = szFindName;
	nLength = strlen(szFindName);
	for (i = 0; i < nLength; i++)
	{
		if (szFindName[i] == '/')
			szFindName[i] = '\\';
	}
	tok = strtok(name, "\\");
	directory * dir = &m_directory;
	while (tok)
	{
		char * next = strtok(NULL, "\\");
		entry * ent = dir->SearchItem(tok);
		if (next)
		{
			if (ent == NULL)
			{
				directory *tmp = new directory(tok);
				dir->AppendEntry(tmp);
				dir = tmp;
			}
			else
			{
				assert(ent->IsContainer());
				if (!ent->IsContainer())
				{
					AFERRLOG(("AFilePackage::InsertFileToDir(), Directory conflict:%s", filename));
					return false;
				}
				dir = (directory*)ent;
			}
		}
		else
		{
			if (ent == NULL)
			{
				dir->AppendEntry(new file(tok, index));
			}
			else
			{
				assert(!ent->IsContainer());
				if (ent->IsContainer())
					return false;
				else
					((file*)ent)->SetIndex(index);
				break;
			}
		}
		tok = next;
	}
	return true;
}


// ТСѕ­МнјУБЛДїВјЅб№№
bool AFilePackage::ResortEntries()
{
	m_directory.clear();
	for (int i = 0; i < m_aFileEntries.GetSize(); i++)
	{
		//	єцВФ·ўЙъµДґнОу
		InsertFileToDir(m_aFileEntries[i]->szFileName, i);
	}
	return true;
}

//	Add a group of file names to file cache list
bool AFilePackage::AddCacheFileNameList(const char* szDescFile)
{
	AScriptFile ScriptFile;
	if (!ScriptFile.Open(szDescFile))
	{
		AFERRLOG(("AFilePackage::ReadCacheFileNameList, Failed to open file %s !", szDescFile));
		return false;
	}

	while (ScriptFile.GetNextToken(true))
	{
		AddCacheFileName(ScriptFile.m_szToken);
	}

	ScriptFile.Close();

	return true;
}

//	Add a file name to file cache list
bool AFilePackage::AddCacheFileName(const char* szFile)
{
	CACHEFILENAME* pCacheFile = new CACHEFILENAME;
	if (!pCacheFile)
	{
		AFERRLOG(("AFilePackage::ReadCacheFileNameList, Not enough memory !"));
		return false;
	}

	pCacheFile->strFileName = szFile;
	pCacheFile->dwFileID = a_MakeIDFromLowString(szFile);

	if (!m_CachedFileTab.put((int)pCacheFile->dwFileID, pCacheFile))
	{
		//	Failed to put item into table, this maybe caused by file name collision
		delete pCacheFile;
		return false;
	}

	return true;
}

//	Clear file cache
void AFilePackage::ClearFileCache()
{
	SharedTable::iterator it = m_SharedFileTab.begin();
	for (; it != m_SharedFileTab.end(); )
	{
		SHAREDFILE* pFileItem = *it.value();

		//	Don't release file which is still referenced
		if (!pFileItem->iRefCnt)
		{
			a_free(pFileItem->pFileData);
			delete pFileItem;

			it = m_SharedFileTab.erase(it);
		}
		else
			++it;
	}
}

/*	Open a shared file

	Return file handle address for success, otherwise return NULL for failure

	szFileName: name of specified file
	ppFileBuf (out): receive file data buffer
	dwFileLen (out): receive file data length
*//*
DWORD AFilePackage::OpenSharedFile(const char* szFileName, BYTE** ppFileBuf, DWORD* pdwFileLen)
{
	char szFile[MAX_PATH];

	//	Normalize file name
	strncpy(szFile, szFileName, MAX_PATH);
	NormalizeFileName(szFile, m_bUseShortName);
	DWORD dwFileID = a_MakeIDFromLowString(szFile);
	if (!dwFileID)
	{
		ASSERT(dwFileID);
		return 0;
	}

	ACSWrapper csa(&m_csSF);

	//	Search it in opened shared file table
	SharedTable::pair_type Pair = m_SharedFileTab.get((int)dwFileID);
	if (Pair.second)
	{
		//	This file exists in shared file table
		SHAREDFILE* pFileItem = *Pair.first;

		if (stricmp(szFileName, pFileItem->pFileEntry->szFileName))
		{
			ASSERT(0);
			return 0;
		}

		pFileItem->iRefCnt++;
		pFileItem->pFileEntry->iAccessCnt++;

		*ppFileBuf	= pFileItem->pFileData;
		*pdwFileLen	= pFileItem->dwFileLen;

		return (DWORD)pFileItem;
	}

	//	Get file entry
	FILEENTRY FileEntry;
	int iEntryIndex;
	if (!GetFileEntry(szFile, &FileEntry, &iEntryIndex))
	{
		AFERRLOG(("AFilePackage::OpenSharedFile, Failed to find file [%s] in package !", szFile));
		return false;
	}

	//	Allocate file data buffer
	BYTE* pFileData = (BYTE*)a_malloc(FileEntry.dwLength);
	if (!pFileData)
	{
		AFERRLOG(("AFilePackage::OpenSharedFile, Not enough memory!"));
		return false;
	}

	//	Read file data
	DWORD dwFileLen = FileEntry.dwLength;
	if (!ReadFile(FileEntry, pFileData, &dwFileLen))
	{
		AFERRLOG(("AFilePackage::OpenSharedFile, Failed to read file data [%s] !", szFile));
		return false;
	}

	//	The file is in cache file list ?
	CACHEFILENAME* pCachedFile = SearchCacheFileName(dwFileID);

	//	Add it to shared file arrey
	SHAREDFILE* pFileItem = new SHAREDFILE;
	if (!pFileItem)
	{
		a_free(pFileData);
		AFERRLOG(("AFilePackage::OpenSharedFile, Not enough memory!"));
		return false;
	}

	pFileItem->bCached		= pCachedFile ? true : false;
	pFileItem->dwFileID		= dwFileID;
	pFileItem->dwFileLen	= dwFileLen;
	pFileItem->iRefCnt		= 1;
	pFileItem->pFileData	= pFileData;
	pFileItem->pFileEntry	= m_aFileEntries[iEntryIndex];

	pFileItem->pFileEntry->iAccessCnt++;

	m_SharedFileTab.put((int)dwFileID, pFileItem);

	//	Change size counter
	m_dwSharedSize += dwFileLen;
	if (pFileItem->bCached)
		m_dwCacheSize += dwFileLen;

	*ppFileBuf	= pFileData;
	*pdwFileLen	= dwFileLen;

	return (DWORD)pFileItem;
}
*/
DWORD AFilePackage::OpenSharedFile(const char* szFileName, BYTE** ppFileBuf, DWORD* pdwFileLen)
{
	//	Get file entry
	FILEENTRY FileEntry;
	int iEntryIndex;
	if (!GetFileEntry(szFileName, &FileEntry, &iEntryIndex))
	{
		if (!strstr(szFileName, "Textures") && !strstr(szFileName, "Tex_"))
		{
			AFERRLOG(("AFilePackage::OpenSharedFile, Failed to find file [%s] in package !", szFileName));
		}
		return false;
	}

	//	Allocate file data buffer
	BYTE* pFileData = (BYTE*)a_malloc(FileEntry.dwLength);
	if (!pFileData)
	{
		AFERRLOG(("AFilePackage::OpenSharedFile, Not enough memory!"));
		return false;
	}

	//	Read file data
	DWORD dwFileLen = FileEntry.dwLength;
	if (!ReadFile(FileEntry, pFileData, &dwFileLen))
	{
		AFERRLOG(("AFilePackage::OpenSharedFile, Failed to read file data [%s] !", szFileName));
		return false;
	}

	//	Add it to shared file arrey
	SHAREDFILE* pFileItem = new SHAREDFILE;
	if (!pFileItem)
	{
		a_free(pFileData);
		AFERRLOG(("AFilePackage::OpenSharedFile, Not enough memory!"));
		return false;
	}

	pFileItem->bCached = false;
	pFileItem->dwFileID = 0;
	pFileItem->dwFileLen = dwFileLen;
	pFileItem->iRefCnt = 1;
	pFileItem->pFileData = pFileData;
	pFileItem->pFileEntry = m_aFileEntries[iEntryIndex];

	//	pFileItem->pFileEntry->iAccessCnt++;

	*ppFileBuf = pFileData;
	*pdwFileLen = dwFileLen;

	return (DWORD)pFileItem;
}

/*
//	Close a shared file
void AFilePackage::CloseSharedFile(DWORD dwFileHandle)
{
	SHAREDFILE* pFileItem = (SHAREDFILE*)dwFileHandle;
	ASSERT(pFileItem && pFileItem->iRefCnt > 0);

	ACSWrapper csa(&m_csSF);

	SharedTable::pair_type Pair = m_SharedFileTab.get((int)pFileItem->dwFileID);
	if (!Pair.second)
	{
		ASSERT(0);
		return;
	}

	pFileItem->iRefCnt--;

	if (!pFileItem->iRefCnt && !pFileItem->bCached)
	{
		//	Change size counter
		m_dwSharedSize -= pFileItem->dwFileLen;

		//	No cache file, release it
		a_free(pFileItem->pFileData);
		delete pFileItem;

		m_SharedFileTab.erase((int)pFileItem->dwFileID);
	}
}
*/

//	Close a shared file
void AFilePackage::CloseSharedFile(DWORD dwFileHandle)
{
	SHAREDFILE* pFileItem = (SHAREDFILE*)dwFileHandle;
	ASSERT(pFileItem && pFileItem->iRefCnt > 0);

	//	No cache file, release it
	a_free(pFileItem->pFileData);
	delete pFileItem;
}

//	Search a cache file name from list
//	Return index of file name for success, otherwise return -1
AFilePackage::CACHEFILENAME* AFilePackage::SearchCacheFileName(const char* szFileName)
{
	DWORD dwFileID = a_MakeIDFromLowString(szFileName);
	return SearchCacheFileName(dwFileID);
}

//	Search a cache file name from list
//	Return index of file name for success, otherwise return -1
AFilePackage::CACHEFILENAME* AFilePackage::SearchCacheFileName(DWORD dwFileID)
{
	CachedTable::pair_type Pair = m_CachedFileTab.get((int)dwFileID);
	if (!Pair.second)
		return NULL;

	return *Pair.first;
}

/////////////////////////////////////////////////////////////////////////////////////
// File package manager object
/////////////////////////////////////////////////////////////////////////////////////
AFilePackMan::AFilePackMan() : m_FilePcks()
{
}

AFilePackMan::~AFilePackMan()
{
	CloseAllPackages();
}

bool AFilePackMan::OpenFilePackage(const char * szPckFile, bool bCreateNew, bool bEncrypt)
{
	AFilePackage * pFilePackage;
	if (!(pFilePackage = new AFilePackage))
	{
		AFERRLOG(("AFilePackMan::OpenFilePackage(), Not enough memory!"));
		return false;
	}

	if (!pFilePackage->Open(szPckFile, bCreateNew ? AFilePackage::CREATENEW : AFilePackage::OPENEXIST, bEncrypt))
	{
		delete pFilePackage;
		AFERRLOG(("AFilePackMan::OpenFilePackage(), Can not open package [%s]", szPckFile));
		return false;
	}

	m_FilePcks.push_back(pFilePackage);

	return true;
}

bool AFilePackMan::CreateFilePackage(const char * szPckFile, const char* szFolder, bool bEncrypt/* false */)
{
	AFilePackage * pFilePackage;
	if (!(pFilePackage = new AFilePackage))
	{
		AFERRLOG(("AFilePackMan::OpenFilePackage(), Not enough memory!"));
		return false;
	}

	if (!pFilePackage->Open(szPckFile, szFolder, AFilePackage::CREATENEW, bEncrypt))
	{
		delete pFilePackage;
		AFERRLOG(("AFilePackMan::OpenFilePackage(), Can not open package [%s]", szPckFile));
		return false;
	}

	m_FilePcks.push_back(pFilePackage);

	return true;
}

bool AFilePackMan::OpenFilePackage(const char * szPckFile, const char* szFolder, bool bEncrypt/* false */)
{
	AFilePackage * pFilePackage;
	if (!(pFilePackage = new AFilePackage))
	{
		AFERRLOG(("AFilePackMan::OpenFilePackage(), Not enough memory!"));
		return false;
	}

	if (!pFilePackage->Open(szPckFile, szFolder, AFilePackage::OPENEXIST, bEncrypt))
	{
		delete pFilePackage;
		AFERRLOG(("AFilePackMan::OpenFilePackage(), Can not open package [%s]", szPckFile));
		return false;
	}

	m_FilePcks.push_back(pFilePackage);

	return true;
}

bool AFilePackMan::CloseFilePackage(AFilePackage * pFilePck)
{
	int nCount = m_FilePcks.size();
	for (int i = 0; i < nCount; i++)
	{
		if (m_FilePcks[i] == pFilePck)
		{
			m_FilePcks.erase(&m_FilePcks[i]);

			pFilePck->Close();
			delete pFilePck;
			return true;
		}
	}

	return true;
}

bool AFilePackMan::CloseAllPackages()
{
	while (m_FilePcks.size())
	{
		AFilePackage * pFilePck = m_FilePcks[0];

		m_FilePcks.erase(&m_FilePcks[0]);

		pFilePck->Close();
		delete pFilePck;
	}

	m_FilePcks.clear();

	return true;
}

AFilePackage * AFilePackMan::GetFilePck(const char * szPath)
{
	char szLowPath[MAX_PATH];
	strncpy(szLowPath, szPath, MAX_PATH);
	_strlwr(szLowPath);
	AFilePackage::NormalizeFileName(szLowPath);

	for (size_t i = 0; i < m_FilePcks.size(); i++)
	{
		AFilePackage* pPack = m_FilePcks[i];

		if (strstr(szLowPath, pPack->GetFolder()) == szLowPath)
		{
			return pPack;
		}
	}

	return NULL;
}

bool AFilePackMan::SetAlgorithmID(int id)
{
	switch (id)
	{
	case 111:
		AFPCK_GUARDBYTE0 = 0xab12908f;
		AFPCK_GUARDBYTE1 = 0xb3231902;
		AFPCK_MASKDWORD = 0x2a63810e;
		AFPCK_CHECKMASK = 0x18734563;
		break;

	default:
		AFPCK_GUARDBYTE0 = 0xfdfdfeee + id * 0x72341f2;
		AFPCK_GUARDBYTE1 = 0xf00dbeef + id * 0x1237a73;
		AFPCK_MASKDWORD = 0xa8937462 + id * 0xab2321f;
		AFPCK_CHECKMASK = 0x59374231 + id * 0x987a223;
		break;
	}
	return true;
}

/*
	Compress a data buffer
	pFileBuffer			IN		buffer contains data to be compressed
	dwFileLength		IN		the bytes in buffer to be compressed
	pCompressedBuffer	OUT		the buffer to hold the compressed data
	pdwCompressedLength IN/OUT	the compressed buffer size when used as input
								when out, it contains the real compressed length

	RETURN: 0,		ok
			-1,		dest buffer is too small
			-2,		unknown error
*/
int AFilePackage::Compress(LPBYTE pFileBuffer, DWORD dwFileLength, LPBYTE pCompressedBuffer, DWORD * pdwCompressedLength)
{
	int nRet = compress2(pCompressedBuffer, pdwCompressedLength, pFileBuffer, dwFileLength, 1);
	if (Z_OK == nRet)
		return 0;

	if (Z_BUF_ERROR == nRet)
		return -1;
	else
		return -2;
}

/*
	Uncompress a data buffer
	pCompressedBuffer	IN		buffer contains compressed data to be uncompressed
	dwCompressedLength	IN		the compressed data size
	pFileBuffer			OUT		the uncompressed data buffer
	pdwFileLength		IN/OUT	the uncompressed data buffer size as input
								when out, it is the real uncompressed data length

	RETURN: 0,		ok
			-1,		dest buffer is too small
			-2,		unknown error
*/
int AFilePackage::Uncompress(LPBYTE pCompressedBuffer, DWORD dwCompressedLength, LPBYTE pFileBuffer, DWORD * pdwFileLength)
{
	int nRet = uncompress(pFileBuffer, pdwFileLength, pCompressedBuffer, dwCompressedLength);
	if (Z_OK == nRet)
		return 0;

	if (Z_BUF_ERROR == nRet)
		return -1;
	else
		return -2;
}


/*
	Safe Header section
*/
bool AFilePackage::LoadSafeHeader()
{
	m_fpPackageFile->seek(0, SEEK_SET);

	m_fpPackageFile->read(&m_safeHeader, sizeof(SAFEFILEHEADER), 1);
	if (m_safeHeader.tag1 == 0x4DCA23EF && m_safeHeader.tag2 == 0x56a089b7)
	{
		m_bHasSafeHeader = true;
	}
	else if (m_safeHeader.tag1 == 0x4DCA23EF && m_safeHeader.tag2 != 0x56a089b7)
	{
		m_bHasSafeHeader = true;
		m_fpPackageFile->seek(0, SEEK_SET);
		m_fpPackageFile->read(&m_safeHeader, sizeof(SAFEFILEHEADER_0x00020003), 1);
	}
	else
		m_bHasSafeHeader = false;

	if (m_bHasSafeHeader)
		m_fpPackageFile->Phase2Open(m_safeHeader.offset);

	m_fpPackageFile->seek(0, SEEK_SET);
	return true;
}

bool AFilePackage::CreateSafeHeader()
{
	m_bHasSafeHeader = true;

	m_safeHeader.tag1 = 0x4DCA23EF;
	m_safeHeader.tag2 = 0x56a089b7;
	m_safeHeader.offset = 0;

	return true;
}

bool AFilePackage::SaveSafeHeader()
{
	if (m_bHasSafeHeader)
	{
		m_fpPackageFile->seek(0, SEEK_END);
		m_safeHeader.offset = m_fpPackageFile->tell();

		m_fpPackageFile->seek(0, SEEK_SET);
		m_fpPackageFile->write(&m_safeHeader, sizeof(SAFEFILEHEADER), 1);
		m_fpPackageFile->seek(0, SEEK_SET);
	}

	return true;
}

#define ENTRY_BUFFER_SIZE		(1024 * 1024)

bool AFilePackage::SaveEntries(DWORD * pdwEntrySize)
{
	DWORD dwTotalSize = 0;

	int iNumFile = m_aFileEntries.GetSize();

	DWORD dwBufferUsed = 0;
	BYTE * pEntryBuffer = new BYTE[ENTRY_BUFFER_SIZE];
	if (NULL == pEntryBuffer)
		return false;

	// Rewrite file entries and file header here;
	m_fpPackageFile->seek(m_header.dwEntryOffset, SEEK_SET);
	for (int i = 0; i < iNumFile; i++)
	{
		FILEENTRY* pEntry = m_aFileEntries[i];
		FILEENTRYCACHE* pEntryCache = m_aFileEntryCache[i];

		if (dwBufferUsed + sizeof(FILEENTRY) + sizeof(DWORD) + sizeof(DWORD) > ENTRY_BUFFER_SIZE)
		{
			// flush entry buffer;
			m_fpPackageFile->write(pEntryBuffer, dwBufferUsed, 1);
			dwBufferUsed = 0;
		}

		DWORD dwCompressedSize = pEntryCache->dwCompressedLength;

		dwCompressedSize ^= AFPCK_MASKDWORD;
		memcpy(&pEntryBuffer[dwBufferUsed], &dwCompressedSize, sizeof(DWORD));
		dwBufferUsed += sizeof(DWORD);

		dwCompressedSize ^= AFPCK_CHECKMASK;
		memcpy(&pEntryBuffer[dwBufferUsed], &dwCompressedSize, sizeof(DWORD));
		dwBufferUsed += sizeof(DWORD);

		memcpy(&pEntryBuffer[dwBufferUsed], pEntryCache->pEntryCompressed, pEntryCache->dwCompressedLength);
		dwBufferUsed += pEntryCache->dwCompressedLength;

		dwTotalSize += sizeof(DWORD) + sizeof(DWORD) + pEntryCache->dwCompressedLength;
	}

	if (dwBufferUsed)
	{
		// flush entry buffer;
		m_fpPackageFile->write(pEntryBuffer, dwBufferUsed, 1);
		dwBufferUsed = 0;
	}

	delete[] pEntryBuffer;
	pEntryBuffer = NULL;

	if (pdwEntrySize)
		*pdwEntrySize = dwTotalSize;
	return true;
}


AFilePackage::CPackageFile::CPackageFile()
{
	m_pFile1 = NULL;
	m_pFile2 = NULL;

	m_size1 = 0;
	m_size2 = 0;

	m_filePos = 0;
}

AFilePackage::CPackageFile::~CPackageFile()
{
}

bool AFilePackage::CPackageFile::Open(const char * szFileName, const char * szMode)
{
	Close();

	m_pFile1 = fopen(szFileName, szMode);
	if (NULL == m_pFile1)
		return false;

	fseek(m_pFile1, 0, SEEK_END);
	m_size1 = ftell(m_pFile1);
	fseek(m_pFile1, 0, SEEK_SET);

	m_filePos = 0;
	strncpy(m_szPath, szFileName, MAX_PATH);
	strncpy(m_szMode, szMode, 32);

	strcpy(m_szPath2, m_szPath);
	af_ChangeFileExt(m_szPath2, MAX_PATH, ".pkx");
	return true;
}

bool AFilePackage::CPackageFile::Phase2Open(DWORD dwOffset)
{
	if (dwOffset >= MAX_FILE_PACKAGE)
	{
		// we need the second file now;
		m_pFile2 = fopen(m_szPath2, m_szMode);
		if (NULL == m_pFile2)
		{
			if (_stricmp(m_szMode, "r+b") == 0 && !af_IsFileExist(m_szPath2))
			{
				// it is the first time we access the second file	
				m_pFile2 = fopen(m_szPath2, "wb");
				if (NULL == m_pFile2)
					return false;
			}
			else
				return false;
		}

		fseek(m_pFile2, 0, SEEK_END);
		m_size2 = ftell(m_pFile2);
		fseek(m_pFile2, 0, SEEK_SET);
	}

	return true;
}

bool AFilePackage::CPackageFile::Close()
{
	if (m_pFile2)
	{
		fclose(m_pFile2);
		m_pFile2 = NULL;
	}

	if (m_pFile1)
	{
		fclose(m_pFile1);
		m_pFile1 = NULL;
	}

	m_size1 = 0;
	m_size2 = 0;
	m_filePos = 0;

	return true;
}

size_t AFilePackage::CPackageFile::read(void *buffer, size_t size, size_t count)
{
	size_t size_to_read = size * count;
	__int64 new_pos = m_filePos + size_to_read;

	if (new_pos <= MAX_FILE_PACKAGE)
	{
		// completely in file 1
		size_t readsize = fread(buffer, 1, size_to_read, m_pFile1);
		m_filePos += readsize;
		return readsize;
	}
	else if (m_filePos < MAX_FILE_PACKAGE)
	{
		// partial in file1 and partial in file 2
		size_t size_to_read1 = (size_t)(MAX_FILE_PACKAGE - m_filePos);
		size_t size_to_read2 = (size_t)(size_to_read - size_to_read1);

		// read from file1
		size_t readsize = fread(buffer, 1, size_to_read1, m_pFile1);

		if (m_pFile2)
		{
			// read from file2
			fseek(m_pFile2, 0, SEEK_SET);
			readsize += fread((LPBYTE)buffer + size_to_read1, 1, size_to_read2, m_pFile2);
		}

		m_filePos += readsize;
		return readsize;
	}
	else
	{
		// completely in file 2
		size_t readsize = fread(buffer, 1, size_to_read, m_pFile2);
		m_filePos += readsize;
		return readsize;
	}

	return 0;
}

size_t AFilePackage::CPackageFile::write(const void *buffer, size_t size, size_t count)
{
	size_t size_to_write = size * count;
	__int64 new_size = m_filePos + size_to_write;

	if (new_size <= MAX_FILE_PACKAGE)
	{
		// completely in file 1
		size_t writesize = fwrite(buffer, 1, size_to_write, m_pFile1);
		m_filePos += writesize;
		if (m_filePos > m_size1)
			m_size1 = m_filePos;
		return writesize;
	}
	else if (m_filePos < MAX_FILE_PACKAGE)
	{
		// partial in file1 and partial in file 2
		size_t size_to_write1 = (size_t)(MAX_FILE_PACKAGE - m_filePos);
		size_t size_to_write2 = (size_t)(size_to_write - size_to_write1);

		// write to file1
		size_t writesize = fwrite(buffer, 1, size_to_write1, m_pFile1);
		m_size1 = MAX_FILE_PACKAGE;

		if (!m_pFile2)
			Phase2Open(MAX_FILE_PACKAGE);

		// write to file2
		fseek(m_pFile2, 0, SEEK_SET);
		writesize += fwrite((LPBYTE)buffer + size_to_write1, 1, size_to_write2, m_pFile2);

		m_filePos += writesize;
		if (m_filePos > m_size1 + m_size2)
			m_size2 = m_filePos - m_size1;
		return writesize;
	}
	else
	{
		// completely in file 2
		size_t writesize = fwrite(buffer, 1, size_to_write, m_pFile2);
		m_filePos += writesize;
		if (m_filePos > m_size1 + m_size2)
			m_size2 = m_filePos - m_size1;
		return writesize;
	}

	return 0;
}

void AFilePackage::CPackageFile::seek(__int64 offset, int origin)
{
	__int64 newpos = m_filePos;

	if (m_pFile2)
	{
		switch (origin)
		{
		case SEEK_SET:
			newpos = offset;
			break;

		case SEEK_CUR:
			newpos = m_filePos + offset;
			break;

		case SEEK_END:
			newpos = m_size1 + m_size2 + offset;
			break;
		}

		if (newpos < 0)
			newpos = 0;
		if (newpos > m_size1 + m_size2)
			newpos = m_size1 + m_size2;

		if (newpos < m_size1)
			fseek(m_pFile1, (long)newpos, SEEK_SET);
		else
			fseek(m_pFile2, (long)(newpos - m_size1), SEEK_SET);

		m_filePos = newpos;
	}
	else
	{
		fseek(m_pFile1, (long)offset, origin);
		m_filePos = ftell(m_pFile1);
	}

	return;
}

DWORD AFilePackage::CPackageFile::tell()
{
	return (DWORD)m_filePos;
}

void AFilePackage::CPackageFile::SetPackageFileSize(DWORD dwFileSize)
{
	if (m_pFile2)
	{
		if (dwFileSize <= MAX_FILE_PACKAGE)
		{
			int fileHandle = _fileno(m_pFile1);
			_chsize(fileHandle, dwFileSize);
			m_size1 = dwFileSize;

			fclose(m_pFile2);
			m_pFile2 = NULL;
			remove(m_szPath2);
			m_size2 = 0;
		}
		else
		{
			int fileHandle = _fileno(m_pFile2);
			m_size2 = dwFileSize - MAX_FILE_PACKAGE;
			_chsize(fileHandle, (long)m_size2);
		}
	}
	else
	{
		int fileHandle = _fileno(m_pFile1);
		_chsize(fileHandle, dwFileSize);
		m_size1 = dwFileSize;
	}
}
